import axios from 'axios';
import toast from 'react-hot-toast';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const api = axios.create({
  baseURL: BASE_URL,
  timeout: 15000,
  headers: { 'Content-Type': 'application/json' }
});

api.interceptors.request.use(config => {
  const token = localStorage.getItem('ha_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
}, error => Promise.reject(error));

api.interceptors.response.use(
  response => response.data,
  error => {
    const msg = error.response?.data?.error || error.message || 'Request failed';
    if (error.response?.status === 401) {
      localStorage.removeItem('ha_token');
      window.location.href = '/login';
    } else if (error.response?.status !== 404) {
      toast.error(msg);
    }
    return Promise.reject(error);
  }
);

export const cloudApi = {
  getAll: () => api.get('/clouds'),
  getById: (id) => api.get(`/clouds/${id}`),
  create: (data) => api.post('/clouds', data),
  update: (id, data) => api.put(`/clouds/${id}`, data),
  delete: (id) => api.delete(`/clouds/${id}`),
  seedDemo: () => api.post('/clouds/seed/demo')
};

export const serverApi = {
  getAll: (params) => api.get('/servers', { params }),
  getById: (id) => api.get(`/servers/${id}`),
  create: (data) => api.post('/servers', data),
  update: (id, data) => api.put(`/servers/${id}`, data),
  delete: (id) => api.delete(`/servers/${id}`),
  getMetrics: (id) => api.get(`/servers/${id}/metrics`)
};

export const alertApi = {
  getAll: (params) => api.get('/alerts', { params }),
  getSummary: () => api.get('/alerts/summary'),
  acknowledge: (id, userId) => api.patch(`/alerts/${id}/acknowledge`, { userId }),
  resolve: (id, userId) => api.patch(`/alerts/${id}/resolve`, { userId }),
  deleteResolved: () => api.delete('/alerts/resolved')
};

export const failoverApi = {
  getAll: () => api.get('/failover'),
  getById: (id) => api.get(`/failover/${id}`),
  trigger: (data) => api.post('/failover/trigger', data),
  getStats: () => api.get('/failover/stats/summary')
};

export const metricsApi = {
  getDashboard: () => api.get('/metrics/dashboard'),
  getTimeseries: () => api.get('/metrics/timeseries'),
  getCosts: () => api.get('/metrics/costs')
};

export const lbApi = {
  getConfig: () => api.get('/loadbalancer/config'),
  updateConfig: (data) => api.put('/loadbalancer/config', data),
  getStatus: () => api.get('/loadbalancer/status'),
  getTraffic: () => api.get('/loadbalancer/traffic')
};

export const healthApi = {
  check: () => api.get('/health'),
  live: () => api.get('/health/live'),
  ready: () => api.get('/health/ready')
};

export default api;

export const userApi = {
  getAll:    (params) => api.get('/users', { params }),
  getById:   (id) => api.get(`/users/${id}`),
  create:    (data) => api.post('/users', data),
  update:    (id, data) => api.put(`/users/${id}`, data),
  toggle:    (id) => api.patch(`/users/${id}/toggle`),
  delete:    (id) => api.delete(`/users/${id}`),
  activity:  () => api.get('/users/me/activity'),
};

export const auditApi = {
  getAll:    (params) => api.get('/audit', { params }),
  getSummary:() => api.get('/audit/summary'),
};

export const notifApi = {
  getChannels:() => api.get('/notifications/channels'),
  test:       () => api.post('/notifications/test'),
};
