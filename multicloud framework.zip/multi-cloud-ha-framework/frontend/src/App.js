import React, { Suspense, lazy } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { AppProvider } from './context/AppContext';
import Layout from './components/Layout/Layout';
import LoadingScreen from './components/common/LoadingScreen';

const Login        = lazy(() => import('./pages/Login'));
const Dashboard    = lazy(() => import('./pages/Dashboard'));
const Providers    = lazy(() => import('./pages/Providers'));
const Servers      = lazy(() => import('./pages/Servers'));
const Alerts       = lazy(() => import('./pages/Alerts'));
const Failover     = lazy(() => import('./pages/Failover'));
const LoadBalancer = lazy(() => import('./pages/LoadBalancer'));
const Analytics    = lazy(() => import('./pages/Analytics'));
const AuditLog     = lazy(() => import('./pages/AuditLog'));
const Profile      = lazy(() => import('./pages/Profile'));
const Settings     = lazy(() => import('./pages/Settings'));
const NotFound     = lazy(() => import('./pages/NotFound'));

const RequireAuth = ({ children }) => {
  const token = localStorage.getItem('ha_token');
  return token ? children : <Navigate to="/login" replace />;
};

export default function App() {
  return (
    <AppProvider>
      <Router>
        <Toaster position="top-right" toastOptions={{
          style: { background:'#111827',color:'#e8f0fe',border:'1px solid #1e2d45',fontFamily:"'DM Sans',sans-serif",fontSize:'13px' },
          success: { iconTheme:{ primary:'#00ff88',secondary:'#111827' } },
          error:   { iconTheme:{ primary:'#ff4060',secondary:'#111827' } }
        }}/>
        <Suspense fallback={<LoadingScreen />}>
          <Routes>
            <Route path="/login" element={<Login />} />
            <Route path="/" element={<RequireAuth><Layout /></RequireAuth>}>
              <Route index element={<Navigate to="/dashboard" replace />} />
              <Route path="dashboard"    element={<Dashboard />} />
              <Route path="providers"    element={<Providers />} />
              <Route path="servers"      element={<Servers />} />
              <Route path="alerts"       element={<Alerts />} />
              <Route path="failover"     element={<Failover />} />
              <Route path="loadbalancer" element={<LoadBalancer />} />
              <Route path="analytics"    element={<Analytics />} />
              <Route path="audit"        element={<AuditLog />} />
              <Route path="profile"      element={<Profile />} />
              <Route path="settings"     element={<Settings />} />
              <Route path="*"            element={<NotFound />} />
            </Route>
            <Route path="*" element={<Navigate to="/login" replace />} />
          </Routes>
        </Suspense>
      </Router>
    </AppProvider>
  );
}
