import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { metricsApi, cloudApi, alertApi } from '../services/api';
import { initSocket } from '../services/socket';
import toast from 'react-hot-toast';

const AppContext = createContext(null);
const initialState = { providers: [], servers: [], alerts: [], alertSummary: { active: 0, critical: 0, warnings: 0 }, overview: null, failovers: [], socket: null, connected: false, loading: true, lastUpdated: null, activeFailover: null };

function reducer(state, action) {
  switch (action.type) {
    case 'SET_LOADING': return { ...state, loading: action.payload };
    case 'SET_PROVIDERS': return { ...state, providers: action.payload };
    case 'SET_SERVERS': return { ...state, servers: action.payload };
    case 'SET_ALERTS': return { ...state, alerts: action.payload };
    case 'SET_ALERT_SUMMARY': return { ...state, alertSummary: action.payload };
    case 'SET_OVERVIEW': return { ...state, overview: action.payload, lastUpdated: new Date() };
    case 'SET_FAILOVERS': return { ...state, failovers: action.payload };
    case 'SET_SOCKET': return { ...state, socket: action.payload };
    case 'SET_CONNECTED': return { ...state, connected: action.payload };
    case 'SET_ACTIVE_FAILOVER': return { ...state, activeFailover: action.payload };
    case 'UPDATE_PROVIDER': return { ...state, providers: state.providers.map(p => p._id === action.payload._id ? { ...p, ...action.payload } : p) };
    case 'ADD_ALERT': return { ...state, alerts: [action.payload, ...state.alerts].slice(0, 100) };
    default: return state;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, initialState);

  const fetchDashboard = useCallback(async () => {
    try {
      const data = await metricsApi.getDashboard();
      dispatch({ type: 'SET_OVERVIEW', payload: data.overview });
      dispatch({ type: 'SET_PROVIDERS', payload: data.providers || [] });
      dispatch({ type: 'SET_SERVERS', payload: data.servers || [] });
      dispatch({ type: 'SET_ALERTS', payload: data.activeAlerts || [] });
      dispatch({ type: 'SET_FAILOVERS', payload: data.recentFailovers || [] });
    } catch (err) { console.error('Dashboard fetch failed:', err); }
  }, []);

  const fetchAlertSummary = useCallback(async () => {
    try { const s = await alertApi.getSummary(); dispatch({ type: 'SET_ALERT_SUMMARY', payload: s }); } catch {}
  }, []);

  const seedData = useCallback(async () => {
    try { await cloudApi.seedDemo(); await fetchDashboard(); toast.success('Demo data loaded!'); } catch {}
  }, [fetchDashboard]);

  useEffect(() => {
    let interval;
    const init = async () => {
      dispatch({ type: 'SET_LOADING', payload: true });
      await fetchDashboard();
      await fetchAlertSummary();
      dispatch({ type: 'SET_LOADING', payload: false });
      const socket = initSocket();
      dispatch({ type: 'SET_SOCKET', payload: socket });
      socket.on('connect', () => dispatch({ type: 'SET_CONNECTED', payload: true }));
      socket.on('disconnect', () => dispatch({ type: 'SET_CONNECTED', payload: false }));
      socket.on('provider:update', (data) => dispatch({ type: 'UPDATE_PROVIDER', payload: data }));
      socket.on('alert:new', (alert) => {
        dispatch({ type: 'ADD_ALERT', payload: alert });
        const icons = { critical: '🔴', warning: '🟡', info: '🔵', emergency: '🚨' };
        toast.error(`${icons[alert.severity] || '⚠️'} ${alert.title}`, { duration: 5000 });
      });
      socket.on('failover:started', (data) => { dispatch({ type: 'SET_ACTIVE_FAILOVER', payload: data }); toast.loading(`🔄 Failover in progress...`, { id: 'failover', duration: 120000 }); });
      socket.on('failover:completed', (data) => { dispatch({ type: 'SET_ACTIVE_FAILOVER', payload: null }); toast.dismiss('failover'); toast.success(`✅ Failover complete in ${(data.durationMs / 1000).toFixed(1)}s`); fetchDashboard(); });
      socket.on('stats:update', () => fetchAlertSummary());
      interval = setInterval(fetchDashboard, 30000);
    };
    init();
    return () => { clearInterval(interval); };
  }, [fetchDashboard, fetchAlertSummary]);

  return <AppContext.Provider value={{ state, dispatch, fetchDashboard, fetchAlertSummary, seedData }}>{children}</AppContext.Provider>;
}

export const useApp = () => { const ctx = useContext(AppContext); if (!ctx) throw new Error('useApp must be used within AppProvider'); return ctx; };
