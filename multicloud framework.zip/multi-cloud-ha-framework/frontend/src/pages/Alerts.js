import React, { useState, useEffect } from 'react';
import { alertApi } from '../services/api';
import { Bell, RefreshCw, CheckCircle, Eye, Trash2, AlertTriangle, Info, Zap } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';

const SEV_ICONS = { info:<Info size={14}/>, warning:<AlertTriangle size={14}/>, critical:<Zap size={14}/>, emergency:<Zap size={14}/> };
const SEV_COLORS = { info:'var(--accent)',warning:'var(--accent-yellow)',critical:'var(--accent-red)',emergency:'#ff0040' };

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [summary, setSummary] = useState({ active:0,critical:0,warnings:0 });
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status:'active',severity:'' });

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const [a, s] = await Promise.all([alertApi.getAll(filter), alertApi.getSummary()]);
      setAlerts(a.alerts||[]); setSummary(s);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchAlerts(); }, [filter]);

  const handleAck = async (id) => {
    try { await alertApi.acknowledge(id,'admin'); toast.success('Alert acknowledged'); fetchAlerts(); } catch {}
  };
  const handleResolve = async (id) => {
    try { await alertApi.resolve(id,'admin'); toast.success('Alert resolved'); fetchAlerts(); } catch {}
  };
  const handleCleanup = async () => {
    try { const r = await alertApi.deleteResolved(); toast.success(r.message); fetchAlerts(); } catch {}
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Alerts</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Real-time alerts and incident management</p>
        </div>
        <div style={{ display:'flex',gap:8 }}>
          <button className="btn btn-ghost btn-sm" onClick={handleCleanup}><Trash2 size={13}/>Clean Resolved</button>
          <button className="btn btn-ghost btn-sm" onClick={fetchAlerts}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {[
          { label:'Active Alerts', value:summary.active, color:'var(--accent-yellow)', icon:<Bell size={18}/> },
          { label:'Critical', value:summary.critical, color:'var(--accent-red)', icon:<Zap size={18}/> },
          { label:'Warnings', value:summary.warnings, color:'var(--accent-yellow)', icon:<AlertTriangle size={18}/> },
          { label:'Info', value:Math.max(0,(summary.active||0)-(summary.critical||0)-(summary.warnings||0)), color:'var(--accent)', icon:<Info size={18}/> }
        ].map(s => (
          <div key={s.label} className="card" style={{ padding:16,display:'flex',alignItems:'center',gap:14 }}>
            <div style={{ width:40,height:40,background:`${s.color}18`,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',color:s.color,flexShrink:0 }}>{s.icon}</div>
            <div><div style={{ fontFamily:'var(--font-mono)',fontSize:26,fontWeight:700,color:s.color,lineHeight:1 }}>{s.value}</div><div style={{ fontSize:12,color:'var(--text-muted)',marginTop:2 }}>{s.label}</div></div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display:'flex',gap:10 }}>
        <select value={filter.status} onChange={e=>setFilter({...filter,status:e.target.value})} style={{ fontSize:13,padding:'6px 10px' }}>
          <option value="">All Status</option>
          <option value="active">Active</option>
          <option value="acknowledged">Acknowledged</option>
          <option value="resolved">Resolved</option>
        </select>
        <select value={filter.severity} onChange={e=>setFilter({...filter,severity:e.target.value})} style={{ fontSize:13,padding:'6px 10px' }}>
          <option value="">All Severity</option>
          <option value="emergency">Emergency</option>
          <option value="critical">Critical</option>
          <option value="warning">Warning</option>
          <option value="info">Info</option>
        </select>
      </div>

      {/* Alerts list */}
      <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
        {alerts.map(alert => (
          <div key={alert._id} className="card fade-in" style={{ padding:16,borderLeft:`3px solid ${SEV_COLORS[alert.severity]||'var(--border)'}`,display:'flex',alignItems:'flex-start',gap:14 }}>
            <div style={{ color:SEV_COLORS[alert.severity],marginTop:2,flexShrink:0 }}>{SEV_ICONS[alert.severity]}</div>
            <div style={{ flex:1,minWidth:0 }}>
              <div style={{ display:'flex',alignItems:'center',gap:8,marginBottom:4,flexWrap:'wrap' }}>
                <span style={{ fontWeight:600,fontSize:14 }}>{alert.title}</span>
                <span className={`badge ${alert.severity}`}>{alert.severity}</span>
                <span className={`badge ${alert.status}`}>{alert.status}</span>
              </div>
              <div style={{ fontSize:13,color:'var(--text-secondary)',marginBottom:6,lineHeight:1.5 }}>{alert.message}</div>
              <div style={{ display:'flex',gap:12,fontSize:11,color:'var(--text-muted)',flexWrap:'wrap' }}>
                <span>Type: {alert.type?.replace(/_/g,' ')}</span>
                {alert.source?.cloudProvider && <span>Provider: {alert.source.cloudProvider.alias||alert.source.cloudProvider}</span>}
                {alert.source?.server && <span>Server: {alert.source.server.name||alert.source.server}</span>}
                <span>{alert.createdAt ? formatDistanceToNow(new Date(alert.createdAt),{addSuffix:true}) : ''}</span>
              </div>
            </div>
            <div style={{ display:'flex',gap:6,flexShrink:0 }}>
              {alert.status === 'active' && <button className="btn btn-ghost btn-sm" onClick={()=>handleAck(alert._id)}><Eye size={12}/>Ack</button>}
              {alert.status !== 'resolved' && <button className="btn btn-secondary btn-sm" onClick={()=>handleResolve(alert._id)}><CheckCircle size={12}/>Resolve</button>}
            </div>
          </div>
        ))}
        {alerts.length === 0 && !loading && (
          <div className="card" style={{ textAlign:'center',padding:60 }}>
            <CheckCircle size={40} style={{ color:'var(--accent-green)',marginBottom:12,display:'block',margin:'0 auto 12px' }}/>
            <div style={{ fontSize:16,fontWeight:600,marginBottom:4 }}>All Clear!</div>
            <div style={{ fontSize:13,color:'var(--text-muted)' }}>No alerts matching your current filter.</div>
          </div>
        )}
      </div>
    </div>
  );
}
