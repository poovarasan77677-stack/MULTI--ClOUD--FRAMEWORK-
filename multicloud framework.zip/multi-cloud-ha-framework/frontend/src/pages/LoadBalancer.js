import React, { useState, useEffect } from 'react';
import { lbApi } from '../services/api';
import { Scale, RefreshCw, CheckCircle, XCircle, Activity, Zap, Settings2 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import toast from 'react-hot-toast';

export default function LoadBalancer() {
  const [status, setStatus] = useState(null);
  const [config, setConfig] = useState(null);
  const [traffic, setTraffic] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(false);
  const [editConfig, setEditConfig] = useState({});

  const fetchData = async () => {
    setLoading(true);
    try {
      const [s,c,t] = await Promise.all([lbApi.getStatus(), lbApi.getConfig(), lbApi.getTraffic()]);
      setStatus(s); setConfig(c); setEditConfig(c); setTraffic(t.data||[]);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); const i=setInterval(fetchData,15000); return ()=>clearInterval(i); }, []);

  const handleSave = async () => {
    try { await lbApi.updateConfig(editConfig); setConfig(editConfig); setEditing(false); toast.success('Config updated'); } catch {}
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Load Balancer</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Traffic distribution and backend health</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={fetchData}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
      </div>

      {/* Status overview */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {[
          { label:'Status', value:status?.status||'—', color:status?.status==='operational'?'var(--accent-green)':'var(--accent-red)' },
          { label:'Active Backends', value:`${status?.activeBackends||0}/${status?.totalBackends||0}`, color:'var(--accent)' },
          { label:'Requests/sec', value:status?.totalRequestsPerSecond||'0', color:'var(--accent-green)' },
          { label:'Algorithm', value:config?.algorithm||'—', color:'var(--accent-purple)' }
        ].map(s=>(
          <div key={s.label} className="card" style={{ padding:14,textAlign:'center' }}>
            <div style={{ fontFamily:'var(--font-mono)',fontSize:s.label==='Algorithm'?14:22,fontWeight:700,color:s.color,textTransform:'uppercase',letterSpacing:s.label==='Algorithm'?'0.5px':0 }}>{s.value}</div>
            <div style={{ fontSize:11,color:'var(--text-muted)',marginTop:3 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Traffic chart */}
      <div className="card">
        <h3 style={{ fontSize:14,fontWeight:600,marginBottom:14 }}>Request Rate (last 60s)</h3>
        <ResponsiveContainer width="100%" height={160}>
          <BarChart data={traffic.slice(-30)} margin={{ top:0,right:0,left:-20,bottom:0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="second" tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v=>`${v}s`} />
            <YAxis tick={{ fontSize:10,fill:'var(--text-muted)' }} />
            <Tooltip formatter={(v,n)=>[v,n==='requests'?'Req/s':'Errors']} contentStyle={{ background:'var(--bg-card)',border:'1px solid var(--border)',borderRadius:8,fontSize:12 }}/>
            <Bar dataKey="requests" fill="var(--accent)" radius={[2,2,0,0]} opacity={0.8}/>
            <Bar dataKey="errors" fill="var(--accent-red)" radius={[2,2,0,0]}/>
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div style={{ display:'grid',gridTemplateColumns:'1.5fr 1fr',gap:16 }}>
        {/* Backend table */}
        <div className="card" style={{ padding:0,overflow:'hidden' }}>
          <div style={{ padding:'14px 18px',borderBottom:'1px solid var(--border)' }}>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Backends</h3>
          </div>
          <div style={{ overflowX:'auto' }}>
            <table style={{ width:'100%',borderCollapse:'collapse',fontSize:13 }}>
              <thead><tr style={{ background:'var(--bg-secondary)',borderBottom:'1px solid var(--border)' }}>
                {['Server','Provider','Health','Latency','CPU','Connections'].map(h=>(
                  <th key={h} style={{ padding:'8px 14px',textAlign:'left',fontSize:11,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.4px' }}>{h}</th>
                ))}
              </tr></thead>
              <tbody>
                {(status?.backends||[]).map(b=>(
                  <tr key={b.id} style={{ borderBottom:'1px solid var(--border)' }}>
                    <td style={{ padding:'10px 14px',fontWeight:500 }}>{b.name}</td>
                    <td style={{ padding:'10px 14px',color:'var(--text-muted)',fontSize:12 }}>{b.provider||'—'}</td>
                    <td style={{ padding:'10px 14px' }}>{b.healthy ? <span style={{ color:'var(--accent-green)',display:'flex',alignItems:'center',gap:4,fontSize:12 }}><CheckCircle size={12}/>Healthy</span> : <span style={{ color:'var(--accent-red)',display:'flex',alignItems:'center',gap:4,fontSize:12 }}><XCircle size={12}/>Down</span>}</td>
                    <td style={{ padding:'10px 14px',fontFamily:'var(--font-mono)',fontSize:12,color:b.latency>100?'var(--accent-red)':b.latency>50?'var(--accent-yellow)':'var(--accent-green)' }}>{b.latency?.toFixed(0)}ms</td>
                    <td style={{ padding:'10px 14px',fontFamily:'var(--font-mono)',fontSize:12 }}>{b.cpu}%</td>
                    <td style={{ padding:'10px 14px',fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-secondary)' }}>{b.connections}</td>
                  </tr>
                ))}
                {!(status?.backends?.length)&&<tr><td colSpan={6} style={{ padding:30,textAlign:'center',color:'var(--text-muted)' }}>No backends available</td></tr>}
              </tbody>
            </table>
          </div>
        </div>

        {/* Config panel */}
        <div className="card">
          <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16 }}>
            <h3 style={{ fontSize:14,fontWeight:600,display:'flex',alignItems:'center',gap:6 }}><Settings2 size={14}/>Config</h3>
            <button className="btn btn-ghost btn-sm" onClick={()=>setEditing(!editing)}>{editing?'Cancel':'Edit'}</button>
          </div>
          <div style={{ display:'flex',flexDirection:'column',gap:12 }}>
            {[
              { key:'algorithm', label:'Algorithm', type:'select', options:['round-robin','least-connections','ip-hash','random','weighted'] },
              { key:'connectionTimeout', label:'Connection Timeout (s)', type:'number' },
              { key:'idleTimeout', label:'Idle Timeout (s)', type:'number' },
              { key:'maxConnections', label:'Max Connections', type:'number' }
            ].map(f=>(
              <div key={f.key}>
                <label style={{ fontSize:11,color:'var(--text-muted)',display:'block',marginBottom:4 }}>{f.label}</label>
                {editing ? (
                  f.type==='select' ? (
                    <select value={editConfig[f.key]||''} onChange={e=>setEditConfig({...editConfig,[f.key]:e.target.value})} style={{ width:'100%',fontSize:13,padding:'6px 8px' }}>
                      {f.options.map(o=><option key={o} value={o}>{o}</option>)}
                    </select>
                  ) : (
                    <input type="number" value={editConfig[f.key]||''} onChange={e=>setEditConfig({...editConfig,[f.key]:parseInt(e.target.value)})} style={{ width:'100%',fontSize:13 }}/>
                  )
                ) : (
                  <div style={{ fontFamily:'var(--font-mono)',fontSize:13,color:'var(--text-primary)',padding:'6px 0' }}>{config?.[f.key]||'—'}</div>
                )}
              </div>
            ))}
            <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
              <span style={{ fontSize:12,color:'var(--text-muted)' }}>Health checks</span>
              <span className="badge active"><CheckCircle size={10}/>Enabled</span>
            </div>
            {editing && <button className="btn btn-primary" style={{ width:'100%',justifyContent:'center' }} onClick={handleSave}>Save Config</button>}
          </div>
        </div>
      </div>
    </div>
  );
}
