import React, { useState } from 'react';
import api from '../services/api';
import { User, Key, Bell, Save, Shield } from 'lucide-react';
import toast from 'react-hot-toast';

export default function Profile() {
  const user = (() => { try { return JSON.parse(localStorage.getItem('ha_user')||'{}'); } catch { return {}; } })();
  const [form, setForm] = useState({ firstName:user.firstName||'', lastName:user.lastName||'', email:user.email||'' });
  const [pwForm, setPwForm] = useState({ current:'', newPw:'', confirm:'' });

  const handleSave = () => toast.success('Profile updated successfully');
  const handlePwChange = () => {
    if (pwForm.newPw !== pwForm.confirm) { toast.error('Passwords do not match'); return; }
    if (pwForm.newPw.length < 8) { toast.error('Password must be at least 8 characters'); return; }
    toast.success('Password changed successfully');
    setPwForm({ current:'', newPw:'', confirm:'' });
  };

  const F = ({label, value, field, type='text', form:f, setForm:sf}) => (
    <div style={{marginBottom:14}}>
      <label style={{fontSize:12,color:'var(--text-muted)',display:'block',marginBottom:5}}>{label}</label>
      <input type={type} value={f[field]||''} onChange={e=>sf({...f,[field]:e.target.value})} style={{width:'100%',fontSize:13}}/>
    </div>
  );

  return (
    <div style={{display:'flex',flexDirection:'column',gap:20,maxWidth:700}}>
      <div><h1 style={{fontSize:22,fontWeight:700}}>Profile</h1><p style={{fontSize:13,color:'var(--text-muted)',marginTop:2}}>Manage your account settings</p></div>

      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:16}}>
        <div className="card">
          <h3 style={{fontSize:14,fontWeight:600,marginBottom:16,display:'flex',alignItems:'center',gap:6}}><User size={14}/>Personal Info</h3>
          <F label="First Name"  field="firstName" form={form} setForm={setForm}/>
          <F label="Last Name"   field="lastName"  form={form} setForm={setForm}/>
          <F label="Email"       field="email"     form={form} setForm={setForm} type="email"/>
          <div style={{marginBottom:14}}>
            <label style={{fontSize:12,color:'var(--text-muted)',display:'block',marginBottom:5}}>Role</label>
            <div style={{fontFamily:'var(--font-mono)',fontSize:13,padding:'8px 12px',background:'var(--bg-secondary)',borderRadius:'var(--radius)',color:'var(--accent)',border:'1px solid var(--border)',textTransform:'capitalize'}}>{user.role||'viewer'}</div>
          </div>
          <button className="btn btn-primary btn-sm" onClick={handleSave} style={{width:'100%',justifyContent:'center'}}><Save size={12}/>Save Changes</button>
        </div>

        <div className="card">
          <h3 style={{fontSize:14,fontWeight:600,marginBottom:16,display:'flex',alignItems:'center',gap:6}}><Key size={14}/>Change Password</h3>
          <F label="Current Password" field="current" form={pwForm} setForm={setPwForm} type="password"/>
          <F label="New Password"     field="newPw"   form={pwForm} setForm={setPwForm} type="password"/>
          <F label="Confirm Password" field="confirm" form={pwForm} setForm={setPwForm} type="password"/>
          <div style={{background:'var(--accent-dim)',border:'1px solid rgba(0,212,255,0.2)',borderRadius:8,padding:10,marginBottom:12,fontSize:12,color:'var(--accent)'}}>
            <Shield size={11} style={{display:'inline',marginRight:4}}/>Min 8 chars, mix of letters, numbers and symbols
          </div>
          <button className="btn btn-secondary btn-sm" onClick={handlePwChange} style={{width:'100%',justifyContent:'center'}}><Key size={12}/>Update Password</button>
        </div>
      </div>

      <div className="card">
        <h3 style={{fontSize:14,fontWeight:600,marginBottom:14,display:'flex',alignItems:'center',gap:6}}><Bell size={14}/>Notification Preferences</h3>
        <div style={{display:'flex',flexDirection:'column',gap:12}}>
          {[
            {label:'Critical alerts',       desc:'Immediate notification for critical/emergency events', on:true},
            {label:'Failover events',        desc:'Notify when automatic failover is triggered',          on:true},
            {label:'Auto-scaling events',    desc:'Notify on scale up/down',                             on:false},
            {label:'Weekly digest',          desc:'Sunday summary of infrastructure health',              on:true},
          ].map((p,i) => (
            <div key={i} style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'10px 0',borderBottom:'1px solid var(--border)'}}>
              <div><div style={{fontSize:13,fontWeight:500}}>{p.label}</div><div style={{fontSize:11,color:'var(--text-muted)',marginTop:2}}>{p.desc}</div></div>
              <div style={{width:40,height:22,borderRadius:11,background:p.on?'var(--accent-green)':'var(--border)',position:'relative',cursor:'pointer',flexShrink:0,transition:'background 0.2s'}}>
                <div style={{width:16,height:16,borderRadius:'50%',background:'#fff',position:'absolute',top:3,left:p.on?21:3,transition:'left 0.2s'}}/>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
