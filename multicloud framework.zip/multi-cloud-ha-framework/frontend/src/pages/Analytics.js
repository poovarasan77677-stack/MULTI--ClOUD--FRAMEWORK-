import React, { useState, useEffect } from 'react';
import { metricsApi } from '../services/api';
import { TrendingUp, TrendingDown, DollarSign, Activity, Cpu, BarChart2, RefreshCw } from 'lucide-react';
import {
  AreaChart, Area, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer, RadarChart, Radar, PolarGrid,
  PolarAngleAxis, PolarRadiusAxis, Legend
} from 'recharts';

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'var(--bg-card)',border:'1px solid var(--border)',borderRadius:8,padding:'10px 14px',fontSize:12 }}>
      <div style={{ color:'var(--text-muted)',marginBottom:6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color:p.color,display:'flex',gap:8,marginBottom:2 }}>
          <span style={{ color:'var(--text-secondary)' }}>{p.name}:</span>
          <span style={{ fontFamily:'var(--font-mono)',fontWeight:600 }}>
            {typeof p.value === 'number' ? p.value.toFixed(1) : p.value}
          </span>
        </div>
      ))}
    </div>
  );
};

export default function Analytics() {
  const [timeseries, setTimeseries] = useState([]);
  const [costs, setCosts] = useState(null);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [ts, c] = await Promise.all([metricsApi.getTimeseries(), metricsApi.getCosts()]);
      setTimeseries(ts.data || []);
      setCosts(c);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  // Compute SLO data for radar chart
  const sloData = [
    { metric: 'Uptime', value: 99.8, target: 99.9 },
    { metric: 'Latency', value: 85,  target: 90 },
    { metric: 'Error Rate', value: 92, target: 95 },
    { metric: 'Throughput', value: 78, target: 85 },
    { metric: 'Recovery', value: 88,  target: 90 },
    { metric: 'Availability', value: 96, target: 99 }
  ];

  const costByDay = Array.from({ length: 30 }, (_, i) => ({
    day: `Day ${i+1}`,
    aws:   (1728/30 + (Math.random()-0.5)*20).toFixed(2)*1,
    azure: (1512/30 + (Math.random()-0.5)*15).toFixed(2)*1,
    gcp:   (1404/30 + (Math.random()-0.5)*15).toFixed(2)*1,
    do:    (640/30  + (Math.random()-0.5)*8 ).toFixed(2)*1
  }));

  const availabilityData = Array.from({ length: 12 }, (_, i) => ({
    month: ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][i],
    uptime: 99.5 + Math.random() * 0.49,
    incidents: Math.floor(Math.random() * 4)
  }));

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Analytics & Insights</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Performance trends, cost analysis and SLO tracking</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={fetchData}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
      </div>

      {/* KPIs */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {[
          { label:'Avg Uptime (30d)', value:'99.78%', trend:+0.02, color:'var(--accent-green)', icon:Activity },
          { label:'Avg Latency',  value:'23ms',  trend:-4.1,  color:'var(--accent)',       icon:TrendingDown },
          { label:'Monthly Cost', value:'$5,285', trend:+2.3, color:'var(--accent-yellow)',icon:DollarSign },
          { label:'Incidents (30d)', value:'3',  trend:-40,   color:'var(--accent-green)', icon:TrendingDown }
        ].map(k => (
          <div key={k.label} className="card glow" style={{ padding:16 }}>
            <div style={{ display:'flex',justifyContent:'space-between',alignItems:'flex-start' }}>
              <div>
                <div style={{ fontSize:11,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.5px',marginBottom:6 }}>{k.label}</div>
                <div style={{ fontFamily:'var(--font-mono)',fontSize:26,fontWeight:700,color:k.color,lineHeight:1 }}>{k.value}</div>
                <div style={{ fontSize:11,marginTop:6,color:k.trend < 0 ? 'var(--accent-green)':'var(--accent-red)',display:'flex',alignItems:'center',gap:3 }}>
                  {k.trend < 0 ? <TrendingDown size={11}/> : <TrendingUp size={11}/>}
                  {Math.abs(k.trend)}% vs last month
                </div>
              </div>
              <div style={{ width:36,height:36,background:`${k.color}15`,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',color:k.color }}>
                <k.icon size={18}/>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cost & CPU charts */}
      <div style={{ display:'grid',gridTemplateColumns:'1.5fr 1fr',gap:16 }}>
        <div className="card">
          <div style={{ marginBottom:14 }}>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Daily Cost Breakdown (30d)</h3>
            <p style={{ fontSize:11,color:'var(--text-muted)' }}>Spend per cloud provider per day</p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={costByDay.slice(-14)} margin={{ top:0,right:0,left:-15,bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="day" tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v=>v.replace('Day ','')} />
              <YAxis tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v=>`$${v}`} />
              <Tooltip content={<CustomTooltip />} />
              <Legend iconSize={10} wrapperStyle={{ fontSize:11 }} />
              <Bar dataKey="aws"   name="AWS"          fill="#ff9900" stackId="a" radius={[0,0,0,0]} />
              <Bar dataKey="azure" name="Azure"        fill="#0078d4" stackId="a" />
              <Bar dataKey="gcp"   name="GCP"          fill="#4285f4" stackId="a" />
              <Bar dataKey="do"    name="DigitalOcean" fill="#0080ff" stackId="a" radius={[2,2,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* SLO Radar */}
        <div className="card">
          <div style={{ marginBottom:14 }}>
            <h3 style={{ fontSize:14,fontWeight:600 }}>SLO Compliance</h3>
            <p style={{ fontSize:11,color:'var(--text-muted)' }}>Actual vs target service levels</p>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <RadarChart data={sloData} margin={{ top:0,right:20,left:20,bottom:0 }}>
              <PolarGrid stroke="var(--border)" />
              <PolarAngleAxis dataKey="metric" tick={{ fontSize:10,fill:'var(--text-secondary)' }} />
              <PolarRadiusAxis angle={30} domain={[60,100]} tick={{ fontSize:9,fill:'var(--text-muted)' }} />
              <Radar name="Actual" dataKey="value" stroke="var(--accent)" fill="var(--accent)" fillOpacity={0.15} strokeWidth={2} />
              <Radar name="Target" dataKey="target" stroke="var(--accent-green)" fill="var(--accent-green)" fillOpacity={0.08} strokeWidth={1.5} strokeDasharray="4 2" />
              <Legend iconSize={10} wrapperStyle={{ fontSize:11 }} />
            </RadarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* CPU / Memory trend */}
      <div className="card">
        <div style={{ marginBottom:14,display:'flex',justifyContent:'space-between',alignItems:'center' }}>
          <div>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Resource Utilization Trends (24h)</h3>
            <p style={{ fontSize:11,color:'var(--text-muted)' }}>Hourly CPU and memory across all providers</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={200}>
          <AreaChart data={timeseries} margin={{ top:0,right:0,left:-18,bottom:0 }}>
            <defs>
              <linearGradient id="cpuG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent)" stopOpacity={0.25}/>
                <stop offset="95%" stopColor="var(--accent)" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="memG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent-purple)" stopOpacity={0.25}/>
                <stop offset="95%" stopColor="var(--accent-purple)" stopOpacity={0}/>
              </linearGradient>
              <linearGradient id="errG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="var(--accent-red)" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="var(--accent-red)" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="timestamp" tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v=>new Date(v).getHours()+'h'} />
            <YAxis tick={{ fontSize:10,fill:'var(--text-muted)' }} domain={[0,100]} />
            <Tooltip content={<CustomTooltip />} />
            <Legend iconSize={10} wrapperStyle={{ fontSize:11 }} />
            <Area type="monotone" dataKey="cpu"    name="CPU %"    stroke="var(--accent)"        fill="url(#cpuG)" strokeWidth={2} />
            <Area type="monotone" dataKey="memory" name="Memory %"  stroke="var(--accent-purple)" fill="url(#memG)" strokeWidth={2} />
            <Area type="monotone" dataKey="errors" name="Errors"    stroke="var(--accent-red)"    fill="url(#errG)" strokeWidth={1.5} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Availability history */}
      <div className="card">
        <div style={{ marginBottom:14 }}>
          <h3 style={{ fontSize:14,fontWeight:600 }}>Monthly Availability & Incidents (12m)</h3>
          <p style={{ fontSize:11,color:'var(--text-muted)' }}>Uptime percentage and incident count per month</p>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={availabilityData} margin={{ top:0,right:0,left:-15,bottom:0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="month" tick={{ fontSize:11,fill:'var(--text-muted)' }} />
            <YAxis yAxisId="left"  tick={{ fontSize:10,fill:'var(--text-muted)' }} domain={[99,100]} tickFormatter={v=>`${v}%`} />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize:10,fill:'var(--text-muted)' }} />
            <Tooltip content={<CustomTooltip />} />
            <Legend iconSize={10} wrapperStyle={{ fontSize:11 }} />
            <Bar yAxisId="left"  dataKey="uptime"    name="Uptime %"  fill="var(--accent-green)" radius={[3,3,0,0]} opacity={0.8} />
            <Bar yAxisId="right" dataKey="incidents" name="Incidents"  fill="var(--accent-red)"   radius={[3,3,0,0]} opacity={0.7} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Cost optimization table */}
      <div className="card" style={{ padding:0,overflow:'hidden' }}>
        <div style={{ padding:'14px 20px',borderBottom:'1px solid var(--border)',display:'flex',justifyContent:'space-between',alignItems:'center' }}>
          <h3 style={{ fontSize:14,fontWeight:600 }}>Cost Optimization Recommendations</h3>
          <span className="badge info">AI-powered</span>
        </div>
        <table style={{ width:'100%',borderCollapse:'collapse',fontSize:13 }}>
          <thead>
            <tr style={{ background:'var(--bg-secondary)',borderBottom:'1px solid var(--border)' }}>
              {['Recommendation','Provider','Est. Savings/mo','Impact','Priority'].map(h=>(
                <th key={h} style={{ padding:'9px 16px',textAlign:'left',fontSize:11,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.4px' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              { rec:'Right-size 3 over-provisioned instances',        provider:'AWS',          saving:'$312',  impact:'Low',    priority:'high'   },
              { rec:'Enable Reserved Instances (1yr) for base load',  provider:'AWS + Azure',  saving:'$680',  impact:'None',   priority:'high'   },
              { rec:'Move dev workloads to spot/preemptible VMs',     provider:'GCP',          saving:'$185',  impact:'Medium', priority:'medium' },
              { rec:'Delete 2 idle EBS volumes (>30d no activity)',    provider:'AWS',          saving:'$48',   impact:'None',   priority:'low'    },
              { rec:'Enable S3 Intelligent-Tiering for backup bucket', provider:'AWS',          saving:'$94',   impact:'None',   priority:'medium' },
              { rec:'Switch DO Droplet to smaller tier after scale-down', provider:'DigitalOcean', saving:'$120', impact:'Low', priority:'low'  }
            ].map((r, i) => (
              <tr key={i} style={{ borderBottom:'1px solid var(--border)' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <td style={{ padding:'11px 16px',color:'var(--text-primary)' }}>{r.rec}</td>
                <td style={{ padding:'11px 16px',color:'var(--text-secondary)',fontFamily:'var(--font-mono)',fontSize:12 }}>{r.provider}</td>
                <td style={{ padding:'11px 16px',color:'var(--accent-green)',fontFamily:'var(--font-mono)',fontWeight:600 }}>{r.saving}</td>
                <td style={{ padding:'11px 16px' }}>
                  <span style={{ fontSize:11,padding:'2px 8px',borderRadius:20,background:r.impact==='None'?'var(--accent-green-dim)':r.impact==='Low'?'var(--accent-dim)':'var(--accent-yellow-dim)',color:r.impact==='None'?'var(--accent-green)':r.impact==='Low'?'var(--accent)':'var(--accent-yellow)' }}>{r.impact} Risk</span>
                </td>
                <td style={{ padding:'11px 16px' }}>
                  <span className={`badge ${r.priority==='high'?'critical':r.priority==='medium'?'warning':'info'}`}>{r.priority}</span>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr style={{ background:'var(--bg-secondary)',borderTop:'1px solid var(--border)' }}>
              <td colSpan={2} style={{ padding:'11px 16px',fontWeight:600,color:'var(--text-primary)' }}>Total Potential Savings</td>
              <td style={{ padding:'11px 16px',color:'var(--accent-green)',fontFamily:'var(--font-mono)',fontWeight:700,fontSize:15 }}>$1,439/mo</td>
              <td colSpan={2} style={{ padding:'11px 16px',fontSize:12,color:'var(--text-muted)' }}>~$17,268/year</td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
