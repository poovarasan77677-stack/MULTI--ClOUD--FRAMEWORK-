import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import toast from 'react-hot-toast';
import { Activity, Eye, EyeOff, Lock, Mail, Zap, Shield, Cloud, Server } from 'lucide-react';

const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function Login() {
  const navigate = useNavigate();
  const [form, setForm]         = useState({ email: '', password: '' });
  const [loading, setLoading]   = useState(false);
  const [showPass, setShowPass] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.error('Please fill in all fields'); return; }
    setLoading(true);
    try {
      const { data } = await axios.post(`${BASE_URL}/auth/login`, form);
      localStorage.setItem('ha_token', data.token);
      localStorage.setItem('ha_user', JSON.stringify(data.user));
      toast.success(`Welcome back, ${data.user.firstName || data.user.username}!`);
      navigate('/dashboard');
    } catch (err) {
      const msg = err.response?.data?.error || 'Login failed';
      toast.error(msg);
    } finally {
      setLoading(false);
    }
  };

  const quickLogin = async (email, password) => {
    setForm({ email, password });
    setLoading(true);
    try {
      // Seed first in case it's fresh
      await axios.post(`${BASE_URL}/auth/seed`).catch(() => {});
      const { data } = await axios.post(`${BASE_URL}/auth/login`, { email, password });
      localStorage.setItem('ha_token', data.token);
      localStorage.setItem('ha_user', JSON.stringify(data.user));
      toast.success('Logged in as ' + (data.user.role));
      navigate('/dashboard');
    } catch {
      toast.error('Quick login failed — is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', background: 'var(--bg-primary)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20, position: 'relative', overflow: 'hidden'
    }}>
      {/* Background grid pattern */}
      <div style={{
        position: 'absolute', inset: 0, opacity: 0.04,
        backgroundImage: 'linear-gradient(var(--border) 1px, transparent 1px), linear-gradient(90deg, var(--border) 1px, transparent 1px)',
        backgroundSize: '40px 40px'
      }}/>

      {/* Glow blobs */}
      <div style={{ position:'absolute', top:'20%', left:'15%', width:300, height:300, background:'rgba(0,212,255,0.06)', borderRadius:'50%', filter:'blur(80px)', pointerEvents:'none' }}/>
      <div style={{ position:'absolute', bottom:'20%', right:'15%', width:250, height:250, background:'rgba(168,85,247,0.06)', borderRadius:'50%', filter:'blur(80px)', pointerEvents:'none' }}/>

      <div style={{ width: '100%', maxWidth: 420, position: 'relative' }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 56, height: 56, margin: '0 auto 16px',
            background: 'linear-gradient(135deg, var(--accent), var(--accent-purple))',
            borderRadius: 14, display: 'flex', alignItems: 'center', justifyContent: 'center',
            boxShadow: '0 0 32px rgba(0,212,255,0.25)'
          }}>
            <Activity size={28} color="#fff"/>
          </div>
          <h1 style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 700, color: 'var(--text-primary)', letterSpacing: '-0.5px' }}>
            Multi-Cloud <span style={{ color: 'var(--accent)' }}>HA</span> Framework
          </h1>
          <p style={{ color: 'var(--text-muted)', fontSize: 13, marginTop: 6 }}>
            High Availability Infrastructure Management
          </p>
        </div>

        {/* Login Card */}
        <div className="card" style={{ padding: 28, boxShadow: '0 8px 40px rgba(0,0,0,0.5)' }}>
          <h2 style={{ fontSize: 16, fontWeight: 600, marginBottom: 20, color: 'var(--text-primary)' }}>Sign In</h2>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 14 }}>
              <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Email Address</label>
              <div style={{ position: 'relative' }}>
                <Mail size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }}/>
                <input
                  type="email" value={form.email} autoComplete="email"
                  onChange={e => setForm({ ...form, email: e.target.value })}
                  placeholder="admin@multicloud-ha.io"
                  style={{ width: '100%', paddingLeft: 36, fontSize: 13, height: 40 }}
                />
              </div>
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: 12, color: 'var(--text-muted)', display: 'block', marginBottom: 6 }}>Password</label>
              <div style={{ position: 'relative' }}>
                <Lock size={14} style={{ position: 'absolute', left: 12, top: '50%', transform: 'translateY(-50%)', color: 'var(--text-muted)' }}/>
                <input
                  type={showPass ? 'text' : 'password'} value={form.password} autoComplete="current-password"
                  onChange={e => setForm({ ...form, password: e.target.value })}
                  placeholder="••••••••"
                  style={{ width: '100%', paddingLeft: 36, paddingRight: 40, fontSize: 13, height: 40 }}
                />
                <button type="button" onClick={() => setShowPass(!showPass)} style={{
                  position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
                  background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', padding: 0
                }}>
                  {showPass ? <EyeOff size={14}/> : <Eye size={14}/>}
                </button>
              </div>
            </div>

            <button type="submit" disabled={loading} className="btn btn-primary" style={{ width: '100%', justifyContent: 'center', height: 40, fontSize: 14 }}>
              {loading ? <><span className="spin" style={{ display:'inline-block', width:14, height:14, border:'2px solid rgba(0,0,0,0.3)', borderTopColor:'#000', borderRadius:'50%' }}/> Signing in...</> : 'Sign In'}
            </button>
          </form>

          <div style={{ margin: '20px 0', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }}/>
            <span style={{ fontSize: 11, color: 'var(--text-muted)', whiteSpace: 'nowrap' }}>DEMO ACCOUNTS</span>
            <div style={{ flex: 1, height: 1, background: 'var(--border)' }}/>
          </div>

          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { label: 'Admin', email: 'admin@multicloud-ha.io', password: 'Admin@1234', icon: Shield, color: 'var(--accent-red)' },
              { label: 'Operator', email: 'operator@multicloud-ha.io', password: 'Operator@1234', icon: Cloud, color: 'var(--accent)' },
              { label: 'Viewer', email: 'viewer@multicloud-ha.io', password: 'Viewer@1234', icon: Server, color: 'var(--accent-green)' }
            ].map(acc => (
              <button key={acc.label} disabled={loading}
                onClick={() => quickLogin(acc.email, acc.password)}
                style={{
                  flex: 1, padding: '8px 6px', background: 'var(--bg-secondary)',
                  border: `1px solid ${acc.color}30`, borderRadius: 8, cursor: 'pointer',
                  color: acc.color, fontSize: 11, fontWeight: 600, display: 'flex',
                  flexDirection: 'column', alignItems: 'center', gap: 4,
                  transition: 'all 0.2s'
                }}
                onMouseEnter={e => e.currentTarget.style.background = `${acc.color}10`}
                onMouseLeave={e => e.currentTarget.style.background = 'var(--bg-secondary)'}
              >
                <acc.icon size={14}/>{acc.label}
              </button>
            ))}
          </div>
        </div>

        {/* Feature badges */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: 16, marginTop: 20, flexWrap: 'wrap' }}>
          {[
            { icon: Zap, label: 'Auto Failover' },
            { icon: Shield, label: 'JWT Auth' },
            { icon: Activity, label: 'Live Metrics' }
          ].map(f => (
            <div key={f.label} style={{ display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: 'var(--text-muted)' }}>
              <f.icon size={11} style={{ color: 'var(--accent)' }}/>{f.label}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
