import React, { useState } from 'react';
import { Settings, Save, RefreshCw, Shield, Bell, Cloud, Database, Key, ChevronRight } from 'lucide-react';
import toast from 'react-hot-toast';

const sections = [
  { id:'general', label:'General', icon:Settings },
  { id:'notifications', label:'Notifications', icon:Bell },
  { id:'security', label:'Security', icon:Shield },
  { id:'providers', label:'Cloud Providers', icon:Cloud },
  { id:'database', label:'Database', icon:Database },
  { id:'api', label:'API Keys', icon:Key }
];

export default function Settings() {
  const [active, setActive] = useState('general');
  const [settings, setSettings] = useState({
    refreshInterval: 30, theme:'dark', timezone:'UTC', logLevel:'info',
    slackWebhook:'', emailAlerts:true, alertEmail:'ops@company.com',
    pagerdutyKey:'', criticalOnly:false,
    sessionTimeout:24, requireMFA:false, allowedIPs:'',
    mongoUri:'mongodb://localhost:27017/multicloud_ha',
    redisUrl:'redis://localhost:6379', backupEnabled:true, backupInterval:24
  });

  const handleSave = () => toast.success('Settings saved successfully');

  const Field = ({ label, desc, type='text', value, field, options }) => (
    <div style={{ display:'flex',flexDirection:'column',gap:6,padding:'14px 0',borderBottom:'1px solid var(--border)' }}>
      <div style={{ display:'flex',justifyContent:'space-between',alignItems:'center' }}>
        <div>
          <div style={{ fontSize:13,fontWeight:500,color:'var(--text-primary)' }}>{label}</div>
          {desc && <div style={{ fontSize:11,color:'var(--text-muted)',marginTop:2 }}>{desc}</div>}
        </div>
        {type==='toggle' ? (
          <button onClick={()=>setSettings({...settings,[field]:!settings[field]})}
            style={{ width:44,height:24,borderRadius:12,background:settings[field]?'var(--accent-green)':'var(--border)',border:'none',cursor:'pointer',position:'relative',transition:'background 0.2s' }}>
            <div style={{ width:18,height:18,borderRadius:'50%',background:'#fff',position:'absolute',top:3,left:settings[field]?23:3,transition:'left 0.2s' }}/>
          </button>
        ) : type==='select' ? (
          <select value={settings[field]} onChange={e=>setSettings({...settings,[field]:e.target.value})} style={{ fontSize:13,padding:'5px 8px' }}>
            {options.map(o=><option key={o} value={o}>{o}</option>)}
          </select>
        ) : (
          <input type={type} value={settings[field]||''} onChange={e=>setSettings({...settings,[field]:e.target.type==='number'?parseInt(e.target.value):e.target.value})}
            style={{ fontSize:13,width:220 }} placeholder={desc}/>
        )}
      </div>
    </div>
  );

  const content = {
    general: (<>
      <Field label="Data Refresh Interval" desc="How often to poll for updates (seconds)" type="number" field="refreshInterval" />
      <Field label="Timezone" desc="Dashboard timezone display" type="select" field="timezone" options={['UTC','America/New_York','America/Los_Angeles','Europe/London','Asia/Tokyo','Asia/Kolkata']} />
      <Field label="Log Level" desc="Application logging verbosity" type="select" field="logLevel" options={['debug','info','warn','error']} />
      <Field label="Dark Theme" desc="Use dark color scheme" type="toggle" field="theme" />
    </>),
    notifications: (<>
      <Field label="Email Alerts" desc="Send alerts via email" type="toggle" field="emailAlerts" />
      <Field label="Alert Email" desc="Destination email for alerts" field="alertEmail" />
      <Field label="Slack Webhook" desc="Slack incoming webhook URL" field="slackWebhook" />
      <Field label="PagerDuty API Key" desc="PagerDuty integration key" field="pagerdutyKey" />
      <Field label="Critical Only" desc="Only notify on critical/emergency alerts" type="toggle" field="criticalOnly" />
    </>),
    security: (<>
      <Field label="Session Timeout" desc="Token expiry in hours" type="number" field="sessionTimeout" />
      <Field label="Require MFA" desc="Enforce multi-factor authentication" type="toggle" field="requireMFA" />
      <Field label="Allowed IP Ranges" desc="Comma-separated CIDR ranges (empty = any)" field="allowedIPs" />
    </>),
    providers: (
      <div style={{ padding:'16px 0' }}>
        <p style={{ fontSize:13,color:'var(--text-secondary)',marginBottom:16 }}>Cloud provider credentials are managed securely. Use environment variables or Kubernetes secrets in production.</p>
        {['AWS','Azure','GCP','DigitalOcean'].map(name=>(
          <div key={name} style={{ display:'flex',alignItems:'center',justifyContent:'space-between',padding:'12px',background:'var(--bg-secondary)',borderRadius:8,marginBottom:8 }}>
            <span style={{ fontWeight:500 }}>{name}</span>
            <div style={{ display:'flex',gap:8 }}>
              <span className="badge active">Configured</span>
              <button className="btn btn-ghost btn-sm">Edit <ChevronRight size={12}/></button>
            </div>
          </div>
        ))}
      </div>
    ),
    database: (<>
      <Field label="MongoDB URI" desc="Primary database connection string" field="mongoUri" />
      <Field label="Redis URL" desc="Cache/session store URL" field="redisUrl" />
      <Field label="Enable Backups" desc="Automated database backups" type="toggle" field="backupEnabled" />
      <Field label="Backup Interval" desc="Hours between backups" type="number" field="backupInterval" />
    </>),
    api: (
      <div style={{ padding:'16px 0' }}>
        <p style={{ fontSize:13,color:'var(--text-secondary)',marginBottom:16 }}>API keys for programmatic access. Treat these like passwords.</p>
        <div style={{ fontFamily:'var(--font-mono)',fontSize:12,background:'var(--bg-secondary)',padding:14,borderRadius:8,color:'var(--accent)',marginBottom:12,wordBreak:'break-all' }}>
          eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.demo-key-not-for-production...
        </div>
        <button className="btn btn-secondary btn-sm"><Key size={12}/>Generate New Key</button>
      </div>
    )
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div>
        <h1 style={{ fontSize:22,fontWeight:700 }}>Settings</h1>
        <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Configure system preferences and integrations</p>
      </div>
      <div style={{ display:'grid',gridTemplateColumns:'200px 1fr',gap:16,alignItems:'start' }}>
        <div className="card" style={{ padding:8 }}>
          {sections.map(s=>(
            <button key={s.id} onClick={()=>setActive(s.id)}
              style={{ width:'100%',display:'flex',alignItems:'center',gap:10,padding:'9px 12px',borderRadius:6,background:active===s.id?'var(--accent-dim)':'transparent',color:active===s.id?'var(--accent)':'var(--text-secondary)',fontSize:13,fontWeight:active===s.id?600:400,transition:'all var(--transition)',border:'none',cursor:'pointer',textAlign:'left' }}>
              <s.icon size={14}/>{s.label}
            </button>
          ))}
        </div>
        <div className="card">
          <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:8,paddingBottom:14,borderBottom:'1px solid var(--border)' }}>
            <h3 style={{ fontSize:15,fontWeight:600 }}>{sections.find(s=>s.id===active)?.label}</h3>
            <button className="btn btn-primary btn-sm" onClick={handleSave}><Save size={12}/>Save</button>
          </div>
          {content[active]}
        </div>
      </div>
    </div>
  );
}
