import React, { useState, useEffect } from 'react';
import { failoverApi, cloudApi } from '../services/api';
import { GitBranch, Play, RefreshCw, CheckCircle, XCircle, Clock, Activity, AlertTriangle } from 'lucide-react';
import { formatDistanceToNow, format } from 'date-fns';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';

const STATUS_COLORS = { completed:'var(--accent-green)',failed:'var(--accent-red)',in_progress:'var(--accent)',pending:'var(--accent-yellow)',rolled_back:'var(--accent-yellow)' };
const STATUS_ICONS = { completed:<CheckCircle size={14}/>,failed:<XCircle size={14}/>,in_progress:<Activity size={14} className="spin"/>,pending:<Clock size={14}/> };

export default function Failover() {
  const { state } = useApp();
  const { activeFailover } = state;
  const [events, setEvents] = useState([]);
  const [stats, setStats] = useState(null);
  const [providers, setProviders] = useState([]);
  const [form, setForm] = useState({ fromProviderId:'',toProviderId:'',reason:'' });
  const [loading, setLoading] = useState(true);
  const [triggering, setTriggering] = useState(false);
  const [selected, setSelected] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [e,s,p] = await Promise.all([failoverApi.getAll(), failoverApi.getStats(), cloudApi.getAll()]);
      setEvents(e.events||[]); setStats(s); setProviders(p.providers||[]);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchData(); }, []);

  const handleTrigger = async () => {
    if (!form.fromProviderId || !form.toProviderId) { toast.error('Select both source and target providers'); return; }
    if (form.fromProviderId === form.toProviderId) { toast.error('Source and target must differ'); return; }
    setTriggering(true);
    try {
      await failoverApi.trigger(form);
      toast.success('Failover initiated! Monitoring progress...');
      setForm({ fromProviderId:'',toProviderId:'',reason:'' });
      setTimeout(fetchData, 3000);
    } catch {} finally { setTriggering(false); }
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Failover Management</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Automatic & manual failover orchestration with real-time tracking</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={fetchData}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
      </div>

      {/* Active failover banner */}
      {activeFailover && (
        <div className="card" style={{ padding:16,background:'rgba(255,215,0,0.05)',border:'1px solid rgba(255,215,0,0.3)' }}>
          <div style={{ display:'flex',alignItems:'center',gap:10 }}>
            <GitBranch size={18} style={{ color:'var(--accent-yellow)' }} className="spin"/>
            <div>
              <div style={{ fontWeight:600,color:'var(--accent-yellow)' }}>Failover In Progress</div>
              <div style={{ fontSize:13,color:'var(--text-secondary)',marginTop:2 }}>
                Migrating traffic from <strong>{activeFailover.from}</strong> to <strong>{activeFailover.to}</strong>
              </div>
              <div style={{ fontSize:12,color:'var(--text-muted)',marginTop:2 }}>Reason: {activeFailover.reason}</div>
            </div>
          </div>
        </div>
      )}

      {/* Stats */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {[
          { label:'Total Events', value:stats?.total||0, color:'var(--text-primary)' },
          { label:'Completed', value:stats?.completed||0, color:'var(--accent-green)' },
          { label:'Failed', value:stats?.failed||0, color:'var(--accent-red)' },
          { label:'Avg Duration', value:stats?.avgDurationMs ? `${(stats.avgDurationMs/1000).toFixed(0)}s` : '—', color:'var(--accent)' }
        ].map(s=>(
          <div key={s.label} className="card" style={{ padding:14,textAlign:'center' }}>
            <div style={{ fontFamily:'var(--font-mono)',fontSize:24,fontWeight:700,color:s.color }}>{s.value}</div>
            <div style={{ fontSize:11,color:'var(--text-muted)',marginTop:3 }}>{s.label}</div>
            {s.label==='Total Events' && stats?.total>0 && <div style={{ fontSize:11,color:'var(--accent-green)',marginTop:2 }}>{stats.successRate}% success</div>}
          </div>
        ))}
      </div>

      <div style={{ display:'grid',gridTemplateColumns:'1fr 1.6fr',gap:16 }}>
        {/* Manual Trigger */}
        <div className="card">
          <h3 style={{ fontSize:14,fontWeight:600,marginBottom:16,display:'flex',alignItems:'center',gap:6 }}>
            <Play size={14} style={{ color:'var(--accent)' }}/>Manual Failover
          </h3>
          <div style={{ display:'flex',flexDirection:'column',gap:12 }}>
            <div>
              <label style={{ fontSize:12,color:'var(--text-muted)',display:'block',marginBottom:6 }}>Source Provider (failing)</label>
              <select value={form.fromProviderId} onChange={e=>setForm({...form,fromProviderId:e.target.value})} style={{ width:'100%',fontSize:13,padding:'8px 10px' }}>
                <option value="">Select source...</option>
                {providers.map(p=><option key={p._id} value={p._id}>{p.alias} ({p.name})</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize:12,color:'var(--text-muted)',display:'block',marginBottom:6 }}>Target Provider (failover to)</label>
              <select value={form.toProviderId} onChange={e=>setForm({...form,toProviderId:e.target.value})} style={{ width:'100%',fontSize:13,padding:'8px 10px' }}>
                <option value="">Select target...</option>
                {providers.filter(p=>p._id!==form.fromProviderId).map(p=><option key={p._id} value={p._id}>{p.alias} ({p.name})</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize:12,color:'var(--text-muted)',display:'block',marginBottom:6 }}>Reason (optional)</label>
              <input value={form.reason} onChange={e=>setForm({...form,reason:e.target.value})} placeholder="e.g. Scheduled maintenance" style={{ width:'100%',fontSize:13 }}/>
            </div>
            <div style={{ background:'rgba(255,64,96,0.06)',border:'1px solid rgba(255,64,96,0.15)',borderRadius:8,padding:10 }}>
              <div style={{ display:'flex',gap:6,fontSize:12,color:'var(--accent-red)' }}>
                <AlertTriangle size={13} style={{ marginTop:1,flexShrink:0 }}/>
                <span>This will reroute live traffic. Estimated downtime: 30–120 seconds.</span>
              </div>
            </div>
            <button className="btn btn-danger" onClick={handleTrigger} disabled={triggering||!form.fromProviderId||!form.toProviderId} style={{ width:'100%',justifyContent:'center' }}>
              {triggering ? <><RefreshCw size={14} className="spin"/>Initiating...</> : <><Play size={14}/>Trigger Failover</>}
            </button>
          </div>
        </div>

        {/* Events list */}
        <div className="card" style={{ padding:0,overflow:'hidden' }}>
          <div style={{ padding:'14px 18px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between' }}>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Failover History</h3>
            <span style={{ fontSize:12,color:'var(--text-muted)' }}>{events.length} events</span>
          </div>
          <div style={{ overflowY:'auto',maxHeight:420 }}>
            {events.map(ev=>(
              <div key={ev._id} className="fade-in" style={{ padding:'14px 18px',borderBottom:'1px solid var(--border)',cursor:'pointer',transition:'background var(--transition)' }}
                onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}
                onClick={()=>setSelected(selected?._id===ev._id?null:ev)}>
                <div style={{ display:'flex',alignItems:'center',gap:10,marginBottom:6 }}>
                  <span style={{ color:STATUS_COLORS[ev.status]||'var(--text-muted)' }}>{STATUS_ICONS[ev.status]||<Clock size={14}/>}</span>
                  <span style={{ fontWeight:600,fontSize:13 }}>{ev.fromProvider?.alias||'?'} → {ev.toProvider?.alias||'?'}</span>
                  <span className="badge" style={{ background:`${STATUS_COLORS[ev.status]||'var(--border)'}18`,color:STATUS_COLORS[ev.status]||'var(--text-muted)',border:'none',marginLeft:'auto' }}>{ev.status}</span>
                </div>
                <div style={{ fontSize:12,color:'var(--text-secondary)',marginBottom:4,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap' }}>{ev.reason}</div>
                <div style={{ display:'flex',gap:12,fontSize:11,color:'var(--text-muted)' }}>
                  <span>{ev.trigger}</span>
                  {ev.durationMs && <span><Clock size={10} style={{ display:'inline',verticalAlign:'middle' }}/> {(ev.durationMs/1000).toFixed(1)}s</span>}
                  <span>{ev.createdAt ? formatDistanceToNow(new Date(ev.createdAt),{addSuffix:true}) : ''}</span>
                </div>
                {selected?._id===ev._id && ev.steps && (
                  <div style={{ marginTop:12,display:'flex',flexDirection:'column',gap:4 }}>
                    {ev.steps.map((step,i)=>(
                      <div key={i} style={{ display:'flex',alignItems:'center',gap:8,fontSize:11 }}>
                        <span style={{ color:step.status==='completed'?'var(--accent-green)':step.status==='failed'?'var(--accent-red)':step.status==='running'?'var(--accent)':'var(--text-muted)',flexShrink:0 }}>
                          {step.status==='completed'?'✓':step.status==='failed'?'✗':step.status==='running'?'⟳':'○'}
                        </span>
                        <span style={{ color:step.status==='completed'?'var(--text-secondary)':'var(--text-muted)',flex:1 }}>{step.name}</span>
                        {step.durationMs && <span style={{ color:'var(--text-muted)',fontFamily:'var(--font-mono)' }}>{step.durationMs}ms</span>}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {events.length===0&&!loading&&<div style={{ padding:60,textAlign:'center',color:'var(--text-muted)' }}><GitBranch size={32} style={{ opacity:0.3,display:'block',margin:'0 auto 10px' }}/>No failover events recorded</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
