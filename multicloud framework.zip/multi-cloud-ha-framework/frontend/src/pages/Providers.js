import React, { useState, useEffect } from 'react';
import { cloudApi } from '../services/api';
import { Cloud, RefreshCw, Plus, Trash2, Edit, CheckCircle, XCircle, Activity, Cpu, DollarSign } from 'lucide-react';
import { useApp } from '../context/AppContext';
import toast from 'react-hot-toast';

const PROVIDER_COLORS = { aws:'#ff9900',azure:'#0078d4',gcp:'#4285f4',digitalocean:'#0080ff' };

export default function Providers() {
  const { state, fetchDashboard } = useApp();
  const { providers, loading } = state;
  const [selected, setSelected] = useState(null);

  const handleDelete = async (id, name) => {
    if (!window.confirm(`Delete provider "${name}"?`)) return;
    try { await cloudApi.delete(id); toast.success('Provider deleted'); fetchDashboard(); } catch {}
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Cloud Providers</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Manage and monitor your cloud infrastructure providers</p>
        </div>
        <div style={{ display:'flex',gap:8 }}>
          <button className="btn btn-ghost btn-sm" onClick={fetchDashboard}><RefreshCw size={13} className={loading?'spin':''} />Refresh</button>
        </div>
      </div>

      {/* Summary cards */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12 }}>
        {[
          { label:'Total Providers', value:providers.length, color:'var(--accent)' },
          { label:'Active', value:providers.filter(p=>p.status==='active').length, color:'var(--accent-green)' },
          { label:'Degraded', value:providers.filter(p=>p.status==='degraded').length, color:'var(--accent-yellow)' },
          { label:'Offline', value:providers.filter(p=>p.status==='offline').length, color:'var(--accent-red)' }
        ].map(s => (
          <div key={s.label} className="card" style={{ textAlign:'center',padding:16 }}>
            <div style={{ fontFamily:'var(--font-mono)',fontSize:28,fontWeight:700,color:s.color }}>{s.value}</div>
            <div style={{ fontSize:12,color:'var(--text-muted)',marginTop:4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Providers table */}
      <div className="card" style={{ padding:0,overflow:'hidden' }}>
        <div style={{ padding:'16px 20px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between' }}>
          <h3 style={{ fontSize:14,fontWeight:600 }}>All Providers</h3>
          <span style={{ fontSize:12,color:'var(--text-muted)' }}>{providers.length} providers</span>
        </div>
        <div style={{ overflowX:'auto' }}>
          <table style={{ width:'100%',borderCollapse:'collapse',fontSize:13 }}>
            <thead>
              <tr style={{ borderBottom:'1px solid var(--border)',background:'var(--bg-secondary)' }}>
                {['Provider','Region','Status','CPU','Memory','Uptime','Latency','Monthly Cost','Role','Actions'].map(h => (
                  <th key={h} style={{ padding:'10px 16px',textAlign:'left',fontSize:11,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.5px',whiteSpace:'nowrap' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {providers.map(p => (
                <tr key={p._id} style={{ borderBottom:'1px solid var(--border)',transition:'background var(--transition)' }}
                    onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
                    onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{ padding:'12px 16px' }}>
                    <div style={{ display:'flex',alignItems:'center',gap:10 }}>
                      <div style={{ width:32,height:32,background:`${PROVIDER_COLORS[p.name]||'#666'}18`,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',fontSize:16 }}>
                        {p.name==='aws'?'☁':p.name==='azure'?'⬡':p.name==='gcp'?'◉':'◈'}
                      </div>
                      <div>
                        <div style={{ fontWeight:600,color:'var(--text-primary)' }}>{p.alias}</div>
                        <div style={{ fontSize:11,color:'var(--text-muted)',textTransform:'uppercase' }}>{p.name}</div>
                      </div>
                    </div>
                  </td>
                  <td style={{ padding:'12px 16px',fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-secondary)' }}>{p.region}</td>
                  <td style={{ padding:'12px 16px' }}><span className={`badge ${p.status}`}><span className={`status-dot ${p.status}`}/>{p.status}</span></td>
                  <td style={{ padding:'12px 16px' }}>
                    <div style={{ display:'flex',alignItems:'center',gap:8 }}>
                      <div className="progress-bar" style={{ width:60,height:4 }}>
                        <div className="progress-bar-fill" style={{ width:`${p.metrics?.cpuUsage||0}%`,background:p.metrics?.cpuUsage>80?'var(--accent-red)':p.metrics?.cpuUsage>60?'var(--accent-yellow)':'var(--accent-green)' }}/>
                      </div>
                      <span style={{ fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-primary)',width:34 }}>{(p.metrics?.cpuUsage||0).toFixed(0)}%</span>
                    </div>
                  </td>
                  <td style={{ padding:'12px 16px' }}>
                    <div style={{ display:'flex',alignItems:'center',gap:8 }}>
                      <div className="progress-bar" style={{ width:60,height:4 }}>
                        <div className="progress-bar-fill info" style={{ width:`${p.metrics?.memoryUsage||0}%` }}/>
                      </div>
                      <span style={{ fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-primary)',width:34 }}>{(p.metrics?.memoryUsage||0).toFixed(0)}%</span>
                    </div>
                  </td>
                  <td style={{ padding:'12px 16px',fontFamily:'var(--font-mono)',fontSize:12,color:'var(--accent-green)' }}>{(p.metrics?.uptimePercentage||100).toFixed(2)}%</td>
                  <td style={{ padding:'12px 16px',fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-secondary)' }}>{(p.metrics?.latency||0).toFixed(0)}ms</td>
                  <td style={{ padding:'12px 16px',fontFamily:'var(--font-mono)',fontSize:12,color:'var(--accent-green)',fontWeight:600 }}>${(p.cost?.monthly||0).toFixed(0)}</td>
                  <td style={{ padding:'12px 16px' }}>
                    <div style={{ display:'flex',gap:4,flexWrap:'wrap' }}>
                      {p.isPrimary && <span className="badge info" style={{ fontSize:10 }}>PRIMARY</span>}
                      {p.isFailoverTarget && <span className="badge" style={{ fontSize:10,background:'rgba(168,85,247,0.15)',color:'var(--accent-purple)',border:'1px solid rgba(168,85,247,0.2)' }}>STANDBY</span>}
                    </div>
                  </td>
                  <td style={{ padding:'12px 16px' }}>
                    <button className="btn btn-danger btn-sm" onClick={() => handleDelete(p._id, p.alias)}><Trash2 size={12} /></button>
                  </td>
                </tr>
              ))}
              {providers.length === 0 && (
                <tr><td colSpan={10} style={{ padding:40,textAlign:'center',color:'var(--text-muted)' }}>
                  <Cloud size={32} style={{ opacity:0.3,marginBottom:8,display:'block',margin:'0 auto 8px' }}/>
                  No providers. Use "Seed Demo" button to load sample data.
                </td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
