import React, { useState, useEffect } from 'react';
import api from '../services/api';
import { Shield, RefreshCw, Clock, User, Activity } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const ACTION_COLORS = {
  login:'var(--accent-green)', login_failed:'var(--accent-red)', failover_triggered:'var(--accent-yellow)',
  failover_completed:'var(--accent-green)', server_terminated:'var(--accent-red)',
  scale_up:'var(--accent)', scale_down:'var(--accent-purple)', seed_executed:'var(--accent-yellow)',
  provider_deleted:'var(--accent-red)', alert_resolved:'var(--accent-green)'
};

export default function AuditLog() {
  const [logs, setLogs] = useState([]);
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ action: '', page: 1 });

  const fetchLogs = async () => {
    setLoading(true);
    try {
      const [l, s] = await Promise.all([
        api.get('/audit', { params: filter }),
        api.get('/audit/summary')
      ]);
      setLogs(l.logs || []); setSummary(s);
    } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchLogs(); }, [filter.action, filter.page]);

  return (
    <div style={{display:'flex',flexDirection:'column',gap:20}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <div>
          <h1 style={{fontSize:22,fontWeight:700}}>Audit Log</h1>
          <p style={{fontSize:13,color:'var(--text-muted)',marginTop:2}}>Complete action history — who did what, when</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={fetchLogs}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
      </div>

      {summary && (
        <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:12}}>
          {[{label:'Events (7d)',value:summary.total,color:'var(--text-primary)'},{label:'Failures',value:summary.failures,color:'var(--accent-red)'},{label:'Failovers',value:summary.failovers,color:'var(--accent-yellow)'},{label:'Top Action',value:summary.byAction?.[0]?._id?.replace(/_/g,' ')||'—',color:'var(--accent)'}].map(s=>(
            <div key={s.label} className="card" style={{padding:14,textAlign:'center'}}>
              <div style={{fontFamily:'var(--font-mono)',fontSize:22,fontWeight:700,color:s.color,textTransform:'capitalize'}}>{s.value}</div>
              <div style={{fontSize:11,color:'var(--text-muted)',marginTop:3}}>{s.label}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{display:'flex',gap:10}}>
        <select value={filter.action} onChange={e=>setFilter({...filter,action:e.target.value,page:1})} style={{fontSize:13,padding:'6px 10px'}}>
          <option value="">All Actions</option>
          {['login','login_failed','failover_triggered','failover_completed','server_terminated','scale_up','scale_down','seed_executed','provider_created','provider_deleted'].map(a=>(
            <option key={a} value={a}>{a.replace(/_/g,' ')}</option>
          ))}
        </select>
      </div>

      <div className="card" style={{padding:0,overflow:'hidden'}}>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:13}}>
            <thead><tr style={{background:'var(--bg-secondary)',borderBottom:'1px solid var(--border)'}}>
              {['Action','User','IP Address','Resource','Result','Time'].map(h=>(
                <th key={h} style={{padding:'9px 16px',textAlign:'left',fontSize:11,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.4px'}}>{h}</th>
              ))}
            </tr></thead>
            <tbody>
              {logs.map(log=>(
                <tr key={log._id} style={{borderBottom:'1px solid var(--border)'}}
                  onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
                  onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                  <td style={{padding:'10px 16px'}}>
                    <span style={{color:ACTION_COLORS[log.action]||'var(--text-secondary)',fontFamily:'var(--font-mono)',fontSize:12}}>{log.action?.replace(/_/g,' ')}</span>
                  </td>
                  <td style={{padding:'10px 16px',color:'var(--text-secondary)',fontSize:12}}>{log.username||'system'}</td>
                  <td style={{padding:'10px 16px',fontFamily:'var(--font-mono)',fontSize:11,color:'var(--text-muted)'}}>{log.ipAddress||'—'}</td>
                  <td style={{padding:'10px 16px',fontSize:12,color:'var(--text-muted)',maxWidth:200,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{log.resource||'—'}</td>
                  <td style={{padding:'10px 16px'}}>
                    <span className={`badge ${log.result==='success'?'active':log.result==='failure'?'critical':'warning'}`}>{log.result}</span>
                  </td>
                  <td style={{padding:'10px 16px',fontSize:11,color:'var(--text-muted)',whiteSpace:'nowrap'}}>
                    {log.createdAt ? formatDistanceToNow(new Date(log.createdAt),{addSuffix:true}) : '—'}
                  </td>
                </tr>
              ))}
              {logs.length===0&&!loading&&<tr><td colSpan={6} style={{padding:40,textAlign:'center',color:'var(--text-muted)'}}>No audit entries found</td></tr>}
            </tbody>
          </table>
        </div>
        <div style={{padding:'10px 16px',borderTop:'1px solid var(--border)',display:'flex',gap:8}}>
          <button className="btn btn-ghost btn-sm" disabled={filter.page<=1} onClick={()=>setFilter(f=>({...f,page:f.page-1}))}>← Prev</button>
          <span style={{fontSize:12,color:'var(--text-muted)',lineHeight:'28px'}}>Page {filter.page}</span>
          <button className="btn btn-ghost btn-sm" disabled={logs.length<50} onClick={()=>setFilter(f=>({...f,page:f.page+1}))}>Next →</button>
        </div>
      </div>
    </div>
  );
}
