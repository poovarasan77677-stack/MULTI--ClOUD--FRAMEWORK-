import React, { useState, useEffect } from 'react';
import { serverApi } from '../services/api';
import { Server, RefreshCw, Cpu, Activity, HardDrive, Wifi } from 'lucide-react';
import toast from 'react-hot-toast';

const STATUS_COLORS = { running:'var(--accent-green)',stopped:'var(--text-muted)',error:'var(--accent-red)',pending:'var(--accent-yellow)',terminated:'var(--text-muted)',maintenance:'var(--accent-yellow)' };
const ROLE_COLORS = { primary:'var(--accent)',secondary:'var(--accent-purple)',replica:'var(--accent-green)',loadbalancer:'var(--accent-yellow)',monitor:'var(--text-secondary)',cache:'#f97316' };

export default function Servers() {
  const [servers, setServers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState({ status:'', role:'' });

  const fetchServers = async () => {
    setLoading(true);
    try { const d = await serverApi.getAll(filter); setServers(d.servers||[]); } catch {} finally { setLoading(false); }
  };

  useEffect(() => { fetchServers(); }, [filter]);

  const handleTerminate = async (id, name) => {
    if (!window.confirm(`Terminate "${name}"?`)) return;
    try { await serverApi.delete(id); toast.success('Server terminated'); fetchServers(); } catch {}
  };

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700 }}>Servers</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Monitor and manage all server instances across providers</p>
        </div>
        <button className="btn btn-ghost btn-sm" onClick={fetchServers}><RefreshCw size={13} className={loading?'spin':''}/>Refresh</button>
      </div>

      {/* Summary */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(5,1fr)',gap:12 }}>
        {[
          { label:'Total', value:servers.length, color:'var(--text-primary)' },
          { label:'Running', value:servers.filter(s=>s.status==='running').length, color:'var(--accent-green)' },
          { label:'Healthy', value:servers.filter(s=>s.healthCheck?.isHealthy).length, color:'var(--accent)' },
          { label:'Error', value:servers.filter(s=>s.status==='error').length, color:'var(--accent-red)' },
          { label:'Avg CPU', value:`${servers.length ? (servers.reduce((a,s)=>a+(s.metrics?.cpuUsage||0),0)/servers.length).toFixed(0) : 0}%`, color:'var(--accent-yellow)' }
        ].map(s => (
          <div key={s.label} className="card" style={{ padding:14,textAlign:'center' }}>
            <div style={{ fontFamily:'var(--font-mono)',fontSize:24,fontWeight:700,color:s.color }}>{s.value}</div>
            <div style={{ fontSize:11,color:'var(--text-muted)',marginTop:3 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div style={{ display:'flex',gap:10 }}>
        <select value={filter.status} onChange={e=>setFilter({...filter,status:e.target.value})} style={{ fontSize:13,padding:'6px 10px' }}>
          <option value="">All Status</option>
          <option value="running">Running</option>
          <option value="stopped">Stopped</option>
          <option value="error">Error</option>
          <option value="pending">Pending</option>
        </select>
        <select value={filter.role} onChange={e=>setFilter({...filter,role:e.target.value})} style={{ fontSize:13,padding:'6px 10px' }}>
          <option value="">All Roles</option>
          <option value="primary">Primary</option>
          <option value="secondary">Secondary</option>
          <option value="replica">Replica</option>
          <option value="loadbalancer">Load Balancer</option>
        </select>
      </div>

      {/* Server Grid */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(300px,1fr))',gap:14 }}>
        {servers.map(s => (
          <div key={s._id} className="card glow fade-in" style={{ padding:16 }}>
            <div style={{ display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:12 }}>
              <div>
                <div style={{ fontWeight:600,fontSize:14,marginBottom:2 }}>{s.name}</div>
                <div style={{ fontFamily:'var(--font-mono)',fontSize:11,color:'var(--text-muted)' }}>{s.instanceId}</div>
              </div>
              <div style={{ display:'flex',flexDirection:'column',alignItems:'flex-end',gap:4 }}>
                <span className={`badge ${s.status}`}><span className="status-dot" style={{ background:STATUS_COLORS[s.status] }}/>{s.status}</span>
                <span className="badge" style={{ background:`${ROLE_COLORS[s.role]||'var(--accent)'}18`,color:ROLE_COLORS[s.role]||'var(--accent)',border:'none',fontSize:10 }}>{s.role}</span>
              </div>
            </div>

            <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:8,marginBottom:12 }}>
              {[
                { icon:Cpu, label:'CPU', value:`${(s.metrics?.cpuUsage||0).toFixed(0)}%`, color:s.metrics?.cpuUsage>80?'var(--accent-red)':s.metrics?.cpuUsage>60?'var(--accent-yellow)':'var(--accent-green)' },
                { icon:Activity, label:'Memory', value:`${(s.metrics?.memoryUsage||0).toFixed(0)}%`, color:'var(--accent)' },
                { icon:HardDrive, label:'Disk', value:`${(s.metrics?.diskUsage||0).toFixed(0)}%`, color:'var(--accent-purple)' },
                { icon:Wifi, label:'Ping', value:`${(s.healthCheck?.lastPingMs||0).toFixed(0)}ms`, color:s.healthCheck?.isHealthy?'var(--accent-green)':'var(--accent-red)' }
              ].map(m => (
                <div key={m.label} style={{ background:'var(--bg-secondary)',borderRadius:8,padding:'8px 10px' }}>
                  <div style={{ display:'flex',alignItems:'center',gap:5,marginBottom:2 }}>
                    <m.icon size={11} style={{ color:'var(--text-muted)' }}/><span style={{ fontSize:10,color:'var(--text-muted)' }}>{m.label}</span>
                  </div>
                  <div style={{ fontFamily:'var(--font-mono)',fontSize:14,fontWeight:700,color:m.color }}>{m.value}</div>
                </div>
              ))}
            </div>

            <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between',paddingTop:10,borderTop:'1px solid var(--border)' }}>
              <div style={{ fontSize:11,color:'var(--text-muted)' }}>
                {s.cloudProvider?.alias||'Unknown'} · {s.instanceType}
              </div>
              <div style={{ display:'flex',gap:6,alignItems:'center' }}>
                <span style={{ fontFamily:'var(--font-mono)',fontSize:11,color:'var(--text-secondary)' }}>{s.ipAddress}</span>
                {s.status !== 'terminated' && (
                  <button className="btn btn-danger btn-sm" style={{ padding:'2px 8px',fontSize:11 }} onClick={()=>handleTerminate(s._id,s.name)}>×</button>
                )}
              </div>
            </div>
          </div>
        ))}
        {servers.length === 0 && !loading && (
          <div style={{ gridColumn:'1/-1',textAlign:'center',padding:60,color:'var(--text-muted)' }}>
            <Server size={40} style={{ opacity:0.3,marginBottom:12,display:'block',margin:'0 auto 12px' }}/>
            No servers found. Try seeding demo data from the top bar.
          </div>
        )}
      </div>
    </div>
  );
}
