import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { metricsApi } from '../services/api';
import MetricCard from '../components/Dashboard/MetricCard';
import ProviderCard from '../components/Dashboard/ProviderCard';
import {
  Server, Cloud, AlertTriangle, DollarSign, Cpu,
  Activity, GitBranch, CheckCircle, XCircle, Clock
} from 'lucide-react';
import {
  AreaChart, Area, LineChart, Line, XAxis, YAxis,
  CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell
} from 'recharts';
import { formatDistanceToNow } from 'date-fns';

const SEVERITY_COLORS = { info: 'var(--accent)', warning: 'var(--accent-yellow)', critical: 'var(--accent-red)', emergency: '#ff0040' };
const PIE_COLORS = ['#00d4ff', '#0078d4', '#4285f4', '#0080ff'];

const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div style={{ background:'var(--bg-card)',border:'1px solid var(--border)',borderRadius:8,padding:'10px 14px',fontSize:12 }}>
      <div style={{ color:'var(--text-muted)',marginBottom:6 }}>{label}</div>
      {payload.map((p, i) => (
        <div key={i} style={{ color:p.color,display:'flex',gap:8 }}>
          <span>{p.name}:</span><span style={{ fontFamily:'var(--font-mono)',fontWeight:600 }}>{typeof p.value === 'number' ? p.value.toFixed(1) : p.value}</span>
        </div>
      ))}
    </div>
  );
};

export default function Dashboard() {
  const { state } = useApp();
  const { overview, providers, alerts, failovers, loading } = state;
  const [timeseries, setTimeseries] = useState([]);
  const [costs, setCosts] = useState(null);

  useEffect(() => {
    metricsApi.getTimeseries().then(d => setTimeseries(d.data || [])).catch(() => {});
    metricsApi.getCosts().then(setCosts).catch(() => {});
  }, []);

  if (loading && !overview) {
    return (
      <div style={{ display:'flex',flexDirection:'column',gap:16 }}>
        {[...Array(4)].map((_,i) => <div key={i} className="skeleton" style={{ height:100,borderRadius:12 }} />)}
      </div>
    );
  }

  const ov = overview || {};

  return (
    <div style={{ display:'flex',flexDirection:'column',gap:20 }}>
      {/* Page Header */}
      <div style={{ display:'flex',alignItems:'center',justifyContent:'space-between' }}>
        <div>
          <h1 style={{ fontSize:22,fontWeight:700,color:'var(--text-primary)',letterSpacing:'-0.3px' }}>Infrastructure Overview</h1>
          <p style={{ fontSize:13,color:'var(--text-muted)',marginTop:2 }}>Real-time multi-cloud monitoring & HA management</p>
        </div>
        <div style={{ display:'flex',gap:8 }}>
          <span className="badge active"><span className="status-dot active" />All Systems Monitored</span>
        </div>
      </div>

      {/* KPI Cards */}
      <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(180px,1fr))',gap:14 }}>
        <MetricCard title="Health Score" value={ov.healthScore || 100} suffix="%" icon={Activity} color={parseFloat(ov.healthScore) >= 90 ? 'var(--accent-green)' : parseFloat(ov.healthScore) >= 70 ? 'var(--accent-yellow)' : 'var(--accent-red)'} subtitle={`${ov.healthyServers||0}/${ov.runningServers||0} servers healthy`} />
        <MetricCard title="Cloud Providers" value={ov.activeProviders||0} suffix={`/${ov.totalProviders||0}`} icon={Cloud} color="var(--accent)" subtitle="Active / Total" />
        <MetricCard title="Total Servers" value={ov.runningServers||0} icon={Server} color="var(--accent-purple)" subtitle={`${ov.totalServers||0} total deployed`} />
        <MetricCard title="Active Alerts" value={ov.activeAlerts||0} icon={AlertTriangle} color={ov.criticalAlerts > 0 ? 'var(--accent-red)' : ov.activeAlerts > 0 ? 'var(--accent-yellow)' : 'var(--accent-green)'} subtitle={`${ov.criticalAlerts||0} critical`} />
        <MetricCard title="Avg CPU" value={ov.avgCpu||0} suffix="%" icon={Cpu} color="var(--accent)" subtitle="Across all servers" />
        <MetricCard title="Monthly Cost" value={parseFloat(ov.totalMonthlyCost||0).toFixed(0)} prefix="$" icon={DollarSign} color="var(--accent-green)" subtitle="Estimated spend" />
      </div>

      {/* Charts Row */}
      <div style={{ display:'grid',gridTemplateColumns:'2fr 1fr',gap:16 }}>
        {/* Timeseries Chart */}
        <div className="card">
          <div style={{ marginBottom:14,display:'flex',alignItems:'center',justifyContent:'space-between' }}>
            <div>
              <h3 style={{ fontSize:14,fontWeight:600 }}>Resource Utilization (24h)</h3>
              <p style={{ fontSize:11,color:'var(--text-muted)' }}>CPU, Memory & Request trends</p>
            </div>
            <span style={{ fontSize:11,color:'var(--text-muted)',fontFamily:'var(--font-mono)' }}>Hourly</span>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={timeseries} margin={{ top:0,right:0,left:-20,bottom:0 }}>
              <defs>
                <linearGradient id="cpuGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00d4ff" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#00d4ff" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="memGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#a855f7" stopOpacity={0.2} />
                  <stop offset="95%" stopColor="#a855f7" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="timestamp" tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v => new Date(v).getHours()+'h'} />
              <YAxis tick={{ fontSize:10,fill:'var(--text-muted)' }} domain={[0,100]} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="cpu" name="CPU %" stroke="#00d4ff" strokeWidth={2} fill="url(#cpuGrad)" />
              <Area type="monotone" dataKey="memory" name="Memory %" stroke="#a855f7" strokeWidth={2} fill="url(#memGrad)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Cost Distribution */}
        <div className="card">
          <div style={{ marginBottom:14 }}>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Cost Distribution</h3>
            <p style={{ fontSize:11,color:'var(--text-muted)' }}>Monthly spend by provider</p>
          </div>
          {costs?.breakdown ? (
            <>
              <ResponsiveContainer width="100%" height={140}>
                <PieChart>
                  <Pie data={costs.breakdown} cx="50%" cy="50%" innerRadius={40} outerRadius={60} paddingAngle={3} dataKey="monthly">
                    {costs.breakdown.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                  </Pie>
                  <Tooltip formatter={(v) => [`$${v.toFixed(2)}`, 'Monthly']} />
                </PieChart>
              </ResponsiveContainer>
              <div style={{ display:'flex',flexDirection:'column',gap:6 }}>
                {costs.breakdown.map((p, i) => (
                  <div key={p.provider} style={{ display:'flex',alignItems:'center',justifyContent:'space-between',fontSize:12 }}>
                    <div style={{ display:'flex',alignItems:'center',gap:6 }}>
                      <div style={{ width:8,height:8,borderRadius:'50%',background:PIE_COLORS[i%PIE_COLORS.length] }} />
                      <span style={{ color:'var(--text-secondary)' }}>{p.provider}</span>
                    </div>
                    <span style={{ fontFamily:'var(--font-mono)',color:'var(--text-primary)',fontWeight:600 }}>${p.monthly.toFixed(0)}</span>
                  </div>
                ))}
                <div style={{ display:'flex',justifyContent:'space-between',paddingTop:8,borderTop:'1px solid var(--border)',fontSize:12 }}>
                  <span style={{ color:'var(--text-muted)' }}>Total</span>
                  <span style={{ fontFamily:'var(--font-mono)',color:'var(--accent-green)',fontWeight:700 }}>${costs.total?.monthly?.toFixed(0)}</span>
                </div>
              </div>
            </>
          ) : <div className="skeleton" style={{ height:200 }} />}
        </div>
      </div>

      {/* Request Rate chart */}
      <div className="card">
        <div style={{ marginBottom:14,display:'flex',justifyContent:'space-between',alignItems:'center' }}>
          <div>
            <h3 style={{ fontSize:14,fontWeight:600 }}>Request Rate & Latency</h3>
            <p style={{ fontSize:11,color:'var(--text-muted)' }}>Traffic patterns over last 24 hours</p>
          </div>
        </div>
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={timeseries} margin={{ top:0,right:0,left:-20,bottom:0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
            <XAxis dataKey="timestamp" tick={{ fontSize:10,fill:'var(--text-muted)' }} tickFormatter={v => new Date(v).getHours()+'h'} />
            <YAxis yAxisId="left" tick={{ fontSize:10,fill:'var(--text-muted)' }} />
            <YAxis yAxisId="right" orientation="right" tick={{ fontSize:10,fill:'var(--text-muted)' }} domain={[0,100]} />
            <Tooltip content={<CustomTooltip />} />
            <Line yAxisId="left" type="monotone" dataKey="requests" name="Req/s" stroke="#00ff88" strokeWidth={2} dot={false} />
            <Line yAxisId="right" type="monotone" dataKey="latency" name="Latency ms" stroke="#ffd700" strokeWidth={2} dot={false} strokeDasharray="4 2" />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Providers Grid */}
      <div>
        <h2 style={{ fontSize:15,fontWeight:600,marginBottom:12 }}>Cloud Providers</h2>
        <div style={{ display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:14 }}>
          {providers.map(p => <ProviderCard key={p._id} provider={p} />)}
          {providers.length === 0 && (
            <div style={{ gridColumn:'1/-1',textAlign:'center',padding:40,color:'var(--text-muted)' }}>
              <Cloud size={32} style={{ marginBottom:8,opacity:0.3 }} />
              <div>No providers configured. Click "Seed Demo" to load sample data.</div>
            </div>
          )}
        </div>
      </div>

      {/* Bottom row: Recent Alerts + Failover History */}
      <div style={{ display:'grid',gridTemplateColumns:'1fr 1fr',gap:16 }}>
        {/* Recent Alerts */}
        <div className="card">
          <h3 style={{ fontSize:14,fontWeight:600,marginBottom:12,display:'flex',alignItems:'center',gap:6 }}>
            <AlertTriangle size={14} style={{ color:'var(--accent-yellow)' }} />
            Recent Alerts
          </h3>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {alerts.slice(0,6).map(alert => (
              <div key={alert._id} style={{ display:'flex',alignItems:'flex-start',gap:10,padding:'8px',background:'var(--bg-secondary)',borderRadius:8,borderLeft:`3px solid ${SEVERITY_COLORS[alert.severity]||'var(--border)'}` }}>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ fontSize:12,fontWeight:500,color:'var(--text-primary)',marginBottom:2,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis' }}>{alert.title}</div>
                  <div style={{ fontSize:11,color:'var(--text-muted)' }}>{alert.createdAt ? formatDistanceToNow(new Date(alert.createdAt),{ addSuffix:true }) : ''}</div>
                </div>
                <span className={`badge ${alert.severity}`}>{alert.severity}</span>
              </div>
            ))}
            {alerts.length === 0 && <div style={{ textAlign:'center',padding:20,color:'var(--text-muted)',fontSize:13 }}><CheckCircle size={24} style={{ color:'var(--accent-green)',marginBottom:6 }} /><br />No active alerts</div>}
          </div>
        </div>

        {/* Failover History */}
        <div className="card">
          <h3 style={{ fontSize:14,fontWeight:600,marginBottom:12,display:'flex',alignItems:'center',gap:6 }}>
            <GitBranch size={14} style={{ color:'var(--accent)' }} />
            Recent Failovers
          </h3>
          <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
            {failovers.slice(0,5).map(f => (
              <div key={f._id} style={{ display:'flex',alignItems:'center',gap:10,padding:'8px',background:'var(--bg-secondary)',borderRadius:8 }}>
                <div style={{ flex:1,minWidth:0 }}>
                  <div style={{ fontSize:12,fontWeight:500,color:'var(--text-primary)',marginBottom:2 }}>
                    {f.fromProvider?.alias||'Unknown'} → {f.toProvider?.alias||'Unknown'}
                  </div>
                  <div style={{ fontSize:11,color:'var(--text-muted)',display:'flex',gap:8 }}>
                    <span style={{ display:'flex',alignItems:'center',gap:3 }}><Clock size={10} />{f.durationMs ? `${(f.durationMs/1000).toFixed(1)}s` : '—'}</span>
                    <span>{f.trigger}</span>
                  </div>
                </div>
                {f.status === 'completed' ? <CheckCircle size={16} style={{ color:'var(--accent-green)',flexShrink:0 }} /> : f.status === 'failed' ? <XCircle size={16} style={{ color:'var(--accent-red)',flexShrink:0 }} /> : <Activity size={16} style={{ color:'var(--accent)',flexShrink:0 }} className="spin" />}
              </div>
            ))}
            {failovers.length === 0 && <div style={{ textAlign:'center',padding:20,color:'var(--text-muted)',fontSize:13 }}><GitBranch size={24} style={{ opacity:0.3,marginBottom:6 }} /><br />No failover events recorded</div>}
          </div>
        </div>
      </div>
    </div>
  );
}
