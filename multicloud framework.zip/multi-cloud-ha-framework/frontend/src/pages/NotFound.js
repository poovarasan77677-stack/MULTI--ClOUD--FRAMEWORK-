import React from 'react';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, Home } from 'lucide-react';
export default function NotFound() {
  const nav = useNavigate();
  return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'70vh',gap:16}}>
      <div style={{width:64,height:64,background:'var(--accent-red-dim)',borderRadius:16,display:'flex',alignItems:'center',justifyContent:'center'}}>
        <AlertTriangle size={32} style={{color:'var(--accent-red)'}}/>
      </div>
      <h1 style={{fontFamily:'var(--font-mono)',fontSize:48,fontWeight:700,color:'var(--accent-red)',margin:0}}>404</h1>
      <p style={{color:'var(--text-muted)',fontSize:14}}>Page not found — this route doesn't exist.</p>
      <button className="btn btn-primary" onClick={()=>nav('/dashboard')}><Home size={14}/>Back to Dashboard</button>
    </div>
  );
}
