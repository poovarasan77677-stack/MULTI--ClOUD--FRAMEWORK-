import React, { useState } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import {
  LayoutDashboard, Cloud, Server, Bell, GitBranch, Scale, Settings,
  Activity, Wifi, WifiOff, RefreshCw, AlertTriangle, Database,
  ChevronLeft, ChevronRight, BarChart2, LogOut, Shield, User
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import './Layout.css';

const NAV = [
  { to:'/dashboard',    icon:LayoutDashboard, label:'Dashboard'       },
  { to:'/providers',    icon:Cloud,           label:'Cloud Providers' },
  { to:'/servers',      icon:Server,          label:'Servers'         },
  { to:'/alerts',       icon:Bell,            label:'Alerts', badge:true },
  { to:'/failover',     icon:GitBranch,       label:'Failover'        },
  { to:'/loadbalancer', icon:Scale,           label:'Load Balancer'   },
  { to:'/analytics',    icon:BarChart2,       label:'Analytics'       },
  { to:'/audit',        icon:Shield,          label:'Audit Log'       },
];

export default function Layout() {
  const { state, fetchDashboard, seedData } = useApp();
  const { overview, alertSummary, connected, lastUpdated, loading, activeFailover } = state;
  const [collapsed, setCollapsed] = useState(false);
  const navigate = useNavigate();
  const user = (() => { try { return JSON.parse(localStorage.getItem('ha_user')||'{}'); } catch { return {}; } })();
  const initials = `${user.firstName?.[0]||''}${user.lastName?.[0]||user.username?.[0]||'U'}`.toUpperCase();

  const handleLogout = () => { localStorage.removeItem('ha_token'); localStorage.removeItem('ha_user'); navigate('/login'); };

  return (
    <div className={`layout ${collapsed?'collapsed':''}`}>
      <aside className="sidebar">
        <div className="sidebar-header">
          <div className="logo">
            <div className="logo-icon"><Activity size={18}/></div>
            {!collapsed && <div className="logo-text"><span className="logo-main">HA</span><span className="logo-sub">Framework</span></div>}
          </div>
          <button className="collapse-btn" onClick={()=>setCollapsed(!collapsed)}>
            {collapsed ? <ChevronRight size={14}/> : <ChevronLeft size={14}/>}
          </button>
        </div>

        {!collapsed && (
          <div className="sidebar-status">
            <div className={`connection-badge ${connected?'connected':'disconnected'}`}>
              {connected ? <Wifi size={12}/> : <WifiOff size={12}/>}
              <span>{connected?'Live':'Offline'}</span>
            </div>
            {lastUpdated && <span className="last-update">{formatDistanceToNow(lastUpdated,{addSuffix:true})}</span>}
          </div>
        )}

        <nav className="sidebar-nav">
          {NAV.map(({to,icon:Icon,label,badge})=>(
            <NavLink key={to} to={to} className={({isActive})=>`nav-item ${isActive?'active':''}`}>
              <div className="nav-icon"><Icon size={16}/></div>
              {!collapsed && <span className="nav-label">{label}</span>}
              {!collapsed && badge && alertSummary.critical > 0 && <span className="nav-badge critical">{alertSummary.critical}</span>}
              {!collapsed && badge && alertSummary.active > 0 && !alertSummary.critical && <span className="nav-badge">{alertSummary.active}</span>}
            </NavLink>
          ))}
          <div style={{margin:'8px 6px',height:1,background:'var(--border)'}}/>
          <NavLink to="/settings" className={({isActive})=>`nav-item ${isActive?'active':''}`}>
            <div className="nav-icon"><Settings size={16}/></div>
            {!collapsed && <span className="nav-label">Settings</span>}
          </NavLink>
          <NavLink to="/profile" className={({isActive})=>`nav-item ${isActive?'active':''}`}>
            <div className="nav-icon"><User size={16}/></div>
            {!collapsed && <span className="nav-label">Profile</span>}
          </NavLink>
        </nav>

        {!collapsed && overview && (
          <div className="sidebar-footer">
            <div className="health-score">
              <div className="health-score-label">System Health</div>
              <div className="health-score-value" style={{color:parseFloat(overview.healthScore)>=90?'var(--accent-green)':parseFloat(overview.healthScore)>=70?'var(--accent-yellow)':'var(--accent-red)'}}>
                {overview.healthScore}%
              </div>
              <div className="progress-bar">
                <div className="progress-bar-fill" style={{width:`${overview.healthScore}%`,background:parseFloat(overview.healthScore)>=90?'var(--accent-green)':parseFloat(overview.healthScore)>=70?'var(--accent-yellow)':'var(--accent-red)'}}/>
              </div>
            </div>
            <div className="sidebar-stats">
              <div className="stat"><Database size={11}/><span>{overview.activeProviders}/{overview.totalProviders} Clouds</span></div>
              <div className="stat"><Server size={11}/><span>{overview.healthyServers}/{overview.runningServers} Servers</span></div>
            </div>
            <div style={{borderTop:'1px solid var(--border)',paddingTop:10,marginTop:8,display:'flex',alignItems:'center',gap:8}}>
              <div style={{width:28,height:28,background:'linear-gradient(135deg,var(--accent),var(--accent-purple))',borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontSize:11,fontWeight:700,color:'#fff',flexShrink:0}}>{initials}</div>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:12,fontWeight:600,whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}}>{user.username||'User'}</div>
                <div style={{fontSize:10,color:'var(--text-muted)',textTransform:'capitalize'}}>{user.role||'viewer'}</div>
              </div>
              <button onClick={handleLogout} style={{background:'none',border:'none',color:'var(--text-muted)',cursor:'pointer',padding:4,borderRadius:4,display:'flex'}} title="Logout"><LogOut size={13}/></button>
            </div>
          </div>
        )}
      </aside>

      <div className="main-wrapper">
        <header className="topbar">
          <div className="topbar-left">
            {activeFailover && (
              <div className="failover-banner"><GitBranch size={14} className="spin"/>
                <span>Failover: <strong>{activeFailover.from}</strong> → <strong>{activeFailover.to}</strong></span>
              </div>
            )}
          </div>
          <div className="topbar-right">
            {alertSummary.critical > 0 && <div className="alert-indicator"><AlertTriangle size={14}/><span>{alertSummary.critical} Critical</span></div>}
            <button className="btn btn-ghost btn-sm" onClick={fetchDashboard} disabled={loading}>
              <RefreshCw size={13} className={loading?'spin':''}/>{!loading&&'Refresh'}
            </button>
            <button className="btn btn-secondary btn-sm" onClick={seedData}><Database size={13}/>Seed Demo</button>
            <div className="user-avatar" title={user.email} onClick={()=>navigate('/profile')} style={{cursor:'pointer'}}>{initials}</div>
          </div>
        </header>
        <main className="page-content"><Outlet/></main>
      </div>
    </div>
  );
}
