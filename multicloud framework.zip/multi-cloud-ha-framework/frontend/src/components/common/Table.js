import React from 'react';
import Spinner from './Spinner';
import EmptyState from './EmptyState';
import { Database } from 'lucide-react';

export default function Table({ columns, rows, loading, emptyTitle = 'No data', emptyMessage, keyField = '_id', onRowClick }) {
  return (
    <div style={{overflowX:'auto'}}>
      <table style={{width:'100%',borderCollapse:'collapse',fontSize:13}}>
        <thead>
          <tr style={{background:'var(--bg-secondary)',borderBottom:'1px solid var(--border)'}}>
            {columns.map(col => (
              <th key={col.key} style={{padding:'9px 16px',textAlign:col.align||'left',fontSize:11,color:'var(--text-muted)',fontWeight:600,textTransform:'uppercase',letterSpacing:'0.4px',whiteSpace:'nowrap',width:col.width}}>
                {col.label}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {loading ? (
            <tr><td colSpan={columns.length} style={{padding:40,textAlign:'center'}}>
              <Spinner style={{margin:'0 auto'}}/>
            </td></tr>
          ) : rows.length === 0 ? (
            <tr><td colSpan={columns.length}>
              <EmptyState icon={Database} title={emptyTitle} message={emptyMessage}/>
            </td></tr>
          ) : rows.map((row, i) => (
            <tr key={row[keyField] || i}
              onClick={onRowClick ? () => onRowClick(row) : undefined}
              style={{borderBottom:'1px solid var(--border)',cursor:onRowClick?'pointer':'default',transition:'background var(--transition)'}}
              onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
              onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
              {columns.map(col => (
                <td key={col.key} style={{padding:'10px 16px',textAlign:col.align||'left',color:col.color||'var(--text-primary)',...col.style}}>
                  {col.render ? col.render(row[col.key], row) : (row[col.key] ?? '—')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
