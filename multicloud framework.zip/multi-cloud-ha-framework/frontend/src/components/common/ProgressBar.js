import React from 'react';

export default function ProgressBar({ value = 0, height = 6, showLabel = false, label, colorAuto = true, color }) {
  const clampedValue = Math.min(100, Math.max(0, value));
  const autoColor = clampedValue > 85 ? 'var(--accent-red)' : clampedValue > 65 ? 'var(--accent-yellow)' : 'var(--accent-green)';
  const barColor = color || (colorAuto ? autoColor : 'var(--accent)');

  return (
    <div style={{ display:'flex', alignItems:'center', gap:8 }}>
      {label && <span style={{ fontSize:11, color:'var(--text-muted)', width:40, flexShrink:0 }}>{label}</span>}
      <div style={{ flex:1, height, background:'var(--bg-secondary)', borderRadius:height/2, overflow:'hidden' }}>
        <div style={{
          height:'100%', width:`${clampedValue}%`,
          background:barColor, borderRadius:height/2,
          transition:'width 0.5s ease, background 0.3s ease'
        }}/>
      </div>
      {showLabel && (
        <span style={{ fontFamily:'var(--font-mono)', fontSize:11, color:barColor, width:34, textAlign:'right', flexShrink:0 }}>
          {clampedValue.toFixed(0)}%
        </span>
      )}
    </div>
  );
}
