import React, { useEffect } from 'react';
import { X } from 'lucide-react';

export default function Modal({ isOpen, onClose, title, children, width = 480, footer }) {
  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e) => { if (e.key === 'Escape') onClose(); };
    document.addEventListener('keydown', handleKey);
    document.body.style.overflow = 'hidden';
    return () => { document.removeEventListener('keydown', handleKey); document.body.style.overflow = ''; };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div onClick={onClose} style={{
      position:'fixed',inset:0,background:'rgba(6,11,20,0.85)',
      display:'flex',alignItems:'center',justifyContent:'center',
      zIndex:1000,padding:20,backdropFilter:'blur(4px)'
    }}>
      <div onClick={e=>e.stopPropagation()} style={{
        background:'var(--bg-card)',border:'1px solid var(--border)',
        borderRadius:'var(--radius-lg)',width:'100%',maxWidth:width,
        boxShadow:'0 20px 60px rgba(0,0,0,0.6)',animation:'fadeIn 0.2s ease'
      }}>
        <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',padding:'16px 20px',borderBottom:'1px solid var(--border)'}}>
          <h3 style={{fontSize:15,fontWeight:600,color:'var(--text-primary)'}}>{title}</h3>
          <button onClick={onClose} style={{background:'none',border:'none',color:'var(--text-muted)',cursor:'pointer',padding:4,borderRadius:4,display:'flex',alignItems:'center'}}>
            <X size={16}/>
          </button>
        </div>
        <div style={{padding:20}}>{children}</div>
        {footer && <div style={{padding:'12px 20px',borderTop:'1px solid var(--border)',display:'flex',justifyContent:'flex-end',gap:8}}>{footer}</div>}
      </div>
    </div>
  );
}
