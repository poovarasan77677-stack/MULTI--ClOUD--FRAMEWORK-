import React from 'react';

export default function EmptyState({ icon: Icon, title, message, action, actionLabel }) {
  return (
    <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', padding:'60px 20px', gap:12 }}>
      {Icon && <Icon size={40} style={{ color:'var(--text-muted)', opacity:0.35 }}/>}
      <div style={{ fontWeight:600, fontSize:15, color:'var(--text-primary)' }}>{title}</div>
      {message && <div style={{ fontSize:13, color:'var(--text-muted)', textAlign:'center', maxWidth:320 }}>{message}</div>}
      {action && actionLabel && (
        <button className="btn btn-secondary" style={{ marginTop:8 }} onClick={action}>{actionLabel}</button>
      )}
    </div>
  );
}
