import React from 'react';
import { Activity } from 'lucide-react';

export default function LoadingScreen() {
  return (
    <div style={{ display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:'100vh',background:'var(--bg-primary)',gap:'16px' }}>
      <div style={{ width:48,height:48,background:'linear-gradient(135deg,var(--accent),var(--accent-purple))',borderRadius:12,display:'flex',alignItems:'center',justifyContent:'center' }}>
        <Activity size={24} color="#fff" />
      </div>
      <div style={{ fontFamily:'var(--font-mono)',color:'var(--accent)',fontSize:14 }}>Initializing Multi-Cloud HA Framework...</div>
      <div className="progress-bar" style={{ width:200 }}>
        <div className="progress-bar-fill info" style={{ width:'60%',animation:'none',transition:'width 2s' }} />
      </div>
    </div>
  );
}
