import React from 'react';
export default function Spinner({ size = 20, color = 'var(--accent)', style = {} }) {
  return (
    <div style={{
      width:size,height:size,border:`2px solid ${color}30`,
      borderTopColor:color,borderRadius:'50%',
      animation:'spin 0.8s linear infinite',flexShrink:0,...style
    }}/>
  );
}
