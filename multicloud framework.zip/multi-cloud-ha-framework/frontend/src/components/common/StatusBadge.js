import React from 'react';

const CONFIG = {
  active:      { label:'Active',      bg:'var(--accent-green-dim)',  color:'var(--accent-green)', dot:true  },
  degraded:    { label:'Degraded',    bg:'var(--accent-yellow-dim)', color:'var(--accent-yellow)',dot:true  },
  offline:     { label:'Offline',     bg:'var(--accent-red-dim)',    color:'var(--accent-red)',   dot:false },
  error:       { label:'Error',       bg:'var(--accent-red-dim)',    color:'var(--accent-red)',   dot:false },
  running:     { label:'Running',     bg:'var(--accent-green-dim)',  color:'var(--accent-green)', dot:true  },
  stopped:     { label:'Stopped',     bg:'var(--bg-secondary)',      color:'var(--text-muted)',   dot:false },
  pending:     { label:'Pending',     bg:'var(--accent-yellow-dim)', color:'var(--accent-yellow)',dot:true  },
  maintenance: { label:'Maintenance', bg:'var(--bg-secondary)',      color:'var(--text-muted)',   dot:false },
  terminated:  { label:'Terminated',  bg:'var(--bg-secondary)',      color:'var(--text-muted)',   dot:false },
  completed:   { label:'Completed',   bg:'var(--accent-green-dim)',  color:'var(--accent-green)', dot:false },
  failed:      { label:'Failed',      bg:'var(--accent-red-dim)',    color:'var(--accent-red)',   dot:false },
  in_progress: { label:'In Progress', bg:'var(--accent-dim)',        color:'var(--accent)',        dot:true  },
};

export default function StatusBadge({ status, label, size = 'normal' }) {
  const cfg = CONFIG[status] || { label: status || 'Unknown', bg:'var(--bg-secondary)', color:'var(--text-muted)', dot:false };
  const displayLabel = label || cfg.label;
  const padding = size === 'small' ? '1px 6px' : '2px 8px';
  const fontSize  = size === 'small' ? 10 : 11;

  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding, borderRadius: 20, fontSize, fontWeight: 600,
      textTransform: 'uppercase', letterSpacing: '0.4px',
      background: cfg.bg, color: cfg.color,
      border: `1px solid ${cfg.color}30`
    }}>
      {cfg.dot && (
        <span style={{
          width: 6, height: 6, borderRadius: '50%',
          background: cfg.color, flexShrink: 0,
          animation: ['active','running','in_progress'].includes(status) ? 'pulse-dot 2s ease-in-out infinite' : 'none'
        }}/>
      )}
      {displayLabel}
    </span>
  );
}
