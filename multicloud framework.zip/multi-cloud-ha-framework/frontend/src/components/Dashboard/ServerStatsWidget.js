import React from 'react';
import { useApp } from '../../context/AppContext';
import { Server, Cpu, HardDrive, Activity } from 'lucide-react';
import ProgressBar from '../common/ProgressBar';

export default function ServerStatsWidget() {
  const { state } = useApp();
  const { servers } = state;
  const running = servers.filter(s => s.status === 'running');
  const avgCpu  = running.length ? running.reduce((a,s) => a + (s.metrics?.cpuUsage||0), 0) / running.length : 0;
  const avgMem  = running.length ? running.reduce((a,s) => a + (s.metrics?.memoryUsage||0), 0) / running.length : 0;
  const avgDisk = running.length ? running.reduce((a,s) => a + (s.metrics?.diskUsage||0), 0) / running.length : 0;
  const healthy = running.filter(s => s.healthCheck?.isHealthy).length;

  const stats = [
    { label:'Avg CPU',    value:avgCpu,  icon:Cpu,      suffix:'%' },
    { label:'Avg Memory', value:avgMem,  icon:Activity,  suffix:'%' },
    { label:'Avg Disk',   value:avgDisk, icon:HardDrive, suffix:'%' },
  ];

  return (
    <div className="card">
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:16}}>
        <h3 style={{fontSize:14,fontWeight:600,display:'flex',alignItems:'center',gap:6}}>
          <Server size={14} style={{color:'var(--accent)'}}/>Server Health
        </h3>
        <span style={{fontFamily:'var(--font-mono)',fontSize:12,color:'var(--accent-green)',fontWeight:600}}>
          {healthy}/{running.length} healthy
        </span>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        {stats.map(s => (
          <div key={s.label}>
            <div style={{display:'flex',justifyContent:'space-between',marginBottom:5}}>
              <span style={{fontSize:12,color:'var(--text-muted)',display:'flex',alignItems:'center',gap:5}}>
                <s.icon size={11}/>{s.label}
              </span>
              <span style={{fontFamily:'var(--font-mono)',fontSize:12,color:'var(--text-primary)',fontWeight:600}}>
                {s.value.toFixed(0)}{s.suffix}
              </span>
            </div>
            <ProgressBar value={s.value} height={5} showLabel={false}/>
          </div>
        ))}
      </div>
      <div style={{marginTop:14,paddingTop:12,borderTop:'1px solid var(--border)',display:'grid',gridTemplateColumns:'1fr 1fr 1fr',gap:8,textAlign:'center'}}>
        {[
          {label:'Primary',  value:servers.filter(s=>s.role==='primary').length,   color:'var(--accent)'},
          {label:'Secondary',value:servers.filter(s=>s.role==='secondary').length,  color:'var(--accent-purple)'},
          {label:'Replica',  value:servers.filter(s=>s.role==='replica').length,    color:'var(--accent-green)'},
        ].map(r => (
          <div key={r.label} style={{background:'var(--bg-secondary)',borderRadius:8,padding:'8px 4px'}}>
            <div style={{fontFamily:'var(--font-mono)',fontSize:18,fontWeight:700,color:r.color}}>{r.value}</div>
            <div style={{fontSize:10,color:'var(--text-muted)',marginTop:2}}>{r.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
