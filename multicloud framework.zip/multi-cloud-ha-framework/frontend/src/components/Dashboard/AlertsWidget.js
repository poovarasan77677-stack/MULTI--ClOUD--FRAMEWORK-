import React from 'react';
import { useApp } from '../../context/AppContext';
import { useNavigate } from 'react-router-dom';
import { AlertTriangle, CheckCircle, Info, Zap, ArrowRight } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

const SEV_CONFIG = {
  emergency:{ color:'#ff0040', bg:'rgba(255,0,64,0.1)',   icon:Zap },
  critical: { color:'var(--accent-red)',    bg:'var(--accent-red-dim)',    icon:Zap },
  warning:  { color:'var(--accent-yellow)', bg:'var(--accent-yellow-dim)', icon:AlertTriangle },
  info:     { color:'var(--accent)',        bg:'var(--accent-dim)',         icon:Info }
};

export default function AlertsWidget({ maxItems = 5 }) {
  const { state } = useApp();
  const { alerts, alertSummary } = state;
  const navigate = useNavigate();
  const active = alerts.filter(a => a.status === 'active').slice(0, maxItems);

  return (
    <div className="card" style={{padding:0,overflow:'hidden'}}>
      <div style={{padding:'14px 18px',borderBottom:'1px solid var(--border)',display:'flex',alignItems:'center',justifyContent:'space-between'}}>
        <h3 style={{fontSize:14,fontWeight:600,display:'flex',alignItems:'center',gap:6}}>
          <AlertTriangle size={14} style={{color:'var(--accent-yellow)'}}/>
          Active Alerts
          {alertSummary.active > 0 && (
            <span style={{background:'var(--accent-red-dim)',color:'var(--accent-red)',fontSize:11,fontWeight:700,padding:'1px 7px',borderRadius:10,border:'1px solid rgba(255,64,96,0.2)'}}>
              {alertSummary.active}
            </span>
          )}
        </h3>
        <button onClick={()=>navigate('/alerts')} style={{background:'none',border:'none',color:'var(--accent)',fontSize:12,cursor:'pointer',display:'flex',alignItems:'center',gap:4}}>
          View All <ArrowRight size={12}/>
        </button>
      </div>

      {active.length === 0 ? (
        <div style={{padding:32,textAlign:'center'}}>
          <CheckCircle size={28} style={{color:'var(--accent-green)',marginBottom:8,display:'block',margin:'0 auto 8px'}}/>
          <div style={{fontSize:13,color:'var(--text-muted)'}}>All clear — no active alerts</div>
        </div>
      ) : (
        <div>
          {active.map(alert => {
            const cfg = SEV_CONFIG[alert.severity] || SEV_CONFIG.info;
            const Icon = cfg.icon;
            return (
              <div key={alert._id} style={{display:'flex',alignItems:'flex-start',gap:12,padding:'12px 18px',borderBottom:'1px solid var(--border)',borderLeft:`3px solid ${cfg.color}`,cursor:'pointer',transition:'background var(--transition)'}}
                onClick={()=>navigate('/alerts')}
                onMouseEnter={e=>e.currentTarget.style.background='var(--bg-card-hover)'}
                onMouseLeave={e=>e.currentTarget.style.background='transparent'}>
                <div style={{width:28,height:28,borderRadius:8,background:cfg.bg,display:'flex',alignItems:'center',justifyContent:'center',flexShrink:0,color:cfg.color}}>
                  <Icon size={13}/>
                </div>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:12,fontWeight:500,color:'var(--text-primary)',marginBottom:2,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{alert.title}</div>
                  <div style={{fontSize:11,color:'var(--text-muted)',display:'flex',gap:8}}>
                    <span style={{color:cfg.color,fontWeight:600,textTransform:'uppercase',letterSpacing:'0.3px'}}>{alert.severity}</span>
                    <span>{alert.createdAt ? formatDistanceToNow(new Date(alert.createdAt),{addSuffix:true}) : ''}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
