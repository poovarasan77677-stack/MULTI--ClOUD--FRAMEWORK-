import React from 'react';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

export default function MetricCard({ title, value, subtitle, icon: Icon, color = 'var(--accent)', trend, prefix = '', suffix = '' }) {
  const trendIcon = trend > 0 ? TrendingUp : trend < 0 ? TrendingDown : Minus;
  const TrendIcon = trendIcon;
  const trendColor = trend > 0 ? 'var(--accent-red)' : trend < 0 ? 'var(--accent-green)' : 'var(--text-muted)';
  return (
    <div className="card glow metric-card fade-in" style={{ '--card-accent': color }}>
      <div style={{ display:'flex',alignItems:'flex-start',justifyContent:'space-between',marginBottom:12 }}>
        <div>
          <div style={{ fontSize:11,color:'var(--text-muted)',textTransform:'uppercase',letterSpacing:'0.5px',marginBottom:6 }}>{title}</div>
          <div style={{ fontFamily:'var(--font-mono)',fontSize:28,fontWeight:700,color,lineHeight:1 }}>
            {prefix}{value}{suffix}
          </div>
          {subtitle && <div style={{ fontSize:12,color:'var(--text-secondary)',marginTop:4 }}>{subtitle}</div>}
        </div>
        <div style={{ width:40,height:40,background:`rgba(${color === 'var(--accent)' ? '0,212,255' : color === 'var(--accent-green)' ? '0,255,136' : color === 'var(--accent-red)' ? '255,64,96' : '168,85,247'},0.12)`,borderRadius:10,display:'flex',alignItems:'center',justifyContent:'center',color,flexShrink:0 }}>
          <Icon size={18} />
        </div>
      </div>
      {trend !== undefined && (
        <div style={{ display:'flex',alignItems:'center',gap:4,fontSize:11,color:trendColor }}>
          <TrendIcon size={12} />
          <span>{Math.abs(trend).toFixed(1)}% vs last hour</span>
        </div>
      )}
    </div>
  );
}
