import React from 'react';
import { Cpu, MemoryStick, Activity, DollarSign, Server } from 'lucide-react';

const PROVIDER_COLORS = { aws: '#ff9900', azure: '#0078d4', gcp: '#4285f4', digitalocean: '#0080ff', default: 'var(--accent)' };
const PROVIDER_LABELS = { aws: 'Amazon Web Services', azure: 'Microsoft Azure', gcp: 'Google Cloud Platform', digitalocean: 'DigitalOcean' };

function ProgressMini({ value, color }) {
  const getColor = (v) => v > 85 ? 'var(--accent-red)' : v > 70 ? 'var(--accent-yellow)' : color || 'var(--accent-green)';
  return (
    <div style={{ display:'flex',alignItems:'center',gap:8 }}>
      <div className="progress-bar" style={{ flex:1,height:4 }}>
        <div className="progress-bar-fill" style={{ width:`${Math.min(100,value||0)}%`, background:getColor(value) }} />
      </div>
      <span style={{ fontFamily:'var(--font-mono)',fontSize:11,color:getColor(value),width:34,textAlign:'right' }}>{(value||0).toFixed(0)}%</span>
    </div>
  );
}

export default function ProviderCard({ provider }) {
  const { name, alias, status, metrics, cost, isPrimary, isFailoverTarget } = provider;
  const color = PROVIDER_COLORS[name] || PROVIDER_COLORS.default;
  const isActive = status === 'active';

  return (
    <div className="card glow provider-card fade-in" style={{ borderColor: isActive ? `${color}30` : 'var(--border)' }}>
      <div style={{ display:'flex',alignItems:'center',gap:10,marginBottom:14 }}>
        <div style={{ width:36,height:36,background:`${color}18`,border:`1px solid ${color}30`,borderRadius:8,display:'flex',alignItems:'center',justifyContent:'center',fontSize:18,flexShrink:0 }}>
          {name === 'aws' ? '☁' : name === 'azure' ? '⬡' : name === 'gcp' ? '◉' : '◈'}
        </div>
        <div style={{ flex:1,minWidth:0 }}>
          <div style={{ fontWeight:600,fontSize:14,color:'var(--text-primary)',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis' }}>{alias}</div>
          <div style={{ fontSize:11,color:'var(--text-muted)' }}>{PROVIDER_LABELS[name] || name}</div>
        </div>
        <div style={{ display:'flex',flexDirection:'column',alignItems:'flex-end',gap:4 }}>
          <span className={`badge ${status}`}><span className={`status-dot ${status}`} />{status}</span>
          {isPrimary && <span className="badge info" style={{ fontSize:10 }}>PRIMARY</span>}
          {isFailoverTarget && !isPrimary && <span className="badge" style={{ fontSize:10,background:'var(--accent-purple)',color:'#fff',opacity:0.7 }}>STANDBY</span>}
        </div>
      </div>

      <div style={{ display:'flex',flexDirection:'column',gap:8 }}>
        <div>
          <div style={{ display:'flex',justifyContent:'space-between',marginBottom:3 }}>
            <span style={{ fontSize:11,color:'var(--text-muted)',display:'flex',alignItems:'center',gap:4 }}><Cpu size={10} /> CPU</span>
          </div>
          <ProgressMini value={metrics?.cpuUsage} />
        </div>
        <div>
          <div style={{ display:'flex',justifyContent:'space-between',marginBottom:3 }}>
            <span style={{ fontSize:11,color:'var(--text-muted)',display:'flex',alignItems:'center',gap:4 }}><Activity size={10} /> Memory</span>
          </div>
          <ProgressMini value={metrics?.memoryUsage} />
        </div>
      </div>

      <div style={{ marginTop:14,display:'flex',justifyContent:'space-between',paddingTop:12,borderTop:'1px solid var(--border)' }}>
        <div style={{ display:'flex',alignItems:'center',gap:4,fontSize:11,color:'var(--text-muted)' }}>
          <Activity size={11} />
          <span>{(metrics?.uptimePercentage||100).toFixed(2)}% uptime</span>
        </div>
        <div style={{ display:'flex',alignItems:'center',gap:4,fontSize:11,color:color,fontFamily:'var(--font-mono)',fontWeight:600 }}>
          <DollarSign size={11} />
          <span>${(cost?.monthly||0).toFixed(0)}/mo</span>
        </div>
      </div>
    </div>
  );
}
