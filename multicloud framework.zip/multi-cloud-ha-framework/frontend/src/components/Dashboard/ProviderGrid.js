import React from 'react';
import { useApp } from '../../context/AppContext';
import ProviderCard from './ProviderCard';
import EmptyState from '../common/EmptyState';
import { Cloud } from 'lucide-react';

export default function ProviderGrid({ onSeed }) {
  const { state } = useApp();
  const { providers, loading } = state;

  if (!loading && providers.length === 0) {
    return (
      <EmptyState
        icon={Cloud}
        title="No cloud providers"
        message='Click "Seed Demo" in the top bar to load 4 sample providers with live metrics.'
        action={onSeed}
        actionLabel="Seed Demo Data"
      />
    );
  }

  return (
    <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fill,minmax(240px,1fr))',gap:14}}>
      {providers.map(p => <ProviderCard key={p._id} provider={p}/>)}
    </div>
  );
}
