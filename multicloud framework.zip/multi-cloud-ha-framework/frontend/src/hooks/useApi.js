import { useState, useCallback, useRef, useEffect } from 'react';

/**
 * Generic API hook with loading, error, data states and abort support
 * @param {Function} apiFn - async function to call
 * @param {Object} options - { immediate, onSuccess, onError }
 */
export function useApi(apiFn, options = {}) {
  const { immediate = false, onSuccess, onError } = options;
  const [data, setData]       = useState(null);
  const [loading, setLoading] = useState(immediate);
  const [error, setError]     = useState(null);
  const abortRef              = useRef(false);

  const execute = useCallback(async (...args) => {
    setLoading(true);
    setError(null);
    abortRef.current = false;
    try {
      const result = await apiFn(...args);
      if (!abortRef.current) {
        setData(result);
        onSuccess?.(result);
        return result;
      }
    } catch (err) {
      if (!abortRef.current) {
        const msg = err.response?.data?.error || err.message || 'Request failed';
        setError(msg);
        onError?.(err);
      }
    } finally {
      if (!abortRef.current) setLoading(false);
    }
  }, [apiFn, onSuccess, onError]);

  useEffect(() => {
    if (immediate) execute();
    return () => { abortRef.current = true; };
  }, [immediate]);

  const reset = () => { setData(null); setError(null); setLoading(false); };

  return { data, loading, error, execute, reset };
}

/** Simplified variant for simple GET calls */
export function useFetch(apiFn, deps = []) {
  const [state, setState] = useState({ data: null, loading: true, error: null });

  useEffect(() => {
    let cancelled = false;
    setState(s => ({ ...s, loading: true, error: null }));
    apiFn()
      .then(data => { if (!cancelled) setState({ data, loading: false, error: null }); })
      .catch(err => { if (!cancelled) setState({ data: null, loading: false, error: err.message }); });
    return () => { cancelled = true; };
  }, deps);

  return state;
}
