import { useEffect, useRef } from 'react';

export function usePolling(callback, interval = 30000, immediate = true) {
  const callbackRef = useRef(callback);
  useEffect(() => { callbackRef.current = callback; }, [callback]);

  useEffect(() => {
    if (immediate) callbackRef.current();
    const id = setInterval(() => callbackRef.current(), interval);
    return () => clearInterval(id);
  }, [interval, immediate]);
}
