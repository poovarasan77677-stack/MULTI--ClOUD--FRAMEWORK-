import { useEffect, useRef, useState, useCallback } from 'react';
import { getSocket } from '../services/socket';

export function useWebSocket(event, callback) {
  const callbackRef = useRef(callback);
  useEffect(() => { callbackRef.current = callback; }, [callback]);

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const handler = (...args) => callbackRef.current(...args);
    socket.on(event, handler);
    return () => socket.off(event, handler);
  }, [event]);
}

export function useSocketStatus() {
  const [connected, setConnected] = useState(false);
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    setConnected(socket.connected);
    socket.on('connect',    () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    return () => { socket.off('connect'); socket.off('disconnect'); };
  }, []);
  return connected;
}
