describe('CloudProvider Model', () => {
  const CloudProvider = require('../../src/models/CloudProvider');

  it('should have required paths', () => {
    expect(CloudProvider.schema.paths.name).toBeDefined();
    expect(CloudProvider.schema.paths.alias).toBeDefined();
    expect(CloudProvider.schema.paths.region).toBeDefined();
  });

  it('should validate status enum', () => {
    const values = CloudProvider.schema.path('status').enumValues;
    expect(values).toContain('active');
    expect(values).toContain('degraded');
    expect(values).toContain('offline');
  });

  it('isHealthy() should return false when consecutive failures >= 3', () => {
    const p = new CloudProvider({ name:'aws', alias:'Test', region:'us-east-1' });
    p.status = 'active';
    p.healthCheck = { consecutiveFailures: 3 };
    expect(p.isHealthy()).toBe(false);
  });

  it('isHealthy() should return true when active and no failures', () => {
    const p = new CloudProvider({ name:'aws', alias:'Test', region:'us-east-1' });
    p.status = 'active';
    p.healthCheck = { consecutiveFailures: 0 };
    expect(p.isHealthy()).toBe(true);
  });
});

describe('Alert Model', () => {
  const Alert = require('../../src/models/Alert');
  it('should have severity enum with all levels', () => {
    const sevs = Alert.schema.path('severity').enumValues;
    ['info','warning','critical','emergency'].forEach(s => expect(sevs).toContain(s));
  });
  it('should default status to active', () => {
    const alert = new Alert({ title:'T', message:'M', type:'high_cpu' });
    expect(alert.status).toBe('active');
  });
});
