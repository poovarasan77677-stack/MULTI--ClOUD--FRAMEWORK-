jest.mock('../../src/models/Server');
jest.mock('../../src/models/CloudProvider');
jest.mock('../../src/services/alertService', () => ({ createAlert: jest.fn().mockResolvedValue({}) }));
jest.mock('../../src/utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn() }));
jest.mock('node-cron', () => ({ schedule: jest.fn() }));

const Server = require('../../src/models/Server');
const CloudProvider = require('../../src/models/CloudProvider');
const { startAutoScaler } = require('../../src/services/autoScaler');
const cron = require('node-cron');

describe('AutoScaler Service', () => {
  it('should schedule cron job on start', () => {
    startAutoScaler(null);
    expect(cron.schedule).toHaveBeenCalled();
    const [interval] = cron.schedule.mock.calls[0];
    expect(typeof interval).toBe('string');
  });

  it('scaleUp should create a new pending server', async () => {
    const mockSave = jest.fn().mockResolvedValue({});
    Server.mockImplementation(() => ({ save: mockSave, status: 'pending', instanceId: 'i-test' }));

    const { scaleUp } = require('../../src/services/autoScaler');
    const fakeProvider = { _id: 'prov1', alias: 'AWS US', name: 'aws', status: 'active' };
    const fakeServer   = { _id: 'srv1', metrics: { cpuUsage: 45 } };
    const io = { emit: jest.fn() };

    const result = await scaleUp(fakeProvider, fakeServer, io);
    expect(mockSave).toHaveBeenCalled();
    expect(result).toBeDefined();
  });

  it('scaleDown should mark a secondary server as terminated', async () => {
    const mockSave = jest.fn().mockResolvedValue({});
    const fakeServers = [
      { _id: 's1', role: 'secondary', status: 'running', metrics: { cpuUsage: 10 }, save: mockSave, terminatedAt: null },
      { _id: 's2', role: 'primary',   status: 'running', metrics: { cpuUsage: 12 }, save: mockSave }
    ];
    const io = { emit: jest.fn() };
    const fakeProvider = { _id: 'prov1', alias: 'AWS US', name: 'aws' };

    const { scaleDown } = require('../../src/services/autoScaler');
    await scaleDown(fakeProvider, fakeServers, io);
    // The secondary server should have been marked terminated
    expect(fakeServers[0].status).toBe('terminated');
    expect(mockSave).toHaveBeenCalled();
  });
});
