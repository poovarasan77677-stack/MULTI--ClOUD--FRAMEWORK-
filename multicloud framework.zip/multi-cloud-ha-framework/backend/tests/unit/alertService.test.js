jest.mock('../../src/models/Alert');
jest.mock('../../src/utils/logger', () => ({ info: jest.fn(), warn: jest.fn(), error: jest.fn() }));

const Alert = require('../../src/models/Alert');
const { createAlert, resolveAlert, acknowledgeAlert } = require('../../src/services/alertService');

describe('Alert Service', () => {
  beforeEach(() => { jest.clearAllMocks(); });

  describe('createAlert', () => {
    it('should create a new alert', async () => {
      const mockSave = jest.fn().mockResolvedValue(true);
      const mockPopulate = jest.fn().mockResolvedValue({ _id: 'abc', title: 'Test', severity: 'critical' });
      const mockAlert = { _id: 'abc', title: 'Test', severity: 'critical', type: 'high_cpu', save: mockSave, populate: jest.fn().mockReturnThis() };
      mockAlert.populate.mockResolvedValue(mockAlert);
      Alert.mockImplementation(() => mockAlert);

      const result = await createAlert({ title: 'Test', message: 'CPU high', severity: 'critical', type: 'high_cpu_new', source: { server: 'unique-srv' } }, null);
      expect(result).toBeTruthy();
    });

    it('should return null for duplicate alerts', async () => {
      const mockAlert = { save: jest.fn().mockResolvedValue(true), populate: jest.fn().mockResolvedValue({}) };
      Alert.mockImplementation(() => mockAlert);

      const data = { title: 'Dup', message: 'dup', severity: 'warning', type: 'dup_type', source: { server: 'dup-srv' } };
      await createAlert(data, null);
      const second = await createAlert(data, null);
      expect(second).toBeNull();
    });
  });

  describe('resolveAlert', () => {
    it('should mark alert as resolved', async () => {
      const resolved = { _id: 'x', status: 'resolved', resolvedAt: new Date() };
      Alert.findByIdAndUpdate = jest.fn().mockResolvedValue(resolved);
      const result = await resolveAlert('x', 'admin');
      expect(result.status).toBe('resolved');
    });
  });

  describe('acknowledgeAlert', () => {
    it('should mark alert as acknowledged', async () => {
      const acked = { _id: 'x', status: 'acknowledged' };
      Alert.findByIdAndUpdate = jest.fn().mockResolvedValue(acked);
      const result = await acknowledgeAlert('x', 'admin');
      expect(result.status).toBe('acknowledged');
    });
  });
});
