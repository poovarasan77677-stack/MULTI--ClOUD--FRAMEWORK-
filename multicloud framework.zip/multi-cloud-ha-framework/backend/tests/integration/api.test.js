const request = require('supertest');

jest.mock('../../src/config/database',         () => jest.fn().mockResolvedValue({}));
jest.mock('../../src/services/healthMonitor',  () => ({ startHealthMonitor:  jest.fn() }));
jest.mock('../../src/services/autoScaler',     () => ({ startAutoScaler:     jest.fn() }));
jest.mock('../../src/services/failoverService',() => ({ startFailoverWatcher:jest.fn() }));
jest.mock('../../src/services/metricsService', () => ({ setupMetrics:        jest.fn() }));
jest.mock('../../src/services/socketService',  () => jest.fn());

const mockChain = { populate:jest.fn().mockReturnThis(), sort:jest.fn().mockReturnThis(), limit:jest.fn().mockReturnThis(), skip:jest.fn().mockResolvedValue([]) };

jest.mock('../../src/models/CloudProvider', () => {
  const m = { find:jest.fn().mockResolvedValue([]), findById:jest.fn().mockResolvedValue(null), countDocuments:jest.fn().mockResolvedValue(0), insertMany:jest.fn().mockResolvedValue([]), getPrimaryProvider:jest.fn().mockResolvedValue(null), getFailoverTargets:jest.fn().mockResolvedValue([]) };
  const ctor = jest.fn().mockImplementation(() => ({ save:jest.fn().mockResolvedValue({}) }));
  return Object.assign(ctor, m);
});
jest.mock('../../src/models/Server', () => { const m = { find:jest.fn().mockResolvedValue([]), deleteMany:jest.fn().mockResolvedValue({}) }; return Object.assign(jest.fn().mockImplementation(()=>({save:jest.fn().mockResolvedValue({})})), m); });
jest.mock('../../src/models/Alert',  () => { const m = { find:jest.fn().mockReturnValue(mockChain), countDocuments:jest.fn().mockResolvedValue(0) }; return Object.assign(jest.fn().mockImplementation(()=>({save:jest.fn().mockResolvedValue({}),populate:jest.fn().mockReturnThis()})), m); });
jest.mock('../../src/models/FailoverEvent', () => { const m = { find:jest.fn().mockReturnValue(mockChain), findOne:jest.fn().mockResolvedValue(null), countDocuments:jest.fn().mockResolvedValue(0), aggregate:jest.fn().mockResolvedValue([]) }; return Object.assign(jest.fn().mockImplementation(()=>({save:jest.fn().mockResolvedValue({})})), m); });
jest.mock('../../src/models/User', () => Object.assign(jest.fn(), { findOne:jest.fn().mockResolvedValue(null) }));

const mongoose = require('mongoose');
jest.spyOn(mongoose.connection, 'readyState', 'get').mockReturnValue(1);

const { app } = require('../../src/app');

describe('Health endpoints', () => {
  it('GET /api/health/live → 200', async () => {
    const r = await request(app).get('/api/health/live');
    expect(r.status).toBe(200);
    expect(r.body.status).toBe('ok');
  });
  it('GET /api/health/ready → 200 when db connected', async () => {
    const r = await request(app).get('/api/health/ready');
    expect(r.status).toBe(200);
    expect(r.body.ready).toBe(true);
  });
});

describe('Cloud endpoints', () => {
  it('GET /api/clouds → 200 with providers array', async () => {
    const r = await request(app).get('/api/clouds');
    expect(r.status).toBe(200);
    expect(Array.isArray(r.body.providers)).toBe(true);
  });
});

describe('Alert endpoints', () => {
  it('GET /api/alerts → 200', async () => {
    const r = await request(app).get('/api/alerts');
    expect(r.status).toBe(200);
    expect(r.body).toHaveProperty('alerts');
  });
  it('GET /api/alerts/summary → 200', async () => {
    const r = await request(app).get('/api/alerts/summary');
    expect(r.status).toBe(200);
    expect(r.body).toHaveProperty('active');
  });
});

describe('Load Balancer endpoints', () => {
  it('GET /api/loadbalancer/config → 200', async () => {
    const r = await request(app).get('/api/loadbalancer/config');
    expect(r.status).toBe(200);
    expect(r.body).toHaveProperty('algorithm');
  });
  it('GET /api/loadbalancer/traffic → 200', async () => {
    const r = await request(app).get('/api/loadbalancer/traffic');
    expect(r.status).toBe(200);
    expect(r.body).toHaveProperty('data');
  });
});

describe('Failover endpoints', () => {
  it('GET /api/failover → 200', async () => {
    const r = await request(app).get('/api/failover');
    expect(r.status).toBe(200);
  });
  it('POST /api/failover/trigger without body → 400', async () => {
    const r = await request(app).post('/api/failover/trigger').send({});
    expect(r.status).toBe(400);
  });
});

describe('404 handler', () => {
  it('unknown routes → 404', async () => {
    const r = await request(app).get('/api/does-not-exist-xyz');
    expect(r.status).toBe(404);
  });
});
