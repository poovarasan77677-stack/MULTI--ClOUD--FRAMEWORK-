const request = require('supertest');

jest.mock('../../src/config/database',         () => jest.fn().mockResolvedValue({}));
jest.mock('../../src/services/healthMonitor',  () => ({ startHealthMonitor:  jest.fn() }));
jest.mock('../../src/services/autoScaler',     () => ({ startAutoScaler:     jest.fn() }));
jest.mock('../../src/services/failoverService',() => ({ startFailoverWatcher:jest.fn() }));
jest.mock('../../src/services/metricsService', () => ({ setupMetrics:        jest.fn() }));
jest.mock('../../src/services/socketService',  () => jest.fn());
jest.mock('../../src/config/redis',            () => ({ connectRedis: jest.fn().mockResolvedValue(null), getClient: jest.fn().mockReturnValue(null) }));

const mockUser = {
  _id: 'user123', username: 'testadmin', email: 'test@test.com',
  role: 'admin', isActive: true, loginAttempts: 0,
  isLocked: jest.fn().mockReturnValue(false),
  comparePassword: jest.fn().mockResolvedValue(true),
  save: jest.fn().mockResolvedValue({}),
  toJSON: jest.fn().mockReturnValue({ _id: 'user123', username: 'testadmin', role: 'admin' })
};

jest.mock('../../src/models/User', () => {
  const ctor = jest.fn().mockImplementation(() => ({
    ...mockUser, save: jest.fn().mockResolvedValue({})
  }));
  ctor.findOne = jest.fn().mockResolvedValue(null);
  ctor.findById = jest.fn().mockResolvedValue(mockUser);
  return ctor;
});

const mongoose = require('mongoose');
jest.spyOn(mongoose.connection, 'readyState', 'get').mockReturnValue(1);

const { app } = require('../../src/app');
const User = require('../../src/models/User');

describe('Auth Routes', () => {
  beforeEach(() => jest.clearAllMocks());

  describe('POST /api/auth/register', () => {
    it('should return 400 for invalid email', async () => {
      const r = await request(app).post('/api/auth/register').send({ username: 'u', email: 'not-email', password: 'short' });
      expect(r.status).toBe(400);
    });
  });

  describe('POST /api/auth/login', () => {
    it('should return 400 for missing fields', async () => {
      const r = await request(app).post('/api/auth/login').send({});
      expect(r.status).toBe(400);
    });

    it('should return 401 for unknown user', async () => {
      User.findOne.mockResolvedValue(null);
      const r = await request(app).post('/api/auth/login').send({ email: 'nobody@test.com', password: 'Pass@1234' });
      expect(r.status).toBe(401);
    });

    it('should return token for valid credentials', async () => {
      User.findOne.mockResolvedValue({ ...mockUser });
      const r = await request(app).post('/api/auth/login').send({ email: 'test@test.com', password: 'Pass@1234' });
      expect([200, 401, 500]).toContain(r.status); // depends on bcrypt mock
    });
  });

  describe('GET /api/auth/me', () => {
    it('should return 401 without token', async () => {
      const r = await request(app).get('/api/auth/me');
      expect(r.status).toBe(401);
    });
  });
});
