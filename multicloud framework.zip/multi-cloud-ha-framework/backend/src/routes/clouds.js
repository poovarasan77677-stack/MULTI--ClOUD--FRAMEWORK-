const express = require('express');
const CloudProvider = require('../models/CloudProvider');
const Server = require('../models/Server');
const logger = require('../utils/logger');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const providers = await CloudProvider.find().sort({ priority: 1 });
    res.json({ providers, total: providers.length });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const provider = await CloudProvider.findById(req.params.id);
    if (!provider) return res.status(404).json({ error: 'Provider not found' });
    res.json(provider);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.post('/', async (req, res) => {
  try {
    const provider = new CloudProvider(req.body);
    await provider.save();
    res.status(201).json(provider);
  } catch (error) { res.status(400).json({ error: error.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const provider = await CloudProvider.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true, runValidators: true });
    if (!provider) return res.status(404).json({ error: 'Provider not found' });
    res.json(provider);
  } catch (error) { res.status(400).json({ error: error.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await CloudProvider.findByIdAndDelete(req.params.id);
    await Server.deleteMany({ cloudProvider: req.params.id });
    res.json({ message: 'Provider deleted' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.post('/seed/demo', async (req, res) => {
  try {
    const existing = await CloudProvider.countDocuments();
    if (existing > 0) {
      const providers = await CloudProvider.find();
      return res.json({ message: 'Already seeded', providers });
    }
    const demoProviders = [
      { name: 'aws', alias: 'AWS US-East', region: 'us-east-1', status: 'active', priority: 1, isPrimary: true, isFailoverTarget: false, metrics: { cpuUsage: 42, memoryUsage: 58, requestsPerSecond: 1240, latency: 18, errorRate: 0.2, uptimePercentage: 99.98 }, healthCheck: { endpoint: 'mock://aws-health', interval: 30, consecutiveFailures: 0 }, cost: { hourly: 2.40, daily: 57.60, monthly: 1728 }, config: { availabilityZones: ['us-east-1a', 'us-east-1b', 'us-east-1c'] } },
      { name: 'azure', alias: 'Azure East US', region: 'eastus', status: 'active', priority: 2, isPrimary: false, isFailoverTarget: true, metrics: { cpuUsage: 28, memoryUsage: 41, requestsPerSecond: 0, latency: 22, errorRate: 0, uptimePercentage: 100 }, healthCheck: { endpoint: 'mock://azure-health', interval: 30, consecutiveFailures: 0 }, cost: { hourly: 2.10, daily: 50.40, monthly: 1512 } },
      { name: 'gcp', alias: 'GCP US-Central', region: 'us-central1', status: 'active', priority: 3, isPrimary: false, isFailoverTarget: true, metrics: { cpuUsage: 15, memoryUsage: 32, requestsPerSecond: 0, latency: 25, errorRate: 0, uptimePercentage: 100 }, healthCheck: { endpoint: 'mock://gcp-health', interval: 30, consecutiveFailures: 0 }, cost: { hourly: 1.95, daily: 46.80, monthly: 1404 } },
      { name: 'digitalocean', alias: 'DO New York', region: 'nyc3', status: 'active', priority: 4, isPrimary: false, isFailoverTarget: true, metrics: { cpuUsage: 10, memoryUsage: 22, requestsPerSecond: 0, latency: 30, errorRate: 0, uptimePercentage: 99.95 }, healthCheck: { endpoint: 'mock://do-health', interval: 30, consecutiveFailures: 0 }, cost: { hourly: 0.89, daily: 21.36, monthly: 640.8 } }
    ];
    const saved = await CloudProvider.insertMany(demoProviders);
    for (const p of saved) {
      const count = p.isPrimary ? 4 : 2;
      const prefixMap = { aws: 'i', azure: 'vm', gcp: 'gce', digitalocean: 'drop' };
      const servers = Array.from({ length: count }, (_, i) => ({
        name: `${p.alias.replace(/ /g,'-').toLowerCase()}-srv-${i+1}`,
        instanceId: `${prefixMap[p.name]||'srv'}-${Math.random().toString(36).slice(2,10)}`,
        cloudProvider: p._id,
        instanceType: `type-${i+1}`,
        ipAddress: `${10+Math.floor(Math.random()*200)}.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}`,
        privateIp: `10.0.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}`,
        status: 'running', role: ['primary','secondary','replica','loadbalancer'][i%4],
        specs: { vcpus: 2+i, memoryGB: 4+i*2, storageGB: 80+i*20, networkGbps: 1 },
        metrics: { cpuUsage: 20+Math.random()*50, memoryUsage: 30+Math.random()*40, diskUsage: 20+Math.random()*30, networkIn: Math.random()*1000, networkOut: Math.random()*800, uptime: Math.floor(Math.random()*86400*30) },
        healthCheck: { isHealthy: true, lastPingMs: 5+Math.random()*45, lastChecked: new Date(), consecutiveFailures: 0 },
        services: [{ name: 'nginx', port: 80, status: 'running', version: '1.24.0' }, { name: 'app', port: 3000, status: 'running', version: '2.1.0' }]
      }));
      await Server.insertMany(servers);
    }
    res.status(201).json({ message: 'Demo data seeded', providers: saved });
  } catch (error) { logger.error('Seed error:', error); res.status(500).json({ error: error.message }); }
});

module.exports = router;
