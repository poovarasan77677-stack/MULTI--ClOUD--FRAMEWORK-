const express = require('express');
const FailoverEvent = require('../models/FailoverEvent');
const { triggerManualFailover } = require('../services/failoverService');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const events = await FailoverEvent.find()
      .populate('fromProvider','name alias')
      .populate('toProvider','name alias')
      .populate('affectedServers','name instanceId')
      .sort({ createdAt: -1 }).limit(20);
    res.json({ events, total: events.length });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const event = await FailoverEvent.findById(req.params.id)
      .populate('fromProvider').populate('toProvider');
    if (!event) return res.status(404).json({ error: 'Event not found' });
    res.json(event);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.post('/trigger', async (req, res) => {
  try {
    const { fromProviderId, toProviderId, reason } = req.body;
    if (!fromProviderId || !toProviderId) return res.status(400).json({ error: 'fromProviderId and toProviderId required' });
    const ongoingCheck = await FailoverEvent.findOne({ status: 'in_progress' });
    if (ongoingCheck) return res.status(409).json({ error: 'A failover is already in progress', eventId: ongoingCheck._id });
    res.json({ message: 'Failover initiated', status: 'in_progress' });
    triggerManualFailover(fromProviderId, toProviderId, reason, req.io).catch(e => console.error('Failover error:', e));
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/stats/summary', async (req, res) => {
  try {
    const [total, completed, failed, avgDuration] = await Promise.all([
      FailoverEvent.countDocuments(),
      FailoverEvent.countDocuments({ status: 'completed' }),
      FailoverEvent.countDocuments({ status: 'failed' }),
      FailoverEvent.aggregate([{ $match: { status: 'completed', durationMs: { $exists: true } } }, { $group: { _id: null, avg: { $avg: '$durationMs' } } }])
    ]);
    res.json({ total, completed, failed, avgDurationMs: avgDuration[0]?.avg || 0, successRate: total > 0 ? ((completed/total)*100).toFixed(1) : 100 });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

module.exports = router;
