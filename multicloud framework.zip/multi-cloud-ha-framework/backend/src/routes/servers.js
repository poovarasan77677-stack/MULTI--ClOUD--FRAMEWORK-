const express = require('express');
const Server = require('../models/Server');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { provider, status, role } = req.query;
    const filter = {};
    if (provider) filter.cloudProvider = provider;
    if (status) filter.status = status;
    if (role) filter.role = role;
    const servers = await Server.find(filter).populate('cloudProvider', 'name alias region').sort({ createdAt: -1 });
    res.json({ servers, total: servers.length });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/:id', async (req, res) => {
  try {
    const server = await Server.findById(req.params.id).populate('cloudProvider');
    if (!server) return res.status(404).json({ error: 'Server not found' });
    res.json(server);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.post('/', async (req, res) => {
  try {
    const server = new Server(req.body);
    await server.save();
    res.status(201).json(server);
  } catch (error) { res.status(400).json({ error: error.message }); }
});

router.put('/:id', async (req, res) => {
  try {
    const server = await Server.findByIdAndUpdate(req.params.id, { $set: req.body }, { new: true });
    if (!server) return res.status(404).json({ error: 'Server not found' });
    res.json(server);
  } catch (error) { res.status(400).json({ error: error.message }); }
});

router.delete('/:id', async (req, res) => {
  try {
    await Server.findByIdAndUpdate(req.params.id, { status: 'terminated', terminatedAt: new Date() });
    res.json({ message: 'Server terminated' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/:id/metrics', async (req, res) => {
  try {
    const server = await Server.findById(req.params.id, 'name metrics healthCheck');
    if (!server) return res.status(404).json({ error: 'Server not found' });
    res.json({ metrics: server.metrics, healthCheck: server.healthCheck, timestamp: new Date() });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

module.exports = router;
