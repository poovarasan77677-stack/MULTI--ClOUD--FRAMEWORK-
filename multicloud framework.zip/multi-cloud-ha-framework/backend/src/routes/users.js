const express = require('express');
const { body } = require('express-validator');
const User = require('../models/User');
const AuditLog = require('../models/AuditLog');
const { authenticate, authorize } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { sendPaginated } = require('../utils/helpers');
const router = express.Router();

// GET /api/users — list users (admin only)
router.get('/', authenticate, authorize('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 20, role, isActive } = req.query;
    const filter = {};
    if (role) filter.role = role;
    if (isActive !== undefined) filter.isActive = isActive === 'true';
    const skip = (Number(page) - 1) * Number(limit);
    const [users, total] = await Promise.all([
      User.find(filter).select('-password').sort({ createdAt: -1 }).limit(Number(limit)).skip(skip),
      User.countDocuments(filter)
    ]);
    sendPaginated(res, users, total, page, limit);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/users/:id
router.get('/:id', authenticate, authorize('admin', 'operator'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// POST /api/users — create user (admin only)
router.post('/', authenticate, authorize('admin'), [
  body('username').trim().isLength({ min: 3, max: 30 }),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('role').isIn(['admin', 'operator', 'viewer'])
], validate([
  body('username').trim().isLength({ min: 3 }),
  body('email').isEmail(),
  body('password').isLength({ min: 8 }),
]), async (req, res) => {
  try {
    const existing = await User.findOne({ $or: [{ email: req.body.email }, { username: req.body.username }] });
    if (existing) return res.status(409).json({ error: 'Username or email already in use' });
    const user = new User(req.body);
    await user.save();
    await AuditLog.log({ action: 'user_created', userId: req.user._id, username: req.user.username, userRole: req.user.role, resourceId: user._id.toString(), result: 'success' });
    res.status(201).json(user.toJSON());
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// PUT /api/users/:id — update user
router.put('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    const { password, ...updateData } = req.body; // Never allow bulk password update
    const user = await User.findByIdAndUpdate(req.params.id, { $set: updateData }, { new: true, runValidators: true }).select('-password');
    if (!user) return res.status(404).json({ error: 'User not found' });
    await AuditLog.log({ action: 'user_updated', userId: req.user._id, username: req.user.username, userRole: req.user.role, resourceId: req.params.id, result: 'success' });
    res.json(user);
  } catch (err) { res.status(400).json({ error: err.message }); }
});

// PATCH /api/users/:id/toggle — enable/disable user
router.patch('/:id/toggle', authenticate, authorize('admin'), async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    if (user._id.toString() === req.user._id.toString()) return res.status(400).json({ error: 'Cannot deactivate your own account' });
    user.isActive = !user.isActive;
    await user.save();
    res.json({ message: `User ${user.isActive ? 'activated' : 'deactivated'}`, isActive: user.isActive });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// DELETE /api/users/:id (admin only)
router.delete('/:id', authenticate, authorize('admin'), async (req, res) => {
  try {
    if (req.params.id === req.user._id.toString()) return res.status(400).json({ error: 'Cannot delete your own account' });
    const user = await User.findByIdAndDelete(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json({ message: 'User deleted' });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/users/me/activity — current user's last 10 audit entries
router.get('/me/activity', authenticate, async (req, res) => {
  try {
    const AuditLog = require('../models/AuditLog');
    const logs = await AuditLog.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(10);
    res.json({ logs });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
