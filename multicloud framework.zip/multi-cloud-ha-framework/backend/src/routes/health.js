const express = require('express');
const mongoose = require('mongoose');
const CloudProvider = require('../models/CloudProvider');
const Server = require('../models/Server');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const dbState = mongoose.connection.readyState;
    const [providers, servers] = await Promise.all([
      CloudProvider.find({}, 'name alias status metrics').sort({ priority: 1 }),
      Server.find({ status: 'running' }, 'name status healthCheck metrics cloudProvider')
    ]);
    const healthyServers = servers.filter(s => s.healthCheck.isHealthy).length;
    const activeProviders = providers.filter(p => p.status === 'active').length;
    res.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      version: '1.0.0',
      uptime: process.uptime(),
      database: { status: dbState === 1 ? 'connected' : 'disconnected', state: dbState },
      infrastructure: {
        totalProviders: providers.length,
        activeProviders,
        totalServers: servers.length,
        healthyServers,
        healthScore: servers.length > 0 ? ((healthyServers / servers.length) * 100).toFixed(1) : 100
      },
      providers: providers.map(p => ({ name: p.alias, status: p.status, cpu: p.metrics.cpuUsage?.toFixed(1), uptime: p.metrics.uptimePercentage?.toFixed(2) }))
    });
  } catch (error) {
    res.status(503).json({ status: 'unhealthy', error: error.message });
  }
});

router.get('/live', (req, res) => res.json({ status: 'ok', timestamp: Date.now() }));
router.get('/ready', async (req, res) => {
  const dbReady = mongoose.connection.readyState === 1;
  res.status(dbReady ? 200 : 503).json({ ready: dbReady, db: dbReady ? 'connected' : 'disconnected' });
});

module.exports = router;

router.get('/deep', async (req, res) => {
  const checks = {};
  const startMs = Date.now();

  // DB check
  try {
    await require('../models/CloudProvider').countDocuments();
    checks.database = { status: 'ok', responseMs: Date.now() - startMs };
  } catch (e) {
    checks.database = { status: 'error', message: e.message };
  }

  // Redis check
  try {
    const { getClient } = require('../config/redis');
    const client = getClient();
    if (client) {
      await client.ping();
      checks.redis = { status: 'ok' };
    } else {
      checks.redis = { status: 'unavailable' };
    }
  } catch (e) {
    checks.redis = { status: 'error', message: e.message };
  }

  const allOk = Object.values(checks).every(c => c.status === 'ok' || c.status === 'unavailable');
  res.status(allOk ? 200 : 503).json({
    status: allOk ? 'healthy' : 'degraded',
    checks,
    uptime: process.uptime(),
    memoryMB: (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(1),
    timestamp: new Date().toISOString()
  });
});
