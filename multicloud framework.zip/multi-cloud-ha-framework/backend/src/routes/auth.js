const express = require('express');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const User = require('../models/User');
const { authenticate } = require('../middleware/auth');
const logger = require('../utils/logger');

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'multi-cloud-ha-super-secret-key-change-in-prod';
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || '24h';

const generateToken = (userId) => jwt.sign({ userId }, JWT_SECRET, { expiresIn: JWT_EXPIRES_IN });

// POST /api/auth/register
router.post('/register', [
  body('username').trim().isLength({ min: 3, max: 30 }),
  body('email').isEmail().normalizeEmail(),
  body('password').isLength({ min: 8 }),
  body('role').optional().isIn(['admin', 'operator', 'viewer'])
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { username, email, password, role, firstName, lastName } = req.body;
    const existing = await User.findOne({ $or: [{ email }, { username }] });
    if (existing) return res.status(409).json({ error: 'Username or email already exists' });

    const user = new User({ username, email, password, role, firstName, lastName });
    await user.save();

    const token = generateToken(user._id);
    res.status(201).json({ message: 'User registered successfully', token, user });
  } catch (error) {
    logger.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// POST /api/auth/login
router.post('/login', [
  body('email').isEmail().normalizeEmail(),
  body('password').notEmpty()
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { email, password } = req.body;
    const user = await User.findOne({ email }).select('+password');

    if (!user || !user.isActive) return res.status(401).json({ error: 'Invalid credentials' });
    if (user.isLocked()) return res.status(423).json({ error: 'Account locked. Try again later.' });

    const isValid = await user.comparePassword(password);
    if (!isValid) {
      user.loginAttempts = (user.loginAttempts || 0) + 1;
      if (user.loginAttempts >= 5) {
        user.lockUntil = new Date(Date.now() + 15 * 60 * 1000);
      }
      await user.save();
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    user.loginAttempts = 0;
    user.lockUntil = undefined;
    user.lastLogin = new Date();
    await user.save();

    const token = generateToken(user._id);
    res.json({ token, user, expiresIn: JWT_EXPIRES_IN });
  } catch (error) {
    logger.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// GET /api/auth/me
router.get('/me', authenticate, (req, res) => {
  res.json({ user: req.user });
});

// POST /api/auth/logout
router.post('/logout', authenticate, (req, res) => {
  // In production, blacklist the token in Redis
  res.json({ message: 'Logged out successfully' });
});

// POST /api/auth/seed - Create demo admin user
router.post('/seed', async (req, res) => {
  try {
    const exists = await User.findOne({ email: 'admin@multicloud-ha.io' });
    if (exists) return res.json({ message: 'Demo user already exists', credentials: { email: 'admin@multicloud-ha.io', password: 'Admin@1234' } });

    const admin = new User({
      username: 'admin',
      email: 'admin@multicloud-ha.io',
      password: 'Admin@1234',
      role: 'admin',
      firstName: 'System',
      lastName: 'Administrator'
    });
    await admin.save();

    const operator = new User({
      username: 'operator',
      email: 'operator@multicloud-ha.io',
      password: 'Operator@1234',
      role: 'operator',
      firstName: 'Cloud',
      lastName: 'Operator'
    });
    await operator.save();

    res.json({
      message: 'Demo users created',
      credentials: [
        { role: 'admin', email: 'admin@multicloud-ha.io', password: 'Admin@1234' },
        { role: 'operator', email: 'operator@multicloud-ha.io', password: 'Operator@1234' }
      ]
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
