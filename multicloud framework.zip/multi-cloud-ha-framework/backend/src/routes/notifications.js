const express = require('express');
const { sendSlack } = require('../services/notificationService');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

router.post('/test', authenticate, authorize('admin'), async (req, res) => {
  try {
    const result = await sendSlack({ title: 'Test Notification', message: 'HA Framework notification test', severity: 'info', type: 'info' });
    res.json({ message: 'Test notification sent', result });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/channels', authenticate, (req, res) => {
  res.json({
    channels: [
      { name: 'Slack',      configured: !!process.env.SLACK_WEBHOOK_URL,   enabled: true  },
      { name: 'PagerDuty',  configured: !!process.env.PAGERDUTY_API_KEY,   enabled: true  },
      { name: 'Email',      configured: !!process.env.SMTP_HOST,           enabled: false },
    ]
  });
});

module.exports = router;
