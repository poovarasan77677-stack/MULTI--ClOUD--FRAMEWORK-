const express = require('express');
const Alert = require('../models/Alert');
const { resolveAlert, acknowledgeAlert } = require('../services/alertService');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const { status, severity, type, limit = 50, page = 1 } = req.query;
    const filter = {};
    if (status) filter.status = status;
    if (severity) filter.severity = severity;
    if (type) filter.type = type;
    const [alerts, total] = await Promise.all([
      Alert.find(filter).populate('source.cloudProvider','name alias').populate('source.server','name instanceId').sort({ createdAt: -1 }).limit(Number(limit)).skip((Number(page)-1)*Number(limit)),
      Alert.countDocuments(filter)
    ]);
    res.json({ alerts, total, page: Number(page), pages: Math.ceil(total/Number(limit)) });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/summary', async (req, res) => {
  try {
    const [active, critical, warnings] = await Promise.all([
      Alert.countDocuments({ status: 'active' }),
      Alert.countDocuments({ status: 'active', severity: { $in: ['critical','emergency'] } }),
      Alert.countDocuments({ status: 'active', severity: 'warning' })
    ]);
    res.json({ active, critical, warnings, info: active - critical - warnings });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.patch('/:id/acknowledge', async (req, res) => {
  try {
    const alert = await acknowledgeAlert(req.params.id, req.body.userId || 'system');
    if (!alert) return res.status(404).json({ error: 'Alert not found' });
    if (req.io) req.io.emit('alert:acknowledged', alert);
    res.json(alert);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.patch('/:id/resolve', async (req, res) => {
  try {
    const alert = await resolveAlert(req.params.id, req.body.userId || 'system');
    if (!alert) return res.status(404).json({ error: 'Alert not found' });
    if (req.io) req.io.emit('alert:resolved', alert);
    res.json(alert);
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.delete('/resolved', async (req, res) => {
  try {
    const result = await Alert.deleteMany({ status: { $in: ['resolved','suppressed'] }, createdAt: { $lt: new Date(Date.now() - 7*24*60*60*1000) } });
    res.json({ message: `Deleted ${result.deletedCount} old resolved alerts` });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

module.exports = router;
