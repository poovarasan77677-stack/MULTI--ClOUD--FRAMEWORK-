const express = require('express');
const AuditLog = require('../models/AuditLog');
const { authenticate, authorize } = require('../middleware/auth');
const router = express.Router();

// GET /api/audit — paginated audit log (admin only)
router.get('/', authenticate, authorize('admin'), async (req, res) => {
  try {
    const { page = 1, limit = 50, action, userId, from, to } = req.query;
    const filter = {};
    if (action) filter.action = action;
    if (userId) filter.userId = userId;
    if (from || to) {
      filter.createdAt = {};
      if (from) filter.createdAt.$gte = new Date(from);
      if (to)   filter.createdAt.$lte = new Date(to);
    }
    const [logs, total] = await Promise.all([
      AuditLog.find(filter)
        .populate('userId', 'username email role')
        .sort({ createdAt: -1 })
        .limit(Number(limit))
        .skip((Number(page)-1)*Number(limit)),
      AuditLog.countDocuments(filter)
    ]);
    res.json({ logs, total, page: Number(page), pages: Math.ceil(total/Number(limit)) });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

// GET /api/audit/summary — action counts for the last 7 days
router.get('/summary', authenticate, authorize('admin','operator'), async (req, res) => {
  try {
    const since = new Date(Date.now() - 7*24*60*60*1000);
    const [total, failures, failovers, byAction] = await Promise.all([
      AuditLog.countDocuments({ createdAt: { $gte: since } }),
      AuditLog.countDocuments({ createdAt: { $gte: since }, result: 'failure' }),
      AuditLog.countDocuments({ createdAt: { $gte: since }, action: { $in: ['failover_triggered','failover_completed'] } }),
      AuditLog.aggregate([
        { $match: { createdAt: { $gte: since } } },
        { $group: { _id: '$action', count: { $sum: 1 } } },
        { $sort: { count: -1 } },
        { $limit: 10 }
      ])
    ]);
    res.json({ total, failures, failovers, byAction });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

module.exports = router;
