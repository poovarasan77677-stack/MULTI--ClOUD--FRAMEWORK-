const express = require('express');
const Server = require('../models/Server');
const CloudProvider = require('../models/CloudProvider');
const router = express.Router();

let lbConfig = {
  algorithm: 'round-robin',
  healthCheckEnabled: true,
  stickySession: false,
  connectionTimeout: 30,
  idleTimeout: 60,
  maxConnections: 10000,
  currentIndex: 0
};

router.get('/config', (req, res) => res.json(lbConfig));

router.put('/config', (req, res) => {
  lbConfig = { ...lbConfig, ...req.body };
  res.json(lbConfig);
});

router.get('/status', async (req, res) => {
  try {
    const servers = await Server.find({ status: 'running', role: { $in: ['primary','secondary'] } }).populate('cloudProvider','alias');
    const healthy = servers.filter(s => s.healthCheck.isHealthy);
    const totalRps = servers.reduce((sum, s) => sum + (s.metrics.networkIn || 0), 0);
    res.json({
      status: healthy.length > 0 ? 'operational' : 'degraded',
      algorithm: lbConfig.algorithm,
      activeBackends: healthy.length,
      totalBackends: servers.length,
      totalRequestsPerSecond: totalRps.toFixed(0),
      backends: servers.map(s => ({
        id: s._id, name: s.name, ip: s.ipAddress,
        provider: s.cloudProvider?.alias,
        healthy: s.healthCheck.isHealthy,
        latency: s.healthCheck.lastPingMs,
        cpu: s.metrics.cpuUsage?.toFixed(1),
        connections: Math.floor(Math.random() * 1000)
      }))
    });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/traffic', (req, res) => {
  const data = Array.from({ length: 60 }, (_, i) => ({
    second: i,
    requests: Math.floor(800 + Math.sin(i * 0.3) * 200 + Math.random() * 100),
    errors: Math.floor(Math.max(0, Math.random() * 5)),
    latencyMs: (15 + Math.random() * 20).toFixed(1)
  }));
  res.json({ data, timestamp: new Date().toISOString() });
});

module.exports = router;
