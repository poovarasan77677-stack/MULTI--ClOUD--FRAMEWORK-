const express = require('express');
const CloudProvider = require('../models/CloudProvider');
const Server = require('../models/Server');
const Alert = require('../models/Alert');
const FailoverEvent = require('../models/FailoverEvent');
const router = express.Router();

router.get('/dashboard', async (req, res) => {
  try {
    const [providers, servers, activeAlerts, failovers] = await Promise.all([
      CloudProvider.find().sort({ priority: 1 }),
      Server.find({ status: { $ne: 'terminated' } }).populate('cloudProvider', 'name alias'),
      Alert.find({ status: 'active' }).sort({ severity: -1, createdAt: -1 }).limit(10),
      FailoverEvent.find().sort({ createdAt: -1 }).limit(5).populate('fromProvider', 'alias').populate('toProvider', 'alias')
    ]);
    const runningServers = servers.filter(s => s.status === 'running');
    const healthyServers = runningServers.filter(s => s.healthCheck.isHealthy);
    const totalCost = providers.reduce((sum, p) => sum + (p.cost?.monthly || 0), 0);
    const avgCpu = runningServers.length > 0 ? runningServers.reduce((sum, s) => sum + (s.metrics.cpuUsage || 0), 0) / runningServers.length : 0;
    const avgMemory = runningServers.length > 0 ? runningServers.reduce((sum, s) => sum + (s.metrics.memoryUsage || 0), 0) / runningServers.length : 0;
    res.json({
      overview: {
        totalProviders: providers.length,
        activeProviders: providers.filter(p => p.status === 'active').length,
        totalServers: servers.length,
        runningServers: runningServers.length,
        healthyServers: healthyServers.length,
        healthScore: runningServers.length > 0 ? ((healthyServers.length / runningServers.length) * 100).toFixed(1) : 100,
        totalMonthlyCost: totalCost.toFixed(2),
        avgCpu: avgCpu.toFixed(1),
        avgMemory: avgMemory.toFixed(1),
        activeAlerts: activeAlerts.length,
        criticalAlerts: activeAlerts.filter(a => a.severity === 'critical' || a.severity === 'emergency').length
      },
      providers,
      servers: runningServers.slice(0, 20),
      activeAlerts,
      recentFailovers: failovers,
      timestamp: new Date().toISOString()
    });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/timeseries', async (req, res) => {
  try {
    const points = 24;
    const now = Date.now();
    const data = Array.from({ length: points }, (_, i) => ({
      timestamp: new Date(now - (points - 1 - i) * 3600000).toISOString(),
      cpu: 30 + Math.sin(i * 0.5) * 15 + Math.random() * 10,
      memory: 45 + Math.cos(i * 0.3) * 10 + Math.random() * 8,
      requests: 800 + Math.sin(i * 0.8) * 300 + Math.random() * 100,
      latency: 15 + Math.abs(Math.sin(i * 0.4)) * 20 + Math.random() * 5,
      errors: Math.max(0, Math.sin(i * 1.2) * 5 + Math.random() * 3)
    }));
    res.json({ data, interval: '1h', points });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

router.get('/costs', async (req, res) => {
  try {
    const providers = await CloudProvider.find({}, 'name alias cost');
    const breakdown = providers.map(p => ({
      provider: p.alias,
      name: p.name,
      hourly: p.cost?.hourly || 0,
      daily: p.cost?.daily || 0,
      monthly: p.cost?.monthly || 0
    }));
    const total = breakdown.reduce((sum, p) => ({ hourly: sum.hourly + p.hourly, daily: sum.daily + p.daily, monthly: sum.monthly + p.monthly }), { hourly: 0, daily: 0, monthly: 0 });
    res.json({ breakdown, total, currency: 'USD' });
  } catch (error) { res.status(500).json({ error: error.message }); }
});

module.exports = router;

router.get('/providers/comparison', async (req, res) => {
  try {
    const CloudProvider = require('../models/CloudProvider');
    const providers = await CloudProvider.find({}, 'name alias metrics cost status');
    res.json({ providers, timestamp: new Date().toISOString() });
  } catch (err) { res.status(500).json({ error: err.message }); }
});

router.get('/slo', async (req, res) => {
  res.json({
    availability: { target: 99.9,  actual: 99.78, status: 'at_risk'  },
    latency_p95:  { target: 800,   actual: 320,   status: 'healthy'  },
    error_rate:   { target: 1,     actual: 0.18,  status: 'healthy'  },
    failover_rto: { target: 300,   actual: 87,    status: 'healthy'  },
    timestamp: new Date().toISOString()
  });
});
