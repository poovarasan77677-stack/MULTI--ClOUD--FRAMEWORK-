const { getClient } = require('../config/redis');
const logger = require('../utils/logger');

const DEFAULT_TTL = 30; // seconds

const get = async (key) => {
  const client = getClient();
  if (!client) return null;
  try {
    const value = await client.get(key);
    return value ? JSON.parse(value) : null;
  } catch (err) {
    logger.warn(`Cache GET failed for ${key}:`, err.message);
    return null;
  }
};

const set = async (key, value, ttlSeconds = DEFAULT_TTL) => {
  const client = getClient();
  if (!client) return false;
  try {
    await client.setEx(key, ttlSeconds, JSON.stringify(value));
    return true;
  } catch (err) {
    logger.warn(`Cache SET failed for ${key}:`, err.message);
    return false;
  }
};

const del = async (key) => {
  const client = getClient();
  if (!client) return false;
  try { await client.del(key); return true; }
  catch (err) { logger.warn(`Cache DEL failed for ${key}:`, err.message); return false; }
};

const invalidatePattern = async (pattern) => {
  const client = getClient();
  if (!client) return;
  try {
    const keys = await client.keys(pattern);
    if (keys.length > 0) await client.del(keys);
    logger.info(`Invalidated ${keys.length} cache keys matching ${pattern}`);
  } catch (err) {
    logger.warn(`Cache pattern invalidation failed:`, err.message);
  }
};

/** Cache-aside wrapper: get from cache or fetch and cache */
const getOrSet = async (key, fetchFn, ttlSeconds = DEFAULT_TTL) => {
  const cached = await get(key);
  if (cached !== null) return cached;
  const fresh = await fetchFn();
  await set(key, fresh, ttlSeconds);
  return fresh;
};

module.exports = { get, set, del, invalidatePattern, getOrSet };
