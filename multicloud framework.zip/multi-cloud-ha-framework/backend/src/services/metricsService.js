const client = require('prom-client');

let metricsInitialized = false;

const metrics = {};

const setupMetrics = () => {
  if (metricsInitialized) return;

  // Default metrics (CPU, memory, event loop lag, etc.)
  client.collectDefaultMetrics({ prefix: 'ha_framework_' });

  // Custom metrics
  metrics.httpRequestsTotal = new client.Counter({
    name: 'ha_http_requests_total',
    help: 'Total HTTP requests',
    labelNames: ['method', 'route', 'status']
  });

  metrics.httpRequestDuration = new client.Histogram({
    name: 'ha_http_request_duration_seconds',
    help: 'HTTP request duration',
    labelNames: ['method', 'route', 'status'],
    buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1, 2, 5]
  });

  metrics.serversTotal = new client.Gauge({
    name: 'ha_servers_total',
    help: 'Total number of servers',
    labelNames: ['provider', 'status']
  });

  metrics.serversHealthy = new client.Gauge({
    name: 'ha_servers_healthy',
    help: 'Healthy servers count',
    labelNames: ['provider']
  });

  metrics.cpuUsage = new client.Gauge({
    name: 'ha_server_cpu_percent',
    help: 'Server CPU usage percentage',
    labelNames: ['server', 'provider']
  });

  metrics.memoryUsage = new client.Gauge({
    name: 'ha_server_memory_percent',
    help: 'Server memory usage percentage',
    labelNames: ['server', 'provider']
  });

  metrics.failoverTotal = new client.Counter({
    name: 'ha_failover_total',
    help: 'Total failover events',
    labelNames: ['from_provider', 'to_provider', 'trigger']
  });

  metrics.failoverDuration = new client.Histogram({
    name: 'ha_failover_duration_seconds',
    help: 'Failover completion duration',
    buckets: [10, 30, 60, 120, 300, 600]
  });

  metrics.alertsTotal = new client.Counter({
    name: 'ha_alerts_total',
    help: 'Total alerts created',
    labelNames: ['severity', 'type']
  });

  metrics.activeAlerts = new client.Gauge({
    name: 'ha_active_alerts',
    help: 'Current active alerts',
    labelNames: ['severity']
  });

  metrics.providerLatency = new client.Gauge({
    name: 'ha_provider_latency_ms',
    help: 'Provider health check latency in milliseconds',
    labelNames: ['provider']
  });

  metrics.scalingEvents = new client.Counter({
    name: 'ha_scaling_events_total',
    help: 'Total auto-scaling events',
    labelNames: ['direction', 'provider']
  });

  metrics.uptimePercent = new client.Gauge({
    name: 'ha_provider_uptime_percent',
    help: 'Provider uptime percentage',
    labelNames: ['provider']
  });

  metricsInitialized = true;
};

const getMetrics = () => metrics;

module.exports = { setupMetrics, getMetrics };
