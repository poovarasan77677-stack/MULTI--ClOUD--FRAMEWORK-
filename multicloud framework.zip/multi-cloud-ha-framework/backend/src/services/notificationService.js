const axios = require('axios');
const logger = require('../utils/logger');

const SLACK_WEBHOOK   = process.env.SLACK_WEBHOOK_URL;
const PAGERDUTY_KEY   = process.env.PAGERDUTY_API_KEY;
const ALERT_EMAIL     = process.env.ALERT_EMAIL;

const SEVERITY_EMOJI = { info:'ℹ️', warning:'⚠️', critical:'🔴', emergency:'🚨' };
const SEVERITY_COLOR = { info:'#00d4ff', warning:'#ffd700', critical:'#ff4060', emergency:'#ff0040' };

/**
 * Send Slack notification
 */
const sendSlack = async (alert) => {
  if (!SLACK_WEBHOOK) return;
  try {
    await axios.post(SLACK_WEBHOOK, {
      attachments: [{
        color: SEVERITY_COLOR[alert.severity] || '#888',
        blocks: [
          {
            type: 'header',
            text: { type: 'plain_text', text: `${SEVERITY_EMOJI[alert.severity]||'⚠️'} ${alert.title}` }
          },
          {
            type: 'section',
            fields: [
              { type: 'mrkdwn', text: `*Severity:* ${alert.severity.toUpperCase()}` },
              { type: 'mrkdwn', text: `*Type:* ${alert.type?.replace(/_/g,' ')}` },
              { type: 'mrkdwn', text: `*Message:* ${alert.message}` },
              { type: 'mrkdwn', text: `*Time:* <!date^${Math.floor(Date.now()/1000)}^{date_time}|now>` }
            ]
          }
        ]
      }]
    }, { timeout: 5000 });
    logger.info(`Slack notification sent for alert: ${alert.title}`);
    return { channel: 'slack', success: true };
  } catch (err) {
    logger.warn(`Slack notification failed: ${err.message}`);
    return { channel: 'slack', success: false };
  }
};

/**
 * Send PagerDuty alert
 */
const sendPagerDuty = async (alert) => {
  if (!PAGERDUTY_KEY || alert.severity === 'info') return;
  try {
    const pd_severity = { warning:'warning', critical:'critical', emergency:'critical' }[alert.severity] || 'warning';
    await axios.post('https://events.pagerduty.com/v2/enqueue', {
      routing_key:  PAGERDUTY_KEY,
      event_action: 'trigger',
      payload: {
        summary:   alert.title,
        source:    'multi-cloud-ha-framework',
        severity:  pd_severity,
        custom_details: { message: alert.message, type: alert.type }
      },
      dedup_key: `ha-${alert.type}-${alert._id}`
    }, { timeout: 8000 });
    logger.info(`PagerDuty alert sent: ${alert.title}`);
    return { channel: 'pagerduty', success: true };
  } catch (err) {
    logger.warn(`PagerDuty failed: ${err.message}`);
    return { channel: 'pagerduty', success: false };
  }
};

/**
 * Main notification dispatcher — routes by severity
 */
const notify = async (alert) => {
  const results = [];
  const critical = ['critical','emergency'].includes(alert.severity);

  // Always try Slack
  const slackResult = await sendSlack(alert);
  if (slackResult) results.push(slackResult);

  // PagerDuty for critical+
  if (critical) {
    const pdResult = await sendPagerDuty(alert);
    if (pdResult) results.push(pdResult);
  }

  return results;
};

module.exports = { notify, sendSlack, sendPagerDuty };
