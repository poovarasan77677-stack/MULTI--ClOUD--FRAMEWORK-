const Alert = require('../models/Alert');
const logger = require('../utils/logger');

// Deduplication cache to avoid spam
const alertCache = new Map();
const DEDUP_WINDOW_MS = 5 * 60 * 1000; // 5 minutes

const createAlert = async (alertData, io) => {
  try {
    // Deduplication by type + source
    const cacheKey = `${alertData.type}:${alertData.source?.server || ''}:${alertData.source?.cloudProvider || ''}`;
    const lastAlerted = alertCache.get(cacheKey);
    if (lastAlerted && Date.now() - lastAlerted < DEDUP_WINDOW_MS) {
      return null; // Suppress duplicate
    }
    alertCache.set(cacheKey, Date.now());

    const alert = new Alert(alertData);
    await alert.save();
    await alert.populate('source.cloudProvider', 'name alias');
    await alert.populate('source.server', 'name instanceId');

    logger.info(`🚨 Alert created: [${alert.severity.toUpperCase()}] ${alert.title}`);

    if (io) {
      io.emit('alert:new', alert);
    }

    return alert;
  } catch (error) {
    logger.error('Failed to create alert:', error.message);
    return null;
  }
};

const resolveAlert = async (alertId, resolvedBy) => {
  const alert = await Alert.findByIdAndUpdate(
    alertId,
    { status: 'resolved', resolvedAt: new Date(), acknowledgedBy: resolvedBy },
    { new: true }
  );
  return alert;
};

const acknowledgeAlert = async (alertId, userId) => {
  const alert = await Alert.findByIdAndUpdate(
    alertId,
    { status: 'acknowledged', acknowledgedAt: new Date(), acknowledgedBy: userId },
    { new: true }
  );
  return alert;
};

module.exports = { createAlert, resolveAlert, acknowledgeAlert };
