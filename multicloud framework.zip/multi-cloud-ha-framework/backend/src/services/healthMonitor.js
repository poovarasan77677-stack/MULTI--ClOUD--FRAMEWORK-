const cron = require('node-cron');
const axios = require('axios');
const logger = require('../utils/logger');
const CloudProvider = require('../models/CloudProvider');
const Server = require('../models/Server');
const Alert = require('../models/Alert');
const { createAlert } = require('./alertService');

const HEALTH_CHECK_INTERVAL = process.env.HEALTH_CHECK_INTERVAL || '*/30 * * * * *'; // every 30 seconds
const PING_TIMEOUT = parseInt(process.env.PING_TIMEOUT) || 5000;

// Simulated health check for demo (in production, use real endpoints)
const performHealthCheck = async (endpoint, timeout = PING_TIMEOUT) => {
  const start = Date.now();
  try {
    if (!endpoint || endpoint.startsWith('mock://')) {
      // Simulate realistic latency + occasional failures for demo
      const latency = Math.random() * 100 + 10;
      const failureChance = Math.random();
      await new Promise(r => setTimeout(r, latency));
      if (failureChance < 0.02) throw new Error('Simulated timeout');
      return { healthy: true, latencyMs: Math.round(latency) };
    }
    const response = await axios.get(endpoint, {
      timeout,
      validateStatus: (status) => status < 500
    });
    const latencyMs = Date.now() - start;
    return { healthy: response.status < 400, latencyMs, statusCode: response.status };
  } catch (error) {
    return { healthy: false, latencyMs: Date.now() - start, error: error.message };
  }
};

const updateServerHealth = async (server, io) => {
  const result = await performHealthCheck(server.healthCheck?.endpoint);

  const wasHealthy = server.healthCheck.isHealthy;
  server.healthCheck.isHealthy = result.healthy;
  server.healthCheck.lastPingMs = result.latencyMs;
  server.healthCheck.lastChecked = new Date();

  // Simulate realistic metric fluctuations
  const baseCpu = server.metrics.cpuUsage || 30;
  const baseMemory = server.metrics.memoryUsage || 45;
  server.metrics.cpuUsage = Math.min(100, Math.max(0, baseCpu + (Math.random() - 0.48) * 8));
  server.metrics.memoryUsage = Math.min(100, Math.max(0, baseMemory + (Math.random() - 0.49) * 5));
  server.metrics.networkIn = Math.random() * 1000 + 100;
  server.metrics.networkOut = Math.random() * 800 + 50;
  server.metrics.uptime = (server.metrics.uptime || 0) + 30;

  if (result.healthy) {
    server.healthCheck.consecutiveFailures = 0;
    if (wasHealthy === false) {
      server.status = 'running';
      logger.info(`Server ${server.name} recovered`);
      await createAlert({
        title: `Server Recovered: ${server.name}`,
        message: `Server ${server.name} is now healthy (latency: ${result.latencyMs}ms)`,
        severity: 'info',
        type: 'server_down',
        source: { server: server._id }
      }, io);
    }
  } else {
    server.healthCheck.consecutiveFailures = (server.healthCheck.consecutiveFailures || 0) + 1;
    if (server.healthCheck.consecutiveFailures >= 3) {
      server.status = 'error';
      server.healthCheck.isHealthy = false;
      logger.warn(`Server ${server.name} marked as unhealthy`);
      if (!wasHealthy) return await server.save(); // Avoid duplicate alerts
      await createAlert({
        title: `Server Down: ${server.name}`,
        message: `Server ${server.name} failed health check (${server.healthCheck.consecutiveFailures} consecutive failures)`,
        severity: 'critical',
        type: 'server_down',
        source: { server: server._id }
      }, io);
    }
  }

  // High CPU alert
  if (server.metrics.cpuUsage > 85) {
    await createAlert({
      title: `High CPU: ${server.name}`,
      message: `CPU usage at ${server.metrics.cpuUsage.toFixed(1)}% on ${server.name}`,
      severity: server.metrics.cpuUsage > 95 ? 'critical' : 'warning',
      type: 'high_cpu',
      source: { server: server._id },
      metadata: { cpuUsage: server.metrics.cpuUsage }
    }, io);
  }

  await server.save();
};

const updateProviderHealth = async (provider, io) => {
  const servers = await Server.find({ cloudProvider: provider._id, status: { $ne: 'terminated' } });
  const healthyCount = servers.filter(s => s.healthCheck.isHealthy).length;
  const totalCount = servers.length;

  // Update provider metrics based on servers
  if (totalCount > 0) {
    const avgCpu = servers.reduce((sum, s) => sum + (s.metrics.cpuUsage || 0), 0) / totalCount;
    const avgMemory = servers.reduce((sum, s) => sum + (s.metrics.memoryUsage || 0), 0) / totalCount;
    provider.metrics.cpuUsage = avgCpu;
    provider.metrics.memoryUsage = avgMemory;
    provider.metrics.requestsPerSecond = Math.random() * 500 + 100;
    provider.metrics.latency = Math.random() * 50 + 10;
    provider.metrics.errorRate = totalCount > 0 ? ((totalCount - healthyCount) / totalCount) * 100 : 0;
    provider.metrics.uptimePercentage = totalCount > 0 ? (healthyCount / totalCount) * 100 : 100;
  }

  // Simulate occasional provider status changes
  const rand = Math.random();
  if (rand < 0.005 && provider.status === 'active') {
    provider.status = 'degraded';
    await createAlert({
      title: `Provider Degraded: ${provider.alias}`,
      message: `Cloud provider ${provider.alias} (${provider.name}) is experiencing degraded performance`,
      severity: 'warning',
      type: 'provider_outage',
      source: { cloudProvider: provider._id }
    }, io);
  } else if (provider.status === 'degraded' && rand > 0.7) {
    provider.status = 'active';
  }

  provider.healthCheck.lastChecked = new Date();
  await provider.save();

  // Emit real-time update
  if (io) {
    io.emit('provider:update', {
      _id: provider._id,
      status: provider.status,
      metrics: provider.metrics,
      healthCheck: provider.healthCheck
    });
  }
};

const startHealthMonitor = (io) => {
  cron.schedule(HEALTH_CHECK_INTERVAL, async () => {
    try {
      const [servers, providers] = await Promise.all([
        Server.find({ status: { $nin: ['terminated', 'maintenance'] } }).limit(50),
        CloudProvider.find({ status: { $ne: 'offline' } })
      ]);

      await Promise.all([
        ...servers.map(s => updateServerHealth(s, io).catch(e => logger.error(`Server health error: ${e.message}`))),
        ...providers.map(p => updateProviderHealth(p, io).catch(e => logger.error(`Provider health error: ${e.message}`)))
      ]);

      // Emit aggregated stats
      if (io) {
        const stats = {
          totalServers: servers.length,
          healthyServers: servers.filter(s => s.healthCheck.isHealthy).length,
          timestamp: new Date().toISOString()
        };
        io.emit('stats:update', stats);
      }
    } catch (error) {
      logger.error('Health monitor error:', error.message);
    }
  });

  logger.info(`Health monitor scheduled: ${HEALTH_CHECK_INTERVAL}`);
};

module.exports = { startHealthMonitor, performHealthCheck };
