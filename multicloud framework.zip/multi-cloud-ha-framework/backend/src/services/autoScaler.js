const cron = require('node-cron');
const { v4: uuidv4 } = require('uuid');
const logger = require('../utils/logger');
const Server = require('../models/Server');
const CloudProvider = require('../models/CloudProvider');
const Alert = require('../models/Alert');
const { createAlert } = require('./alertService');

const AUTOSCALER_INTERVAL = '*/45 * * * * *';
const INSTANCE_TYPES = {
  aws: ['t3.micro', 't3.small', 't3.medium', 't3.large', 'm5.large', 'm5.xlarge', 'c5.large'],
  azure: ['Standard_B1s', 'Standard_B2s', 'Standard_D2s_v3', 'Standard_D4s_v3', 'Standard_F2s'],
  gcp: ['e2-micro', 'e2-small', 'e2-medium', 'n1-standard-1', 'n1-standard-2', 'n2-standard-2'],
  digitalocean: ['s-1vcpu-1gb', 's-1vcpu-2gb', 's-2vcpu-2gb', 's-4vcpu-8gb', 'g-2vcpu-8gb']
};

const REGIONS = {
  aws: ['us-east-1a', 'us-east-1b', 'us-west-2a', 'eu-west-1a'],
  azure: ['eastus', 'westus2', 'eastus2', 'westeurope'],
  gcp: ['us-central1-a', 'us-east1-b', 'europe-west1-b'],
  digitalocean: ['nyc3', 'sfo3', 'lon1', 'fra1']
};

const generateInstanceId = (providerName) => {
  const prefixes = { aws: 'i', azure: 'vm', gcp: 'gce', digitalocean: 'droplet' };
  const prefix = prefixes[providerName] || 'srv';
  return `${prefix}-${uuidv4().slice(0, 8)}`;
};

const generateIp = () =>
  `${Math.floor(Math.random() * 200 + 10)}.${Math.floor(Math.random() * 250 + 1)}.${Math.floor(Math.random() * 250 + 1)}.${Math.floor(Math.random() * 250 + 1)}`;

const scaleUp = async (provider, server, io) => {
  logger.info(`📈 Scaling up: Adding instance to ${provider.alias}`);

  const providerName = provider.name;
  const instanceTypes = INSTANCE_TYPES[providerName] || INSTANCE_TYPES.aws;
  const instanceType = instanceTypes[Math.floor(Math.random() * 3) + 1]; // medium tier

  const newServer = new Server({
    name: `${provider.alias}-auto-${Date.now().toString(36)}`,
    instanceId: generateInstanceId(providerName),
    cloudProvider: provider._id,
    instanceType,
    ipAddress: generateIp(),
    privateIp: `10.0.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`,
    status: 'pending',
    role: 'secondary',
    specs: {
      vcpus: 2,
      memoryGB: 4,
      storageGB: 80,
      networkGbps: 1
    },
    metrics: {
      cpuUsage: 5,
      memoryUsage: 15,
      diskUsage: 10
    },
    services: [
      { name: 'nginx', port: 80, status: 'running', version: '1.24.0' },
      { name: 'node', port: 3000, status: 'running', version: '18.17.0' }
    ]
  });

  await newServer.save();

  // Simulate startup time
  setTimeout(async () => {
    newServer.status = 'running';
    newServer.healthCheck.isHealthy = true;
    await newServer.save();
    if (io) io.emit('server:new', { server: newServer, providerId: provider._id });
    logger.info(`✅ New instance ${newServer.instanceId} is running`);
  }, 15000);

  await createAlert({
    title: `Auto Scale-Up: ${provider.alias}`,
    message: `Launched new instance ${newServer.instanceId} (${instanceType}) due to high load`,
    severity: 'info',
    type: 'scale_up',
    source: { cloudProvider: provider._id, server: newServer._id },
    metadata: { instanceId: newServer.instanceId, instanceType, trigger: 'cpu_threshold' }
  }, io);

  return newServer;
};

const scaleDown = async (provider, servers, io) => {
  // Find the least loaded server to terminate
  const target = servers
    .filter(s => s.role === 'secondary' && s.status === 'running')
    .sort((a, b) => a.metrics.cpuUsage - b.metrics.cpuUsage)[0];

  if (!target) return;

  logger.info(`📉 Scaling down: Terminating ${target.instanceId} from ${provider.alias}`);
  target.status = 'terminated';
  target.terminatedAt = new Date();
  await target.save();

  await createAlert({
    title: `Auto Scale-Down: ${provider.alias}`,
    message: `Terminated instance ${target.instanceId} due to low utilization`,
    severity: 'info',
    type: 'scale_down',
    source: { cloudProvider: provider._id, server: target._id }
  }, io);

  if (io) io.emit('server:terminated', { serverId: target._id, providerId: provider._id });
};

const checkAutoScaling = async (io) => {
  try {
    const providers = await CloudProvider.find({ status: 'active' });

    for (const provider of providers) {
      const servers = await Server.find({
        cloudProvider: provider._id,
        status: 'running'
      });

      if (!servers.length) continue;

      const avgCpu = servers.reduce((sum, s) => sum + (s.metrics.cpuUsage || 0), 0) / servers.length;

      const scalingConfig = {
        minInstances: 1,
        maxInstances: 8,
        scaleUpThreshold: 80,
        scaleDownThreshold: 20
      };

      if (avgCpu > scalingConfig.scaleUpThreshold && servers.length < scalingConfig.maxInstances) {
        logger.info(`Provider ${provider.alias}: avg CPU ${avgCpu.toFixed(1)}% > ${scalingConfig.scaleUpThreshold}% - scaling up`);
        await scaleUp(provider, servers[0], io);
      } else if (avgCpu < scalingConfig.scaleDownThreshold && servers.length > scalingConfig.minInstances) {
        logger.info(`Provider ${provider.alias}: avg CPU ${avgCpu.toFixed(1)}% < ${scalingConfig.scaleDownThreshold}% - scaling down`);
        await scaleDown(provider, servers, io);
      }
    }
  } catch (error) {
    logger.error('Auto-scaler error:', error.message);
  }
};

const startAutoScaler = (io) => {
  cron.schedule(AUTOSCALER_INTERVAL, () => checkAutoScaling(io));
  logger.info(`Auto-scaler scheduled: ${AUTOSCALER_INTERVAL}`);
};

module.exports = { startAutoScaler, scaleUp, scaleDown };
