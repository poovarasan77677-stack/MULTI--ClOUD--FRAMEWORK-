const logger = require('../utils/logger');

const socketHandler = (io) => {
  io.on('connection', (socket) => {
    logger.info(`Socket connected: ${socket.id}`);

    socket.on('subscribe:provider', (providerId) => {
      socket.join(`provider:${providerId}`);
    });

    socket.on('subscribe:alerts', () => {
      socket.join('alerts');
    });

    socket.on('ping', (data) => {
      socket.emit('pong', { ...data, serverTime: Date.now() });
    });

    socket.on('disconnect', (reason) => {
      logger.info(`Socket disconnected: ${socket.id} (${reason})`);
    });

    // Send welcome message with current status
    socket.emit('connected', {
      message: 'Connected to Multi-Cloud HA Framework',
      timestamp: new Date().toISOString(),
      socketId: socket.id
    });
  });

  io.on('error', (error) => {
    logger.error('Socket.IO error:', error);
  });
};

module.exports = socketHandler;
