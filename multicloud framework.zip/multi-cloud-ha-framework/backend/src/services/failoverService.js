const cron = require('node-cron');
const logger = require('../utils/logger');
const CloudProvider = require('../models/CloudProvider');
const FailoverEvent = require('../models/FailoverEvent');
const Alert = require('../models/Alert');
const { createAlert } = require('./alertService');

const FAILOVER_CHECK_INTERVAL = '*/60 * * * * *'; // every 60 seconds
const FAILURE_THRESHOLD = parseInt(process.env.FAILURE_THRESHOLD) || 3;

const FAILOVER_STEPS = [
  'Detecting failure',
  'Selecting failover target',
  'Initiating DNS switch',
  'Redirecting load balancer',
  'Warming up target provider',
  'Verifying target health',
  'Switching traffic (25%)',
  'Switching traffic (50%)',
  'Switching traffic (75%)',
  'Switching traffic (100%)',
  'Updating monitoring',
  'Failover complete'
];

const executeFailover = async (fromProvider, toProvider, reason, io, trigger = 'automatic') => {
  logger.warn(`🔄 Initiating failover: ${fromProvider.alias} → ${toProvider.alias}. Reason: ${reason}`);

  const failoverEvent = new FailoverEvent({
    trigger,
    reason,
    fromProvider: fromProvider._id,
    toProvider: toProvider._id,
    status: 'in_progress',
    startedAt: new Date(),
    steps: FAILOVER_STEPS.map(name => ({ name, status: 'pending' }))
  });

  await failoverEvent.save();

  if (io) {
    io.emit('failover:started', {
      eventId: failoverEvent._id,
      from: fromProvider.alias,
      to: toProvider.alias,
      reason
    });
  }

  // Execute steps with realistic timing
  for (let i = 0; i < failoverEvent.steps.length; i++) {
    const step = failoverEvent.steps[i];
    step.status = 'running';
    step.startedAt = new Date();

    if (io) {
      io.emit('failover:step', {
        eventId: failoverEvent._id,
        stepIndex: i,
        stepName: step.name,
        status: 'running'
      });
    }

    // Simulate step execution time (3-8 seconds each)
    const stepDuration = Math.random() * 5000 + 3000;
    await new Promise(r => setTimeout(r, stepDuration));

    // Occasionally fail a step for realism (and retry)
    const stepFailed = Math.random() < 0.05;
    step.status = stepFailed ? 'failed' : 'completed';
    step.completedAt = new Date();
    step.durationMs = step.completedAt - step.startedAt;
    step.message = stepFailed ? 'Retrying...' : `Completed in ${step.durationMs}ms`;

    if (stepFailed) {
      // Retry once
      await new Promise(r => setTimeout(r, 2000));
      step.status = 'completed';
      step.message = `Completed after retry in ${step.durationMs + 2000}ms`;
    }

    await failoverEvent.save();

    if (io) {
      io.emit('failover:step', {
        eventId: failoverEvent._id,
        stepIndex: i,
        stepName: step.name,
        status: step.status
      });
    }
  }

  // Update providers
  fromProvider.isPrimary = false;
  fromProvider.status = 'degraded';
  fromProvider.failoverCount = (fromProvider.failoverCount || 0) + 1;
  fromProvider.lastFailover = new Date();
  await fromProvider.save();

  toProvider.isPrimary = true;
  toProvider.status = 'active';
  await toProvider.save();

  // Complete failover event
  failoverEvent.status = 'completed';
  failoverEvent.completedAt = new Date();
  failoverEvent.durationMs = failoverEvent.completedAt - failoverEvent.startedAt;
  failoverEvent.metrics = {
    downtimeMs: failoverEvent.durationMs,
    rtoAchievedMs: failoverEvent.durationMs,
    rpoAchievedMs: Math.random() * 60000,
    requestsLost: Math.floor(Math.random() * 50),
    requestsRedirected: Math.floor(Math.random() * 10000 + 1000)
  };
  await failoverEvent.save();

  // Create success alert
  await createAlert({
    title: 'Failover Completed Successfully',
    message: `Traffic switched from ${fromProvider.alias} to ${toProvider.alias} in ${(failoverEvent.durationMs / 1000).toFixed(1)}s`,
    severity: 'info',
    type: 'failover_complete',
    source: { cloudProvider: toProvider._id },
    metadata: { failoverEventId: failoverEvent._id, durationMs: failoverEvent.durationMs }
  }, io);

  if (io) {
    io.emit('failover:completed', {
      eventId: failoverEvent._id,
      durationMs: failoverEvent.durationMs,
      fromProvider: fromProvider.alias,
      toProvider: toProvider.alias
    });
  }

  logger.info(`✅ Failover complete: ${fromProvider.alias} → ${toProvider.alias} (${failoverEvent.durationMs}ms)`);
  return failoverEvent;
};

const checkForFailover = async (io) => {
  try {
    const primaryProvider = await CloudProvider.getPrimaryProvider();
    if (!primaryProvider) return;

    const consecutiveFailures = primaryProvider.healthCheck?.consecutiveFailures || 0;
    if (consecutiveFailures < FAILURE_THRESHOLD) return;

    // Check if failover already in progress
    const ongoingFailover = await FailoverEvent.findOne({ status: 'in_progress' });
    if (ongoingFailover) return;

    logger.warn(`Primary provider ${primaryProvider.alias} has ${consecutiveFailures} consecutive failures. Triggering failover.`);

    const failoverTargets = await CloudProvider.getFailoverTargets();
    if (!failoverTargets.length) {
      logger.error('No failover targets available!');
      return;
    }

    const target = failoverTargets[0];
    await executeFailover(
      primaryProvider,
      target,
      `Automatic failover: ${consecutiveFailures} consecutive health check failures`,
      io,
      'automatic'
    );
  } catch (error) {
    logger.error('Failover check error:', error.message);
  }
};

const startFailoverWatcher = (io) => {
  cron.schedule(FAILOVER_CHECK_INTERVAL, () => checkForFailover(io));
  logger.info(`Failover watcher scheduled: ${FAILOVER_CHECK_INTERVAL}`);
};

const triggerManualFailover = async (fromProviderId, toProviderId, reason, io) => {
  const [from, to] = await Promise.all([
    CloudProvider.findById(fromProviderId),
    CloudProvider.findById(toProviderId)
  ]);

  if (!from || !to) throw new Error('Provider not found');

  return executeFailover(from, to, reason || 'Manual failover', io, 'manual');
};

module.exports = { startFailoverWatcher, triggerManualFailover, executeFailover };
