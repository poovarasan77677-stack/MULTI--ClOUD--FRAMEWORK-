const { v4: uuidv4 } = require('uuid');

/**
 * Attaches a unique request ID to every request and response.
 * Useful for distributed tracing and log correlation.
 */
const requestId = (req, res, next) => {
  const id = req.headers['x-request-id'] || uuidv4();
  req.requestId = id;
  res.setHeader('X-Request-ID', id);
  next();
};

module.exports = requestId;
