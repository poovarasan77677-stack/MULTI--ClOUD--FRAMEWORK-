const rateLimit = require('express-rate-limit');

const createLimiter = (windowMs, max, message) =>
  rateLimit({ windowMs, max, message: { error: message }, standardHeaders: true, legacyHeaders: false });

module.exports = {
  apiLimiter:    createLimiter(15 * 60 * 1000, 500,  'Too many API requests'),
  authLimiter:   createLimiter(15 * 60 * 1000, 15,   'Too many login attempts, try again in 15 minutes'),
  strictLimiter: createLimiter(60  * 1000,     20,   'Rate limit exceeded'),
  seedLimiter:   createLimiter(60  * 1000,     3,    'Seed endpoint rate limited'),
};
