const AuditLog = require('../models/AuditLog');
const logger   = require('../utils/logger');

// Map HTTP method+path → audit action
const ACTION_MAP = {
  'POST /api/auth/login':           'login',
  'POST /api/auth/logout':          'logout',
  'POST /api/clouds':               'provider_created',
  'PUT /api/clouds':                'provider_updated',
  'DELETE /api/clouds':             'provider_deleted',
  'POST /api/servers':              'server_created',
  'DELETE /api/servers':            'server_terminated',
  'POST /api/failover/trigger':     'failover_triggered',
  'POST /api/clouds/seed/demo':     'seed_executed',
};

const getAction = (method, path) => {
  const base = path.split('/').slice(0,4).join('/');
  const key = `${method} ${base}`;
  return ACTION_MAP[key] || null;
};

const auditMiddleware = (req, res, next) => {
  const start = Date.now();
  const origEnd = res.end.bind(res);

  res.end = function (...args) {
    const action = getAction(req.method, req.path);
    if (action && req.user) {
      AuditLog.log({
        action,
        userId:   req.user._id,
        username: req.user.username,
        userRole: req.user.role,
        ipAddress: req.ip || req.connection?.remoteAddress,
        userAgent: req.headers['user-agent'],
        resource:  req.path,
        resourceId: req.params?.id,
        result: res.statusCode < 400 ? 'success' : 'failure',
        duration: Date.now() - start,
        metadata: { statusCode: res.statusCode, method: req.method }
      }).catch(e => logger.warn('Audit log write failed:', e.message));
    }
    origEnd(...args);
  };

  next();
};

module.exports = auditMiddleware;
