const mongoose = require('mongoose');

const cloudProviderSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    enum: ['aws', 'azure', 'gcp', 'digitalocean', 'linode', 'oracle'],
    unique: false
  },
  alias: { type: String, required: true, trim: true },
  region: { type: String, required: true },
  status: {
    type: String,
    enum: ['active', 'degraded', 'offline', 'maintenance'],
    default: 'active'
  },
  priority: { type: Number, default: 1, min: 1, max: 10 },
  isPrimary: { type: Boolean, default: false },
  isFailoverTarget: { type: Boolean, default: false },
  credentials: {
    accessKey: { type: String, select: false },
    secretKey: { type: String, select: false },
    subscriptionId: { type: String, select: false },
    projectId: { type: String, select: false },
    keyFile: { type: String, select: false }
  },
  config: {
    vpcId: String,
    subnetIds: [String],
    securityGroupIds: [String],
    loadBalancerArn: String,
    autoScalingGroupName: String,
    availabilityZones: [String]
  },
  metrics: {
    cpuUsage: { type: Number, default: 0 },
    memoryUsage: { type: Number, default: 0 },
    networkIn: { type: Number, default: 0 },
    networkOut: { type: Number, default: 0 },
    requestsPerSecond: { type: Number, default: 0 },
    errorRate: { type: Number, default: 0 },
    latency: { type: Number, default: 0 },
    uptimePercentage: { type: Number, default: 100 }
  },
  healthCheck: {
    endpoint: String,
    interval: { type: Number, default: 30 },
    timeout: { type: Number, default: 10 },
    successThreshold: { type: Number, default: 2 },
    failureThreshold: { type: Number, default: 3 },
    lastChecked: Date,
    consecutiveFailures: { type: Number, default: 0 },
    consecutiveSuccesses: { type: Number, default: 0 }
  },
  cost: {
    hourly: { type: Number, default: 0 },
    daily: { type: Number, default: 0 },
    monthly: { type: Number, default: 0 },
    currency: { type: String, default: 'USD' }
  },
  tags: [{ key: String, value: String }],
  lastFailover: Date,
  failoverCount: { type: Number, default: 0 }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

cloudProviderSchema.virtual('servers', {
  ref: 'Server',
  localField: '_id',
  foreignField: 'cloudProvider'
});

cloudProviderSchema.index({ name: 1, region: 1 });
cloudProviderSchema.index({ status: 1, priority: 1 });

cloudProviderSchema.methods.isHealthy = function () {
  return this.status === 'active' && this.healthCheck.consecutiveFailures < 3;
};

cloudProviderSchema.statics.getPrimaryProvider = function () {
  return this.findOne({ isPrimary: true, status: 'active' }).sort({ priority: 1 });
};

cloudProviderSchema.statics.getFailoverTargets = function () {
  return this.find({ isFailoverTarget: true, status: 'active' }).sort({ priority: 1 });
};

module.exports = mongoose.model('CloudProvider', cloudProviderSchema);
