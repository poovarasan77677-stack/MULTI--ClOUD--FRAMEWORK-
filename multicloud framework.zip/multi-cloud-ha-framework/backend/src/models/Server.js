const mongoose = require('mongoose');

const serverSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  instanceId: { type: String, required: true },
  cloudProvider: { type: mongoose.Schema.Types.ObjectId, ref: 'CloudProvider', required: true },
  instanceType: { type: String, required: true },
  ipAddress: { type: String, required: true },
  privateIp: String,
  status: {
    type: String,
    enum: ['running', 'stopped', 'pending', 'terminated', 'error', 'maintenance'],
    default: 'running'
  },
  role: {
    type: String,
    enum: ['primary', 'secondary', 'replica', 'loadbalancer', 'monitor', 'cache'],
    default: 'primary'
  },
  os: { type: String, default: 'ubuntu-22.04' },
  specs: {
    vcpus: { type: Number, default: 2 },
    memoryGB: { type: Number, default: 4 },
    storageGB: { type: Number, default: 100 },
    networkGbps: { type: Number, default: 1 }
  },
  metrics: {
    cpuUsage: { type: Number, default: 0, min: 0, max: 100 },
    memoryUsage: { type: Number, default: 0, min: 0, max: 100 },
    diskUsage: { type: Number, default: 0, min: 0, max: 100 },
    networkIn: { type: Number, default: 0 },
    networkOut: { type: Number, default: 0 },
    iops: { type: Number, default: 0 },
    temperature: { type: Number, default: 0 },
    uptime: { type: Number, default: 0 }
  },
  healthCheck: {
    isHealthy: { type: Boolean, default: true },
    lastPingMs: { type: Number, default: 0 },
    lastChecked: Date,
    endpoint: String,
    consecutiveFailures: { type: Number, default: 0 }
  },
  autoScaling: {
    enabled: { type: Boolean, default: false },
    minInstances: { type: Number, default: 1 },
    maxInstances: { type: Number, default: 10 },
    targetCpuPercent: { type: Number, default: 70 },
    scaleUpCooldown: { type: Number, default: 300 },
    scaleDownCooldown: { type: Number, default: 600 }
  },
  services: [{
    name: String,
    port: Number,
    status: { type: String, enum: ['running', 'stopped', 'error'], default: 'running' },
    version: String
  }],
  tags: [{ key: String, value: String }],
  createdBy: String,
  terminatedAt: Date
}, {
  timestamps: true,
  toJSON: { virtuals: true }
});

serverSchema.index({ cloudProvider: 1, status: 1 });
serverSchema.index({ instanceId: 1 }, { unique: true });
serverSchema.index({ role: 1, status: 1 });

serverSchema.methods.updateMetrics = async function (metrics) {
  Object.assign(this.metrics, metrics);
  this.healthCheck.lastChecked = new Date();
  return this.save();
};

serverSchema.statics.getRunningByProvider = function (providerId) {
  return this.find({ cloudProvider: providerId, status: 'running' });
};

module.exports = mongoose.model('Server', serverSchema);
