const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema({
  action: {
    type: String,
    required: true,
    enum: [
      'login','logout','login_failed',
      'provider_created','provider_updated','provider_deleted',
      'server_created','server_terminated','server_updated',
      'failover_triggered','failover_completed','failover_failed',
      'alert_acknowledged','alert_resolved',
      'config_changed','user_created','user_updated',
      'seed_executed','api_key_generated','scale_up','scale_down'
    ]
  },
  userId:     { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  username:   String,
  userRole:   String,
  ipAddress:  String,
  userAgent:  String,
  resource:   String,
  resourceId: String,
  changes:    mongoose.Schema.Types.Mixed,
  result:     { type: String, enum: ['success','failure','partial'], default: 'success' },
  errorMessage: String,
  duration:   Number,   // ms
  metadata:   mongoose.Schema.Types.Mixed
}, { timestamps: true });

auditLogSchema.index({ action: 1, createdAt: -1 });
auditLogSchema.index({ userId: 1, createdAt: -1 });
auditLogSchema.index({ createdAt: -1 });

auditLogSchema.statics.log = async function (data) {
  try {
    return await this.create(data);
  } catch (err) {
    require('../utils/logger').error('AuditLog.log failed:', err.message);
  }
};

module.exports = mongoose.model('AuditLog', auditLogSchema);
