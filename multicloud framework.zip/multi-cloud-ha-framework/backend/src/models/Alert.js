const mongoose = require('mongoose');

const alertSchema = new mongoose.Schema({
  title: { type: String, required: true },
  message: { type: String, required: true },
  severity: {
    type: String,
    enum: ['info', 'warning', 'critical', 'emergency'],
    default: 'info'
  },
  type: {
    type: String,
    enum: [
      'server_down', 'high_cpu', 'high_memory', 'high_disk',
      'failover_triggered', 'failover_complete', 'scale_up', 'scale_down',
      'network_issue', 'security_breach', 'cost_threshold', 'latency_spike',
      'provider_outage', 'certificate_expiry', 'backup_failure'
    ],
    required: true
  },
  source: {
    cloudProvider: { type: mongoose.Schema.Types.ObjectId, ref: 'CloudProvider' },
    server: { type: mongoose.Schema.Types.ObjectId, ref: 'Server' },
    service: String
  },
  status: {
    type: String,
    enum: ['active', 'acknowledged', 'resolved', 'suppressed'],
    default: 'active'
  },
  metadata: mongoose.Schema.Types.Mixed,
  resolvedAt: Date,
  acknowledgedAt: Date,
  acknowledgedBy: String,
  notificationsSent: [{
    channel: String,
    sentAt: Date,
    success: Boolean
  }],
  autoResolved: { type: Boolean, default: false },
  runbookUrl: String,
  correlationId: String
}, {
  timestamps: true
});

alertSchema.index({ severity: 1, status: 1, createdAt: -1 });
alertSchema.index({ 'source.cloudProvider': 1, status: 1 });
alertSchema.index({ type: 1, createdAt: -1 });

alertSchema.statics.getActiveAlerts = function () {
  return this.find({ status: 'active' })
    .populate('source.cloudProvider', 'name alias')
    .populate('source.server', 'name instanceId')
    .sort({ severity: -1, createdAt: -1 });
};

alertSchema.statics.getCriticalCount = function () {
  return this.countDocuments({ status: 'active', severity: { $in: ['critical', 'emergency'] } });
};

module.exports = mongoose.model('Alert', alertSchema);
