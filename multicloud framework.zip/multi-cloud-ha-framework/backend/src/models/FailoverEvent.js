const mongoose = require('mongoose');

const failoverEventSchema = new mongoose.Schema({
  trigger: {
    type: String,
    enum: ['automatic', 'manual', 'scheduled', 'test'],
    default: 'automatic'
  },
  reason: { type: String, required: true },
  fromProvider: { type: mongoose.Schema.Types.ObjectId, ref: 'CloudProvider', required: true },
  toProvider: { type: mongoose.Schema.Types.ObjectId, ref: 'CloudProvider', required: true },
  status: {
    type: String,
    enum: ['pending', 'in_progress', 'completed', 'failed', 'rolled_back'],
    default: 'pending'
  },
  startedAt: { type: Date, default: Date.now },
  completedAt: Date,
  durationMs: Number,
  steps: [{
    name: String,
    status: { type: String, enum: ['pending', 'running', 'completed', 'failed'] },
    startedAt: Date,
    completedAt: Date,
    message: String,
    durationMs: Number
  }],
  trafficSwitchPercent: { type: Number, default: 100 },
  affectedServers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Server' }],
  metrics: {
    downtimeMs: Number,
    rtoAchievedMs: Number,
    rpoAchievedMs: Number,
    requestsLost: Number,
    requestsRedirected: Number
  },
  initiatedBy: String,
  rollbackAvailable: { type: Boolean, default: true },
  notes: String
}, {
  timestamps: true
});

failoverEventSchema.index({ status: 1, createdAt: -1 });
failoverEventSchema.index({ fromProvider: 1, toProvider: 1 });

failoverEventSchema.methods.calculateDuration = function () {
  if (this.completedAt && this.startedAt) {
    this.durationMs = this.completedAt - this.startedAt;
  }
};

module.exports = mongoose.model('FailoverEvent', failoverEventSchema);
