require('dotenv').config();
const express = require('express');
const http = require('http');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const compression = require('compression');
const { Server } = require('socket.io');
const rateLimit = require('express-rate-limit');

const logger = require('./utils/logger');
const connectDB = require('./config/database');
const { connectRedis } = require('./config/redis');
const metricsRouter = require('./routes/metrics');
const cloudsRouter = require('./routes/clouds');
const serversRouter = require('./routes/servers');
const healthRouter = require('./routes/health');
const alertsRouter = require('./routes/alerts');
const authRouter = require('./routes/auth');
const failoverRouter = require('./routes/failover');
const auditRouter = require('./routes/audit');
const usersRouter = require('./routes/users');
const notificationsRouter = require('./routes/notifications');
const loadbalancerRouter = require('./routes/loadbalancer');
const { setupMetrics } = require('./services/metricsService');
const { startHealthMonitor } = require('./services/healthMonitor');
const { startAutoScaler } = require('./services/autoScaler');
const { startFailoverWatcher } = require('./services/failoverService');
const socketHandler = require('./services/socketService');
const errorHandler = require('./middleware/errorHandler');
const requestId = require('./middleware/requestId');

const app = express();
const server = http.createServer(app);

// Socket.IO setup
const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    methods: ['GET', 'POST']
  }
});

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 500,
  message: { error: 'Too many requests, please try again later.' }
});

// Middleware
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:3000', credentials: true }));
app.use(compression());
app.use(morgan('combined', { stream: { write: msg => logger.info(msg.trim()) } }));
app.use(express.json({ limit: '10mb' }));
app.use(requestId);
app.use(express.urlencoded({ extended: true }));
app.use('/api/', limiter);

// Attach io to requests
app.use((req, res, next) => { req.io = io; next(); });

// Routes
app.use('/api/auth', authRouter);
app.use('/api/clouds', cloudsRouter);
app.use('/api/servers', serversRouter);
app.use('/api/health', healthRouter);
app.use('/api/metrics', metricsRouter);
app.use('/api/alerts', alertsRouter);
app.use('/api/failover', failoverRouter);
app.use('/api/audit', auditRouter);
app.use('/api/users', usersRouter);
app.use('/api/notifications', notificationsRouter);
app.use('/api/loadbalancer', loadbalancerRouter);

// Prometheus metrics endpoint
app.get('/metrics', async (req, res) => {
  const client = require('prom-client');
  res.set('Content-Type', client.register.contentType);
  res.end(await client.register.metrics());
});

// Root
app.get('/', (req, res) => {
  res.json({
    name: 'Multi-Cloud HA Framework API',
    version: '1.0.0',
    status: 'operational',
    timestamp: new Date().toISOString(),
    endpoints: {
      auth: '/api/auth',
      clouds: '/api/clouds',
      servers: '/api/servers',
      health: '/api/health',
      metrics: '/api/metrics',
      alerts: '/api/alerts',
      failover: '/api/failover',
      loadbalancer: '/api/loadbalancer'
    }
  });
});

// Error handler
app.use(errorHandler);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found' });
});

// Initialize services
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();
    logger.info('✅ Database connected');

    await connectRedis().catch(e => logger.warn('Redis optional - skipping:', e.message));
    setupMetrics();
    logger.info('✅ Prometheus metrics initialized');

    socketHandler(io);

    // Start background services
    startHealthMonitor(io);
    logger.info('✅ Health monitor started');

    startAutoScaler(io);
    logger.info('✅ Auto-scaler started');

    startFailoverWatcher(io);
    logger.info('✅ Failover watcher started');

    server.listen(PORT, () => {
      logger.info(`🚀 Multi-Cloud HA Framework API running on port ${PORT}`);
      logger.info(`📊 Metrics available at http://localhost:${PORT}/metrics`);
      logger.info(`🌍 Environment: ${process.env.NODE_ENV || 'development'}`);
    });
  } catch (error) {
    logger.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

// Graceful shutdown
const gracefulShutdown = (signal) => {
  logger.info(`${signal} received. Starting graceful shutdown...`);
  server.close(() => {
    logger.info('HTTP server closed.');
    process.exit(0);
  });
  setTimeout(() => {
    logger.error('Forcing shutdown after timeout');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', reason);
});
process.on('uncaughtException', (error) => {
  logger.error('Uncaught Exception:', error);
  process.exit(1);
});

startServer();

module.exports = { app, server };
