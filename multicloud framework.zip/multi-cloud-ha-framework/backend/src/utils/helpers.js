/**
 * Utility helpers for Multi-Cloud HA Framework backend
 */

/** Send a standardised success response */
const sendSuccess = (res, data, statusCode = 200, meta = {}) => {
  return res.status(statusCode).json({
    success: true,
    data,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

/** Send a paginated list response */
const sendPaginated = (res, items, total, page, limit) => {
  return res.json({
    success: true,
    data: items,
    pagination: {
      total,
      page: Number(page),
      limit: Number(limit),
      pages: Math.ceil(total / Number(limit)),
      hasNext: Number(page) * Number(limit) < total,
      hasPrev: Number(page) > 1
    },
    timestamp: new Date().toISOString()
  });
};

/** Build a MongoDB filter from query params */
const buildFilter = (query, allowedFields) => {
  const filter = {};
  allowedFields.forEach(field => {
    if (query[field] !== undefined && query[field] !== '') {
      filter[field] = query[field];
    }
  });
  return filter;
};

/** Parse pagination query params with safe defaults */
const parsePagination = (query, defaultLimit = 50) => {
  const page  = Math.max(1, parseInt(query.page)  || 1);
  const limit = Math.min(200, parseInt(query.limit) || defaultLimit);
  const skip  = (page - 1) * limit;
  return { page, limit, skip };
};

/** Generate a random hex string of given byte length */
const randomHex = (bytes = 16) => {
  const { randomBytes } = require('crypto');
  return randomBytes(bytes).toString('hex');
};

/** Format bytes to human-readable string */
const formatBytes = (bytes) => {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`;
};

/** Format milliseconds to human-readable duration */
const formatDuration = (ms) => {
  if (ms < 1000) return `${ms}ms`;
  if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`;
  if (ms < 3600000) return `${Math.floor(ms / 60000)}m ${Math.floor((ms % 60000) / 1000)}s`;
  return `${Math.floor(ms / 3600000)}h ${Math.floor((ms % 3600000) / 60000)}m`;
};

/** Deep-merge two objects */
const deepMerge = (target, source) => {
  const output = { ...target };
  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach(key => {
      if (isObject(source[key])) {
        if (!(key in target)) Object.assign(output, { [key]: source[key] });
        else output[key] = deepMerge(target[key], source[key]);
      } else {
        Object.assign(output, { [key]: source[key] });
      }
    });
  }
  return output;
};

const isObject = (item) => item && typeof item === 'object' && !Array.isArray(item);

/** Sleep for n milliseconds */
const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

/** Retry an async function up to maxAttempts times */
const retry = async (fn, maxAttempts = 3, delayMs = 1000) => {
  let lastErr;
  for (let i = 0; i < maxAttempts; i++) {
    try { return await fn(); }
    catch (err) {
      lastErr = err;
      if (i < maxAttempts - 1) await sleep(delayMs * (i + 1));
    }
  }
  throw lastErr;
};

/** Clamp a number between min and max */
const clamp = (value, min, max) => Math.min(Math.max(value, min), max);

module.exports = {
  sendSuccess, sendPaginated, buildFilter, parsePagination,
  randomHex, formatBytes, formatDuration, deepMerge, sleep, retry, clamp
};
