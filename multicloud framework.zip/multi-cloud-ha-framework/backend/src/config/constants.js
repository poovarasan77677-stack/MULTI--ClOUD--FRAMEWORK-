'use strict';

module.exports = {
  // Health check
  HEALTH_CHECK_INTERVAL_SECS: 30,
  FAILURE_THRESHOLD: parseInt(process.env.FAILURE_THRESHOLD) || 3,
  PING_TIMEOUT_MS: parseInt(process.env.PING_TIMEOUT) || 5000,

  // Auto-scaling
  SCALE_UP_CPU_THRESHOLD: 80,
  SCALE_DOWN_CPU_THRESHOLD: 20,
  AUTOSCALER_INTERVAL_SECS: 45,
  MIN_INSTANCES: 1,
  MAX_INSTANCES: 20,

  // Failover
  FAILOVER_CHECK_INTERVAL_SECS: 60,
  FAILOVER_STEPS: [
    'Detecting failure',
    'Selecting failover target',
    'Initiating DNS switch',
    'Redirecting load balancer',
    'Warming up target provider',
    'Verifying target health',
    'Switching traffic (25%)',
    'Switching traffic (50%)',
    'Switching traffic (75%)',
    'Switching traffic (100%)',
    'Updating monitoring',
    'Failover complete'
  ],

  // Alerts
  ALERT_DEDUP_WINDOW_MS: 5 * 60 * 1000,
  ALERT_SEVERITIES: ['info', 'warning', 'critical', 'emergency'],
  ALERT_TYPES: [
    'server_down', 'high_cpu', 'high_memory', 'high_disk',
    'failover_triggered', 'failover_complete', 'scale_up', 'scale_down',
    'network_issue', 'security_breach', 'cost_threshold', 'latency_spike',
    'provider_outage', 'certificate_expiry', 'backup_failure'
  ],

  // Cache TTLs (seconds)
  CACHE_TTL: {
    dashboard: 30,
    providers: 15,
    servers: 15,
    alerts: 10,
    timeseries: 60,
    costs: 300,
  },

  // Pagination
  DEFAULT_PAGE_LIMIT: 50,
  MAX_PAGE_LIMIT: 200,

  // Provider priority order
  PROVIDER_PRIORITY: ['aws', 'azure', 'gcp', 'digitalocean', 'linode', 'oracle'],

  // Cost estimation defaults (USD/hr)
  DEFAULT_COST_PER_HOUR: {
    aws: 0.12,
    azure: 0.10,
    gcp: 0.09,
    digitalocean: 0.04,
  },
};
