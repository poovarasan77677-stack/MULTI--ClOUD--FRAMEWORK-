const { createClient } = require('redis');
const logger = require('../utils/logger');

let client = null;

const connectRedis = async () => {
  if (client) return client;

  const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';

  client = createClient({
    url: redisUrl,
    socket: {
      reconnectStrategy: (retries) => {
        if (retries > 10) { logger.error('Redis reconnect limit reached'); return new Error('Too many retries'); }
        return Math.min(retries * 200, 3000);
      }
    }
  });

  client.on('error', (err) => logger.error('Redis error:', err.message));
  client.on('connect', () => logger.info('Redis connected'));
  client.on('reconnecting', () => logger.warn('Redis reconnecting...'));

  try {
    await client.connect();
    return client;
  } catch (err) {
    logger.warn(`Redis unavailable (${err.message}), running without cache`);
    return null;
  }
};

const getClient = () => client;

const disconnect = async () => {
  if (client) { await client.quit(); client = null; }
};

module.exports = { connectRedis, getClient, disconnect };
