module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/tests/**/*.test.js'],
  collectCoverageFrom: ['src/**/*.js','!src/app.js'],
  coverageDirectory: 'coverage',
  coverageReporters: ['text','lcov','html'],
  testTimeout: 15000,
  verbose: true,
  forceExit: true,
  detectOpenHandles: true
};
