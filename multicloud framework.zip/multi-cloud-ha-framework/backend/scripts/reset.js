#!/usr/bin/env node
/**
 * Database Reset Script
 * WARNING: This deletes ALL data. Use only in development.
 * Usage: NODE_ENV=development node scripts/reset.js --confirm
 */
require('dotenv').config();
const mongoose = require('mongoose');

if (process.env.NODE_ENV === 'production') {
  console.error('❌  CANNOT run reset in production!'); process.exit(1);
}
if (!process.argv.includes('--confirm')) {
  console.log('⚠️   Add --confirm to proceed with full database reset.'); process.exit(0);
}

const MODELS = ['CloudProvider', 'Server', 'Alert', 'FailoverEvent', 'User', 'AuditLog'];

(async () => {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/multicloud_ha');
  console.log('Connected to database');

  for (const name of MODELS) {
    try {
      const Model = require(`../src/models/${name}`);
      const count = await Model.countDocuments();
      await Model.deleteMany({});
      console.log(`✅  Cleared ${name} (${count} documents)`);
    } catch (e) {
      console.warn(`⚠️   Could not clear ${name}: ${e.message}`);
    }
  }

  await mongoose.disconnect();
  console.log('\n🗑️   Database reset complete. Run seed.js to reload demo data.');
  process.exit(0);
})().catch(err => { console.error('Reset failed:', err); process.exit(1); });
