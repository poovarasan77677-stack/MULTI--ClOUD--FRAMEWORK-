#!/usr/bin/env node
/**
 * Database Migration Runner
 * Usage: node scripts/migrate.js
 * Migrations are idempotent — safe to re-run
 */
require('dotenv').config();
const mongoose = require('mongoose');
const logger   = console;

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/multicloud_ha';

const migrations = [
  {
    version: '1.0.0',
    name: 'Add default healthCheck to CloudProviders',
    async run(db) {
      const result = await db.collection('cloudproviders').updateMany(
        { 'healthCheck.interval': { $exists: false } },
        { $set: { 'healthCheck.interval': 30, 'healthCheck.timeout': 10, 'healthCheck.consecutiveFailures': 0 } }
      );
      return `Updated ${result.modifiedCount} providers`;
    }
  },
  {
    version: '1.0.1',
    name: 'Ensure servers have services array',
    async run(db) {
      const result = await db.collection('servers').updateMany(
        { services: { $exists: false } },
        { $set: { services: [] } }
      );
      return `Updated ${result.modifiedCount} servers`;
    }
  },
  {
    version: '1.0.2',
    name: 'Add failoverCount field to CloudProviders',
    async run(db) {
      const result = await db.collection('cloudproviders').updateMany(
        { failoverCount: { $exists: false } },
        { $set: { failoverCount: 0 } }
      );
      return `Updated ${result.modifiedCount} providers`;
    }
  },
  {
    version: '1.1.0',
    name: 'Add isActive field to Users',
    async run(db) {
      const result = await db.collection('users').updateMany(
        { isActive: { $exists: false } },
        { $set: { isActive: true } }
      );
      return `Updated ${result.modifiedCount} users`;
    }
  },
  {
    version: '1.1.1',
    name: 'Create performance indexes',
    async run(db) {
      await db.collection('cloudproviders').createIndex({ status: 1, priority: 1 });
      await db.collection('servers').createIndex({ cloudProvider: 1, status: 1, role: 1 });
      await db.collection('alerts').createIndex({ status: 1, severity: 1, createdAt: -1 });
      await db.collection('failoverevents').createIndex({ status: 1, createdAt: -1 });
      await db.collection('auditlogs').createIndex({ userId: 1, createdAt: -1 });
      return 'Indexes created';
    }
  }
];

(async () => {
  await mongoose.connect(MONGO_URI);
  const db = mongoose.connection.db;
  logger.log(`\n🔄  Running ${migrations.length} migrations on ${MONGO_URI}\n`);

  // Track applied migrations
  const migCollection = db.collection('_migrations');

  for (const migration of migrations) {
    const already = await migCollection.findOne({ version: migration.version });
    if (already) {
      logger.log(`  ⏭️   ${migration.version} — ${migration.name} (already applied)`);
      continue;
    }
    try {
      const result = await migration.run(db);
      await migCollection.insertOne({ version: migration.version, name: migration.name, appliedAt: new Date() });
      logger.log(`  ✅  ${migration.version} — ${migration.name}: ${result}`);
    } catch (err) {
      logger.error(`  ❌  ${migration.version} — ${migration.name}: ${err.message}`);
      process.exit(1);
    }
  }

  logger.log('\n✅  All migrations complete.\n');
  await mongoose.disconnect();
  process.exit(0);
})().catch(err => { console.error(err); process.exit(1); });
