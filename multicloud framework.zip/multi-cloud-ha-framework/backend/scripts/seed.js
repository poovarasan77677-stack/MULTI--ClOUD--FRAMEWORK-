#!/usr/bin/env node
/**
 * Database Seed Script
 * Usage: node scripts/seed.js [--reset]
 */
require('dotenv').config();
const mongoose = require('mongoose');
const CloudProvider = require('../src/models/CloudProvider');
const Server = require('../src/models/Server');
const User = require('../src/models/User');
const Alert = require('../src/models/Alert');
const FailoverEvent = require('../src/models/FailoverEvent');

const MONGO_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/multicloud_ha';
const RESET = process.argv.includes('--reset');

const PROVIDERS = [
  {
    name: 'aws', alias: 'AWS US-East', region: 'us-east-1', status: 'active',
    priority: 1, isPrimary: true, isFailoverTarget: false,
    metrics: { cpuUsage:42, memoryUsage:58, requestsPerSecond:1240, latency:18, errorRate:0.2, uptimePercentage:99.98 },
    healthCheck: { endpoint:'mock://aws-health', interval:30, consecutiveFailures:0, consecutiveSuccesses:10 },
    cost: { hourly:2.40, daily:57.60, monthly:1728 },
    config: { availabilityZones:['us-east-1a','us-east-1b','us-east-1c'] },
    tags: [{key:'env',value:'production'},{key:'team',value:'platform'}]
  },
  {
    name: 'azure', alias: 'Azure East US', region: 'eastus', status: 'active',
    priority: 2, isPrimary: false, isFailoverTarget: true,
    metrics: { cpuUsage:28, memoryUsage:41, requestsPerSecond:0, latency:22, errorRate:0, uptimePercentage:100 },
    healthCheck: { endpoint:'mock://azure-health', interval:30, consecutiveFailures:0 },
    cost: { hourly:2.10, daily:50.40, monthly:1512 }
  },
  {
    name: 'gcp', alias: 'GCP US-Central', region: 'us-central1', status: 'active',
    priority: 3, isPrimary: false, isFailoverTarget: true,
    metrics: { cpuUsage:15, memoryUsage:32, requestsPerSecond:0, latency:25, errorRate:0, uptimePercentage:100 },
    healthCheck: { endpoint:'mock://gcp-health', interval:30, consecutiveFailures:0 },
    cost: { hourly:1.95, daily:46.80, monthly:1404 }
  },
  {
    name: 'digitalocean', alias: 'DO New York', region: 'nyc3', status: 'active',
    priority: 4, isPrimary: false, isFailoverTarget: true,
    metrics: { cpuUsage:10, memoryUsage:22, requestsPerSecond:0, latency:30, errorRate:0, uptimePercentage:99.95 },
    healthCheck: { endpoint:'mock://do-health', interval:30, consecutiveFailures:0 },
    cost: { hourly:0.89, daily:21.36, monthly:640.8 }
  }
];

const ROLES = ['primary','secondary','replica','loadbalancer'];
const IP_GEN = () => `${10+Math.floor(Math.random()*200)}.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}`;
const ID_GEN = (prefix) => `${prefix}-${Math.random().toString(36).slice(2,10)}`;

async function seed() {
  await mongoose.connect(MONGO_URI);
  console.log('✅ Connected to MongoDB:', MONGO_URI);

  if (RESET) {
    await Promise.all([
      CloudProvider.deleteMany({}), Server.deleteMany({}),
      Alert.deleteMany({}), FailoverEvent.deleteMany({})
    ]);
    console.log('🗑️  All existing data cleared');
  }

  const existingProviders = await CloudProvider.countDocuments();
  if (existingProviders > 0 && !RESET) {
    console.log(`ℹ️  ${existingProviders} providers already exist. Use --reset to overwrite.`);
  } else {
    const savedProviders = await CloudProvider.insertMany(PROVIDERS);
    console.log(`✅ Created ${savedProviders.length} cloud providers`);

    const prefixes = { aws:'i', azure:'vm', gcp:'gce', digitalocean:'drop' };
    let totalServers = 0;
    for (const provider of savedProviders) {
      const count = provider.isPrimary ? 4 : 2;
      const servers = Array.from({ length: count }, (_, i) => ({
        name: `${provider.alias.toLowerCase().replace(/ /g,'-')}-srv-${i+1}`,
        instanceId: ID_GEN(prefixes[provider.name] || 'srv'),
        cloudProvider: provider._id,
        instanceType: `${provider.name}-type-${i+1}`,
        ipAddress: IP_GEN(),
        privateIp: `10.${Math.floor(Math.random()*5)}.${Math.floor(Math.random()*250)}.${Math.floor(Math.random()*250)}`,
        status: 'running',
        role: ROLES[i % ROLES.length],
        specs: { vcpus:2+i, memoryGB:4+i*2, storageGB:80+i*20, networkGbps:1 },
        metrics: {
          cpuUsage: 15+Math.random()*50, memoryUsage: 25+Math.random()*40,
          diskUsage: 20+Math.random()*30, networkIn: Math.random()*1000,
          networkOut: Math.random()*800, uptime: Math.floor(Math.random()*86400*30)
        },
        healthCheck: { isHealthy:true, lastPingMs:5+Math.random()*45, lastChecked:new Date(), consecutiveFailures:0 },
        services: [
          { name:'nginx',  port:80,   status:'running', version:'1.24.0' },
          { name:'app',    port:3000, status:'running', version:'2.1.0'  },
          { name:'exporter',port:9100,status:'running', version:'1.6.1'  }
        ]
      }));
      await Server.insertMany(servers);
      totalServers += servers.length;
    }
    console.log(`✅ Created ${totalServers} server instances`);
  }

  // Seed users
  const existingUsers = await User.countDocuments();
  if (existingUsers === 0 || RESET) {
    await User.deleteMany({});
    await User.insertMany([
      { username:'admin',    email:'admin@multicloud-ha.io',    password:'Admin@1234',    role:'admin',    firstName:'System',  lastName:'Administrator' },
      { username:'operator', email:'operator@multicloud-ha.io', password:'Operator@1234', role:'operator', firstName:'Cloud',   lastName:'Operator'      },
      { username:'viewer',   email:'viewer@multicloud-ha.io',   password:'Viewer@1234',   role:'viewer',   firstName:'Dashboard',lastName:'Viewer'       }
    ]);
    console.log('✅ Created 3 demo users');
    console.log('   admin@multicloud-ha.io / Admin@1234');
    console.log('   operator@multicloud-ha.io / Operator@1234');
  }

  // Seed sample alerts
  const existingAlerts = await Alert.countDocuments();
  if (existingAlerts === 0 || RESET) {
    await Alert.deleteMany({});
    await Alert.insertMany([
      { title:'High CPU on aws-us-east-srv-1',   message:'CPU at 87% for 3 min',    severity:'warning',  type:'high_cpu',      status:'active'       },
      { title:'Memory Threshold Exceeded',        message:'Memory at 91% on azure',  severity:'critical', type:'high_memory',   status:'active'       },
      { title:'Auto Scale-Up: AWS US-East',       message:'Launched 2 new instances',severity:'info',     type:'scale_up',      status:'resolved'     },
      { title:'Backup Completed Successfully',    message:'Daily backup took 4 min', severity:'info',     type:'backup_failure',status:'resolved'     }
    ]);
    console.log('✅ Created 4 sample alerts');
  }

  console.log('\n🎉 Database seeded successfully!\n');
  await mongoose.disconnect();
  process.exit(0);
}

seed().catch(err => { console.error('❌ Seed failed:', err); process.exit(1); });
