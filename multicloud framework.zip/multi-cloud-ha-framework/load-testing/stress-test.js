/**
 * k6 Stress Test — Find breaking point
 * Run: k6 run load-testing/stress-test.js
 */
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

const failRate = new Rate('fail_rate');

export const options = {
  stages: [
    { duration: '2m',  target: 100  },
    { duration: '5m',  target: 100  },
    { duration: '2m',  target: 200  },
    { duration: '5m',  target: 200  },
    { duration: '2m',  target: 300  },
    { duration: '5m',  target: 300  },
    { duration: '2m',  target: 0    }
  ],
  thresholds: {
    http_req_failed: ['rate<0.1'],  // < 10% error rate (relaxed for stress)
    http_req_duration: ['p(95)<3000']
  }
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';

export default function () {
  const r = http.get(`${BASE_URL}/api/metrics/dashboard`);
  const ok = check(r, { 'status 200': res => res.status === 200 });
  failRate.add(!ok);
  sleep(0.5);
}
