/**
 * k6 Load Test — Ramp up to 100 concurrent users
 * Run: k6 run load-testing/load-test.js
 * Run with output: k6 run --out json=results.json load-testing/load-test.js
 */
import http from 'k6/http';
import { check, group, sleep } from 'k6';
import { Counter, Rate, Trend, Gauge } from 'k6/metrics';

const httpErrors     = new Counter('http_errors');
const successRate    = new Rate('success_rate');
const dashboardTime  = new Trend('dashboard_load_time');
const alertsTime     = new Trend('alerts_load_time');
const failoverTime   = new Trend('failover_load_time');
const activeUsers    = new Gauge('active_users');

export const options = {
  stages: [
    { duration: '1m',  target: 10  },   // Ramp up
    { duration: '3m',  target: 50  },   // Stay at 50
    { duration: '2m',  target: 100 },   // Peak load
    { duration: '2m',  target: 100 },   // Sustained peak
    { duration: '1m',  target: 50  },   // Scale down
    { duration: '30s', target: 0   }    // Ramp down
  ],
  thresholds: {
    http_req_duration:        ['p(50)<200', 'p(95)<800', 'p(99)<2000'],
    http_req_failed:          ['rate<0.02'],
    success_rate:             ['rate>0.98'],
    dashboard_load_time:      ['p(95)<1000'],
    alerts_load_time:         ['p(95)<500'],
  }
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';
const HEADERS  = { 'Content-Type': 'application/json' };

export default function () {
  activeUsers.add(1);

  group('Dashboard & Metrics', () => {
    const r = http.get(`${BASE_URL}/api/metrics/dashboard`, { headers: HEADERS });
    dashboardTime.add(r.timings.duration);
    const ok = check(r, { 'dashboard 200': res => res.status === 200 });
    successRate.add(ok);
    if (!ok) httpErrors.add(1);
  });

  sleep(Math.random() * 2 + 0.5);

  group('Cloud Providers', () => {
    const r = http.get(`${BASE_URL}/api/clouds`, { headers: HEADERS });
    check(r, { 'clouds 200': res => res.status === 200 });
    successRate.add(r.status === 200);
  });

  sleep(Math.random() * 1 + 0.5);

  group('Servers', () => {
    const r = http.get(`${BASE_URL}/api/servers?limit=20`, { headers: HEADERS });
    check(r, { 'servers 200': res => res.status === 200 });
    successRate.add(r.status === 200);
  });

  sleep(Math.random() * 1);

  group('Alerts', () => {
    const r = http.get(`${BASE_URL}/api/alerts?status=active&limit=10`, { headers: HEADERS });
    alertsTime.add(r.timings.duration);
    check(r, { 'alerts 200': res => res.status === 200 });
    successRate.add(r.status === 200);
  });

  sleep(Math.random() * 1 + 0.5);

  group('Failover Stats', () => {
    const r = http.get(`${BASE_URL}/api/failover/stats/summary`, { headers: HEADERS });
    failoverTime.add(r.timings.duration);
    check(r, { 'failover stats 200': res => res.status === 200 });
    successRate.add(r.status === 200);
  });

  sleep(Math.random() * 2 + 1);
  activeUsers.add(-1);
}

export function handleSummary(data) {
  const p95 = data.metrics.http_req_duration?.values?.['p(95)']?.toFixed(0) || 'N/A';
  const rps  = data.metrics.http_reqs?.values?.rate?.toFixed(1) || 'N/A';
  const fail = ((data.metrics.http_req_failed?.values?.rate||0)*100).toFixed(2);

  console.log('\n============================================');
  console.log('   Multi-Cloud HA — Load Test Summary');
  console.log('============================================');
  console.log(`  Total Requests:   ${data.metrics.http_reqs?.values?.count}`);
  console.log(`  Req/sec:          ${rps}`);
  console.log(`  P95 Latency:      ${p95}ms`);
  console.log(`  Error Rate:       ${fail}%`);
  console.log(`  Max VUs:          ${data.metrics.vus_max?.values?.max}`);
  console.log('============================================\n');
  return { 'load-test-results.json': JSON.stringify(data, null, 2) };
}
