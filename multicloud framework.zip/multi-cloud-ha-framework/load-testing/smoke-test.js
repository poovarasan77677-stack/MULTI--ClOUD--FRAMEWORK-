/**
 * k6 Smoke Test — Quick sanity check
 * Run: k6 run load-testing/smoke-test.js
 */
import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate, Trend } from 'k6/metrics';

const errorRate   = new Rate('error_rate');
const apiLatency  = new Trend('api_latency');

export const options = {
  vus: 5,
  duration: '30s',
  thresholds: {
    http_req_duration: ['p(95)<500'],
    http_req_failed:   ['rate<0.05'],
    error_rate:        ['rate<0.05']
  }
};

const BASE_URL = __ENV.BASE_URL || 'http://localhost:5000';

export default function () {
  const responses = {
    health:    http.get(`${BASE_URL}/api/health/live`),
    clouds:    http.get(`${BASE_URL}/api/clouds`),
    servers:   http.get(`${BASE_URL}/api/servers`),
    alerts:    http.get(`${BASE_URL}/api/alerts?status=active&limit=10`),
    metrics:   http.get(`${BASE_URL}/api/metrics/dashboard`),
    timeseries:http.get(`${BASE_URL}/api/metrics/timeseries`)
  };

  for (const [name, res] of Object.entries(responses)) {
    const ok = check(res, {
      [`${name} status 200`]: r => r.status === 200,
      [`${name} has body`]:   r => r.body.length > 0
    });
    errorRate.add(!ok);
    apiLatency.add(res.timings.duration, { endpoint: name });
  }

  sleep(1);
}
