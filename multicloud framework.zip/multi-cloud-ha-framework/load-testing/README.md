# Load Testing — Multi-Cloud HA Framework

## Prerequisites
```bash
# Install k6
brew install k6                        # macOS
sudo apt-get install k6                # Ubuntu
# Or: https://k6.io/docs/get-started/installation/
```

## Tests

| Test | Purpose | Duration |
|------|---------|---------|
| `smoke-test.js` | Verify endpoints work | 30s |
| `load-test.js` | Realistic load (100 VUs peak) | ~10m |
| `stress-test.js` | Find breaking point (300 VUs) | ~23m |

## Running Tests

```bash
# Start the application first
cd /path/to/project && bash scripts/start-dev.sh

# In another terminal
cd load-testing

# Smoke test
k6 run smoke-test.js

# Load test against local
k6 run load-test.js

# Load test against production
BASE_URL=https://ha-framework.yourdomain.com k6 run load-test.js

# Stress test with JSON output
k6 run --out json=stress-results.json stress-test.js

# Output to InfluxDB (for Grafana)
k6 run --out influxdb=http://localhost:8086/k6 load-test.js
```

## Acceptance Criteria

| Metric | Target |
|--------|--------|
| P95 API latency | < 800ms |
| Error rate | < 2% |
| Throughput | > 500 req/s |
| Dashboard load (P95) | < 1000ms |
