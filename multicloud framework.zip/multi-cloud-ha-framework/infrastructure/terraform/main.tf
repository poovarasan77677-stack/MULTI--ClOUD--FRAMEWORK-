# ==============================================================
# Multi-Cloud HA Framework — Top-level Terraform Orchestrator
# Manages all three cloud providers together
# ==============================================================
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws     = { source = "hashicorp/aws",     version = "~> 5.0" }
    azurerm = { source = "hashicorp/azurerm", version = "~> 3.0" }
    google  = { source = "hashicorp/google",  version = "~> 5.0" }
  }

  # Uncomment and configure for remote state
  # backend "s3" {
  #   bucket  = "your-tf-state-bucket"
  #   key     = "multi-cloud-ha/global/terraform.tfstate"
  #   region  = "us-east-1"
  #   encrypt = true
  # }
}

# ── Variables ──────────────────────────────────────────────────
variable "project_name" { default = "multicloud-ha" }
variable "environment"  { default = "production" }
variable "deploy_aws"   { default = true }
variable "deploy_azure" { default = true }
variable "deploy_gcp"   { default = true }

# ── AWS ────────────────────────────────────────────────────────
module "aws_infrastructure" {
  count  = var.deploy_aws ? 1 : 0
  source = "./aws"
  project_name = var.project_name
  environment  = var.environment
}

# ── Azure ──────────────────────────────────────────────────────
module "azure_infrastructure" {
  count  = var.deploy_azure ? 1 : 0
  source = "./azure"
  project_name = var.project_name
  environment  = var.environment
  ssh_public_key = "~/.ssh/id_rsa.pub"
}

# ── GCP ────────────────────────────────────────────────────────
module "gcp_infrastructure" {
  count  = var.deploy_gcp ? 1 : 0
  source = "./gcp"
  project_id   = var.gcp_project_id
  project_name = var.project_name
  environment  = var.environment
}

variable "gcp_project_id" { default = "" }

# ── Outputs ────────────────────────────────────────────────────
output "aws_lb_dns"   { value = var.deploy_aws   ? module.aws_infrastructure[0].alb_dns_name : "not deployed" }
output "azure_lb_ip"  { value = var.deploy_azure ? module.azure_infrastructure[0].lb_public_ip : "not deployed" }
output "gcp_lb_ip"    { value = var.deploy_gcp   ? module.gcp_infrastructure[0].lb_ip_address : "not deployed" }
