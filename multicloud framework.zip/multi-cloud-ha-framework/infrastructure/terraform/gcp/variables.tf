variable "project_id"       { description = "GCP project ID" }
variable "project_name"     { default = "multicloud-ha" }
variable "environment"      { default = "production" }
variable "region"           { default = "us-central1" }
variable "subnet_cidr"      { default = "10.2.0.0/20" }
variable "machine_type"     { default = "n2-standard-2" }
variable "mig_min_replicas" { default = 2 }
variable "mig_max_replicas" { default = 20 }
variable "mongodb_uri"      { sensitive = true; default = "" }
variable "redis_url"        { sensitive = true; default = "" }
variable "jwt_secret"       { sensitive = true; default = "" }
variable "app_image"        { default = "gcr.io/your-project/ha-backend:latest" }
