#!/bin/bash
apt-get update -y
apt-get install -y docker.io curl jq
systemctl enable docker && systemctl start docker

cat > /etc/ha-framework.env << ENVEOF
NODE_ENV=production
MONGODB_URI=${mongodb_uri}
REDIS_URL=${redis_url}
JWT_SECRET=${jwt_secret}
PORT=5000
ENVEOF

docker pull ${app_image}
docker run -d \
  --name ha-backend \
  --restart=unless-stopped \
  --env-file /etc/ha-framework.env \
  -p 5000:5000 \
  ${app_image}
