output "lb_ip_address"        { value = google_compute_global_address.main.address }
output "redis_host"           { value = google_redis_instance.main.host }
output "instance_group"       { value = google_compute_region_instance_group_manager.app.instance_group }
output "service_account_email"{ value = google_service_account.app.email }
