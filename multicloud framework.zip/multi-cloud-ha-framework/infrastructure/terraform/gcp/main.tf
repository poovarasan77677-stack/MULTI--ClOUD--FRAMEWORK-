# ============================================================
# Multi-Cloud HA Framework — Google Cloud Platform Infrastructure
# ============================================================
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    google      = { source = "hashicorp/google",      version = "~> 5.0" }
    google-beta = { source = "hashicorp/google-beta", version = "~> 5.0" }
  }
  backend "gcs" {
    bucket = "your-tfstate-bucket"
    prefix = "multi-cloud-ha/gcp"
  }
}

provider "google" {
  project = var.project_id
  region  = var.region
}

provider "google-beta" {
  project = var.project_id
  region  = var.region
}

locals {
  common_labels = { project = var.project_name; environment = var.environment; managed_by = "terraform" }
}

# ── Enable APIs ─────────────────────────────────────────────────
resource "google_project_service" "apis" {
  for_each = toset([
    "compute.googleapis.com", "container.googleapis.com",
    "cloudresourcemanager.googleapis.com", "iam.googleapis.com",
    "monitoring.googleapis.com", "logging.googleapis.com",
    "sqladmin.googleapis.com", "redis.googleapis.com",
    "secretmanager.googleapis.com", "dns.googleapis.com"
  ])
  project            = var.project_id
  service            = each.value
  disable_on_destroy = false
}

# ── VPC Network ─────────────────────────────────────────────────
resource "google_compute_network" "main" {
  name                    = "${var.project_name}-vpc"
  auto_create_subnetworks = false
  project                 = var.project_id
  depends_on              = [google_project_service.apis]
}

resource "google_compute_subnetwork" "app" {
  name          = "${var.project_name}-app-subnet"
  ip_cidr_range = var.subnet_cidr
  region        = var.region
  network       = google_compute_network.main.id
  private_ip_google_access = true

  log_config {
    aggregation_interval = "INTERVAL_10_MIN"
    flow_sampling        = 0.5
    metadata             = "INCLUDE_ALL_METADATA"
  }
}

resource "google_compute_router" "main" {
  name    = "${var.project_name}-router"
  region  = var.region
  network = google_compute_network.main.id
}

resource "google_compute_router_nat" "main" {
  name                               = "${var.project_name}-nat"
  router                             = google_compute_router.main.name
  region                             = var.region
  nat_ip_allocate_option             = "AUTO_ONLY"
  source_subnetwork_ip_ranges_to_nat = "ALL_SUBNETWORKS_ALL_IP_RANGES"
  log_config { enable = true; filter = "ERRORS_ONLY" }
}

# ── Firewall Rules ──────────────────────────────────────────────
resource "google_compute_firewall" "allow_http" {
  name    = "${var.project_name}-allow-http"
  network = google_compute_network.main.name
  allow { protocol = "tcp"; ports = ["80","443","5000"] }
  source_ranges = ["0.0.0.0/0"]
  target_tags   = ["${var.project_name}-app"]
}

resource "google_compute_firewall" "allow_internal" {
  name    = "${var.project_name}-allow-internal"
  network = google_compute_network.main.name
  allow { protocol = "tcp" }
  allow { protocol = "udp" }
  allow { protocol = "icmp" }
  source_ranges = [var.subnet_cidr]
}

resource "google_compute_firewall" "allow_health_check" {
  name    = "${var.project_name}-allow-hc"
  network = google_compute_network.main.name
  allow { protocol = "tcp"; ports = ["5000"] }
  source_ranges = ["130.211.0.0/22","35.191.0.0/16"] # GCP health check IPs
  target_tags   = ["${var.project_name}-app"]
}

# ── Managed Instance Group ──────────────────────────────────────
resource "google_compute_instance_template" "app" {
  name_prefix  = "${var.project_name}-template-"
  machine_type = var.machine_type
  region       = var.region
  tags         = ["${var.project_name}-app", "http-server", "https-server"]
  labels       = local.common_labels

  disk {
    source_image = "projects/ubuntu-os-cloud/global/images/family/ubuntu-2204-lts"
    auto_delete  = true
    boot         = true
    disk_size_gb = 50
    disk_type    = "pd-ssd"
  }

  network_interface {
    subnetwork = google_compute_subnetwork.app.id
  }

  metadata = {
    startup-script = templatefile("${path.module}/startup.sh", {
      mongodb_uri = var.mongodb_uri
      redis_url   = var.redis_url
      jwt_secret  = var.jwt_secret
      app_image   = var.app_image
    })
    enable-oslogin = "true"
  }

  service_account {
    email  = google_service_account.app.email
    scopes = ["cloud-platform"]
  }

  shielded_instance_config {
    enable_secure_boot          = true
    enable_vtpm                 = true
    enable_integrity_monitoring = true
  }

  lifecycle { create_before_destroy = true }
}

resource "google_service_account" "app" {
  account_id   = "${var.project_name}-sa"
  display_name = "HA Framework App Service Account"
  project      = var.project_id
}

resource "google_compute_region_instance_group_manager" "app" {
  name               = "${var.project_name}-mig"
  region             = var.region
  base_instance_name = "${var.project_name}-vm"

  version { instance_template = google_compute_instance_template.app.id; name = "primary" }

  named_port { name = "http"; port = 5000 }

  auto_healing_policies {
    health_check      = google_compute_health_check.app.id
    initial_delay_sec = 120
  }

  update_policy {
    type                  = "PROACTIVE"
    minimal_action        = "REPLACE"
    max_surge_fixed       = 3
    max_unavailable_fixed = 0
  }
}

resource "google_compute_region_autoscaler" "app" {
  name   = "${var.project_name}-autoscaler"
  region = var.region
  target = google_compute_region_instance_group_manager.app.id

  autoscaling_policy {
    max_replicas    = var.mig_max_replicas
    min_replicas    = var.mig_min_replicas
    cooldown_period = 90

    cpu_utilization { target = 0.7 }

    load_balancing_utilization { target = 0.8 }

    scale_in_control {
      max_scaled_in_replicas { fixed = 2 }
      time_window_sec = 300
    }
  }
}

# ── HTTP(S) Load Balancer ───────────────────────────────────────
resource "google_compute_global_address" "main" {
  name    = "${var.project_name}-lb-ip"
  project = var.project_id
}

resource "google_compute_health_check" "app" {
  name = "${var.project_name}-hc"
  http_health_check {
    port         = 5000
    request_path = "/api/health/live"
  }
  check_interval_sec  = 15
  timeout_sec         = 10
  healthy_threshold   = 2
  unhealthy_threshold = 3
}

resource "google_compute_backend_service" "app" {
  name        = "${var.project_name}-backend-svc"
  protocol    = "HTTP"
  port_name   = "http"
  timeout_sec = 60
  health_checks = [google_compute_health_check.app.id]

  backend {
    group           = google_compute_region_instance_group_manager.app.instance_group
    balancing_mode  = "UTILIZATION"
    capacity_scaler = 1.0
  }

  log_config { enable = true; sample_rate = 0.1 }
  enable_cdn = false
}

resource "google_compute_url_map" "main" {
  name            = "${var.project_name}-url-map"
  default_service = google_compute_backend_service.app.id
}

resource "google_compute_target_http_proxy" "main" {
  name    = "${var.project_name}-http-proxy"
  url_map = google_compute_url_map.main.id
}

resource "google_compute_global_forwarding_rule" "main" {
  name       = "${var.project_name}-forwarding-rule"
  target     = google_compute_target_http_proxy.main.id
  port_range = "80"
  ip_address = google_compute_global_address.main.address
}

# ── Cloud Memorystore (Redis) ───────────────────────────────────
resource "google_redis_instance" "main" {
  name           = "${var.project_name}-redis"
  tier           = "STANDARD_HA"
  memory_size_gb = 1
  region         = var.region
  location_id    = "${var.region}-a"
  alternative_location_id = "${var.region}-b"
  authorized_network      = google_compute_network.main.id
  redis_version           = "REDIS_7_0"
  redis_configs           = { maxmemory-policy = "allkeys-lru" }
  labels = local.common_labels
}

# ── Secret Manager ──────────────────────────────────────────────
resource "google_secret_manager_secret" "jwt_secret" {
  secret_id = "${var.project_name}-jwt-secret"
  replication { automatic {} }
  labels = local.common_labels
}

resource "google_secret_manager_secret_version" "jwt_secret" {
  secret      = google_secret_manager_secret.jwt_secret.id
  secret_data = var.jwt_secret
}
