#!/bin/bash
set -e
exec > /var/log/ha-bootstrap.log 2>&1

# Update system
apt-get update -y
apt-get install -y docker.io docker-compose curl jq awscli

# Start Docker
systemctl enable docker
systemctl start docker

# Pull app config from SSM (optional — falls back to env vars)
JWT_SECRET=$(aws ssm get-parameter --name "/ha-framework/jwt-secret" --with-decryption --query Parameter.Value --output text 2>/dev/null || echo "${jwt_secret}")
MONGODB_URI=$(aws ssm get-parameter --name "/ha-framework/mongodb-uri" --with-decryption --query Parameter.Value --output text 2>/dev/null || echo "${mongo_uri}")
REDIS_URL=$(aws ssm get-parameter --name "/ha-framework/redis-url" --with-decryption --query Parameter.Value --output text 2>/dev/null || echo "${redis_url}")

# Create app directory
mkdir -p /opt/ha-framework

# Write environment
cat > /opt/ha-framework/.env << ENVEOF
NODE_ENV=production
PORT=5000
MONGODB_URI=$MONGODB_URI
REDIS_URL=$REDIS_URL
JWT_SECRET=$JWT_SECRET
LOG_LEVEL=info
HEALTH_CHECK_INTERVAL=*/30 * * * * *
FAILURE_THRESHOLD=3
ENVEOF

# Run backend container
docker pull ${app_image:-ha-backend:latest}
docker run -d \
  --name ha-backend \
  --restart=unless-stopped \
  --env-file /opt/ha-framework/.env \
  -p 5000:5000 \
  --log-driver=awslogs \
  --log-opt awslogs-region=${region:-us-east-1} \
  --log-opt awslogs-group=/ha-framework/backend \
  ${app_image:-ha-backend:latest}

# Install node exporter for Prometheus scraping
docker run -d \
  --name node-exporter \
  --restart=unless-stopped \
  --net="host" \
  --pid="host" \
  -v "/:/host:ro,rslave" \
  prom/node-exporter:latest \
  --path.rootfs=/host \
  --collector.filesystem.ignored-mount-points="^/(sys|proc|dev|host|etc)($$|/)"

echo "Bootstrap complete at $(date)"
