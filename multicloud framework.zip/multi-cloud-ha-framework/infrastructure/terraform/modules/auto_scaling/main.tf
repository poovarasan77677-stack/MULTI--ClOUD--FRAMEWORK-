# ==============================================================
# Reusable Auto Scaling Module
# ==============================================================
variable "name"           { description = "Resource name prefix" }
variable "provider_type"  { description = "aws | azure | gcp" }
variable "min_instances"  { default = 2 }
variable "max_instances"  { default = 20 }
variable "desired_instances" { default = 3 }
variable "scale_up_cpu_threshold"   { default = 75 }
variable "scale_down_cpu_threshold" { default = 25 }
variable "scale_up_cooldown"   { default = 300 }
variable "scale_down_cooldown" { default = 600 }
variable "common_tags"    { type = map(string); default = {} }

output "scaling_config" {
  value = {
    min        = var.min_instances
    max        = var.max_instances
    desired    = var.desired_instances
    up_cpu     = var.scale_up_cpu_threshold
    down_cpu   = var.scale_down_cpu_threshold
  }
}
