# ==============================================================
# Reusable Load Balancer Module
# Supports: AWS ALB, Azure LB, GCP HTTP(S) LB
# ==============================================================
variable "name"         { description = "Resource name prefix" }
variable "provider_type"{ description = "aws | azure | gcp" }
variable "environment"  { default = "production" }
variable "health_check_path"  { default = "/api/health/live" }
variable "health_check_port"  { default = 5000 }
variable "enable_https"       { default = true }
variable "idle_timeout"       { default = 60 }
variable "common_tags"        { type = map(string); default = {} }

locals {
  full_name = "${var.name}-lb-${var.environment}"
}

output "module_info" {
  value = {
    name          = local.full_name
    provider_type = var.provider_type
    health_check  = "${var.health_check_path}:${var.health_check_port}"
    https_enabled = var.enable_https
  }
}
