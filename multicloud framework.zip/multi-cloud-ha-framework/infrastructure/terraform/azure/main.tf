# ============================================================
# Multi-Cloud HA Framework — Azure Infrastructure
# ============================================================
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    azurerm = { source = "hashicorp/azurerm", version = "~> 3.0" }
    random  = { source = "hashicorp/random",  version = "~> 3.0" }
  }
  backend "azurerm" {
    resource_group_name  = "tfstate-rg"
    storage_account_name = "tfstatemulticloud"
    container_name       = "tfstate"
    key                  = "multi-cloud-ha/azure/terraform.tfstate"
  }
}

provider "azurerm" {
  features {
    resource_group { prevent_deletion_if_contains_resources = false }
    key_vault      { purge_soft_delete_on_destroy = true }
  }
}

resource "random_string" "suffix" { length = 6; special = false; upper = false }

locals {
  name_prefix  = "${var.project_name}-${random_string.suffix.result}"
  common_tags  = { Project = var.project_name; Environment = var.environment; ManagedBy = "terraform" }
}

# ── Resource Group ─────────────────────────────────────────────
resource "azurerm_resource_group" "main" {
  name     = "${local.name_prefix}-rg"
  location = var.location
  tags     = local.common_tags
}

# ── Virtual Network ─────────────────────────────────────────────
resource "azurerm_virtual_network" "main" {
  name                = "${local.name_prefix}-vnet"
  address_space       = [var.vnet_cidr]
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  tags                = local.common_tags
}

resource "azurerm_subnet" "public" {
  name                 = "${local.name_prefix}-public-subnet"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.public_subnet_cidr]
}

resource "azurerm_subnet" "private" {
  name                 = "${local.name_prefix}-private-subnet"
  resource_group_name  = azurerm_resource_group.main.name
  virtual_network_name = azurerm_virtual_network.main.name
  address_prefixes     = [var.private_subnet_cidr]
}

# ── Network Security Group ──────────────────────────────────────
resource "azurerm_network_security_group" "app" {
  name                = "${local.name_prefix}-nsg"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name

  security_rule {
    name = "AllowHTTP"; priority = 100; direction = "Inbound"; access = "Allow"
    protocol = "Tcp"; source_port_range = "*"; destination_port_range = "80"
    source_address_prefix = "*"; destination_address_prefix = "*"
  }
  security_rule {
    name = "AllowHTTPS"; priority = 110; direction = "Inbound"; access = "Allow"
    protocol = "Tcp"; source_port_range = "*"; destination_port_range = "443"
    source_address_prefix = "*"; destination_address_prefix = "*"
  }
  security_rule {
    name = "AllowApp"; priority = 120; direction = "Inbound"; access = "Allow"
    protocol = "Tcp"; source_port_range = "*"; destination_port_range = "5000"
    source_address_prefix = var.vnet_cidr; destination_address_prefix = "*"
  }
  tags = local.common_tags
}

# ── Public IP for Load Balancer ─────────────────────────────────
resource "azurerm_public_ip" "lb" {
  name                = "${local.name_prefix}-lb-pip"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  allocation_method   = "Static"
  sku                 = "Standard"
  zones               = ["1","2","3"]
  tags                = local.common_tags
}

# ── Azure Load Balancer ─────────────────────────────────────────
resource "azurerm_lb" "main" {
  name                = "${local.name_prefix}-lb"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  sku                 = "Standard"

  frontend_ip_configuration {
    name                 = "PublicIPAddress"
    public_ip_address_id = azurerm_public_ip.lb.id
    zones                = ["1","2","3"]
  }
  tags = local.common_tags
}

resource "azurerm_lb_backend_address_pool" "app" {
  loadbalancer_id = azurerm_lb.main.id
  name            = "${local.name_prefix}-backend-pool"
}

resource "azurerm_lb_probe" "http" {
  loadbalancer_id = azurerm_lb.main.id
  name            = "http-probe"
  port            = 5000
  protocol        = "Http"
  request_path    = "/api/health/live"
  interval_in_seconds = 15
  number_of_probes    = 2
}

resource "azurerm_lb_rule" "http" {
  loadbalancer_id                = azurerm_lb.main.id
  name                           = "http-rule"
  protocol                       = "Tcp"
  frontend_port                  = 80
  backend_port                   = 5000
  frontend_ip_configuration_name = "PublicIPAddress"
  backend_address_pool_ids       = [azurerm_lb_backend_address_pool.app.id]
  probe_id                       = azurerm_lb_probe.http.id
  enable_tcp_reset               = true
  idle_timeout_in_minutes        = 30
}

# ── Virtual Machine Scale Set ───────────────────────────────────
resource "azurerm_linux_virtual_machine_scale_set" "app" {
  name                = "${local.name_prefix}-vmss"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  sku                 = var.vm_size
  instances           = var.vmss_initial_count
  admin_username      = var.admin_username
  zones               = ["1","2","3"]
  overprovision       = false
  upgrade_mode        = "Rolling"

  rolling_upgrade_policy {
    max_batch_instance_percent              = 20
    max_unhealthy_instance_percent          = 20
    max_unhealthy_upgraded_instance_percent = 20
    pause_time_between_batches              = "PT0S"
  }

  health_probe_id = azurerm_lb_probe.http.id

  admin_ssh_key {
    username   = var.admin_username
    public_key = var.ssh_public_key
  }

  os_disk {
    storage_account_type = "Premium_LRS"
    caching              = "ReadWrite"
    disk_size_gb         = 64
  }

  source_image_reference {
    publisher = "Canonical"
    offer     = "0001-com-ubuntu-server-jammy"
    sku       = "22_04-lts-gen2"
    version   = "latest"
  }

  network_interface {
    name    = "vmss-nic"
    primary = true
    network_security_group_id = azurerm_network_security_group.app.id

    ip_configuration {
      name                                   = "primary"
      primary                                = true
      subnet_id                              = azurerm_subnet.private.id
      load_balancer_backend_address_pool_ids = [azurerm_lb_backend_address_pool.app.id]
    }
  }

  custom_data = base64encode(templatefile("${path.module}/cloud-init.yml", {
    mongodb_uri = var.mongodb_uri
    redis_url   = var.redis_url
    jwt_secret  = var.jwt_secret
    app_image   = var.app_image
  }))

  automatic_os_upgrade_policy {
    enable_automatic_os_upgrade = false
    disable_automatic_rollback  = false
  }

  tags = local.common_tags
}

# ── Auto Scale Settings ─────────────────────────────────────────
resource "azurerm_monitor_autoscale_setting" "app" {
  name                = "${local.name_prefix}-autoscale"
  resource_group_name = azurerm_resource_group.main.name
  location            = azurerm_resource_group.main.location
  target_resource_id  = azurerm_linux_virtual_machine_scale_set.app.id

  profile {
    name = "default"
    capacity { default = var.vmss_initial_count; minimum = var.vmss_min_count; maximum = var.vmss_max_count }

    rule {
      metric_trigger {
        metric_name        = "Percentage CPU"
        metric_resource_id = azurerm_linux_virtual_machine_scale_set.app.id
        time_grain         = "PT1M"; statistic = "Average"
        time_window        = "PT5M"; time_aggregation = "Average"
        operator           = "GreaterThan"; threshold = 75
      }
      scale_action { direction = "Increase"; type = "ChangeCount"; value = "2"; cooldown = "PT5M" }
    }

    rule {
      metric_trigger {
        metric_name        = "Percentage CPU"
        metric_resource_id = azurerm_linux_virtual_machine_scale_set.app.id
        time_grain         = "PT1M"; statistic = "Average"
        time_window        = "PT10M"; time_aggregation = "Average"
        operator           = "LessThan"; threshold = 25
      }
      scale_action { direction = "Decrease"; type = "ChangeCount"; value = "1"; cooldown = "PT10M" }
    }
  }

  notification {
    email {
      send_to_subscription_administrator    = true
      send_to_subscription_co_administrator = true
    }
  }
  tags = local.common_tags
}

# ── Azure Cosmos DB (MongoDB API) ───────────────────────────────
resource "azurerm_cosmosdb_account" "main" {
  name                = "${local.name_prefix}-cosmos"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  offer_type          = "Standard"
  kind                = "MongoDB"

  consistency_policy { consistency_level = "BoundedStaleness"; max_interval_in_seconds = 300; max_staleness_prefix = 100000 }

  geo_location { location = azurerm_resource_group.main.location; failover_priority = 0; zone_redundant = true }
  geo_location { location = var.dr_location; failover_priority = 1; zone_redundant = false }

  backup { type = "Periodic"; interval_in_minutes = 240; retention_in_hours = 168; storage_redundancy = "Geo" }

  capabilities { name = "EnableMongo" }
  capabilities { name = "mongoEnableDocLevelTTL" }

  tags = local.common_tags
}

# ── Azure Cache for Redis ───────────────────────────────────────
resource "azurerm_redis_cache" "main" {
  name                = "${local.name_prefix}-redis"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  capacity            = 1
  family              = "C"
  sku_name            = "Standard"
  enable_non_ssl_port = false
  minimum_tls_version = "1.2"
  redis_configuration { maxmemory_policy = "allkeys-lru" }
  tags = local.common_tags
}

# ── Key Vault for Secrets ───────────────────────────────────────
resource "azurerm_key_vault" "main" {
  name                = "${local.name_prefix}-kv"
  location            = azurerm_resource_group.main.location
  resource_group_name = azurerm_resource_group.main.name
  tenant_id           = data.azurerm_client_config.current.tenant_id
  sku_name            = "standard"
  soft_delete_retention_days = 7
  purge_protection_enabled   = var.environment == "production"
  tags = local.common_tags
}

data "azurerm_client_config" "current" {}
