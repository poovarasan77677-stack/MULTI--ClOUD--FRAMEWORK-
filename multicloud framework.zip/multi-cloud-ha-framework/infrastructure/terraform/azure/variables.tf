variable "project_name"        { default = "multicloud-ha" }
variable "environment"         { default = "production" }
variable "location"            { default = "eastus" }
variable "dr_location"         { default = "westus2" }
variable "vnet_cidr"           { default = "10.1.0.0/16" }
variable "public_subnet_cidr"  { default = "10.1.1.0/24" }
variable "private_subnet_cidr" { default = "10.1.2.0/24" }
variable "vm_size"             { default = "Standard_D2s_v3" }
variable "admin_username"      { default = "azureuser" }
variable "ssh_public_key"      { description = "SSH public key for VMSS" }
variable "vmss_initial_count"  { default = 2 }
variable "vmss_min_count"      { default = 2 }
variable "vmss_max_count"      { default = 20 }
variable "mongodb_uri"         { sensitive = true; default = "" }
variable "redis_url"           { sensitive = true; default = "" }
variable "jwt_secret"          { sensitive = true; default = "" }
variable "app_image"           { default = "ghcr.io/your-org/ha-backend:latest" }
