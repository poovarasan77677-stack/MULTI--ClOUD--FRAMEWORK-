output "lb_public_ip"        { value = azurerm_public_ip.lb.ip_address }
output "vmss_id"             { value = azurerm_linux_virtual_machine_scale_set.app.id }
output "cosmosdb_endpoint"   { value = azurerm_cosmosdb_account.main.connection_strings[0]; sensitive = true }
output "redis_hostname"      { value = azurerm_redis_cache.main.hostname }
output "key_vault_uri"       { value = azurerm_key_vault.main.vault_uri }
output "resource_group_name" { value = azurerm_resource_group.main.name }
