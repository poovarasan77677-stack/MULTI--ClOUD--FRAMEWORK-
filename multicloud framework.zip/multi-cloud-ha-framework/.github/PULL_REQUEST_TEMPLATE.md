## Summary
Brief description of changes.

## Type of change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update
- [ ] Refactor / performance
- [ ] Infrastructure / DevOps

## Checklist
- [ ] Tests pass (`make test`)
- [ ] Smoke test passes (`make smoke-test`)
- [ ] Docs updated (if applicable)
- [ ] No secrets committed
- [ ] Migration added (if schema changed)

## Related issues
Closes #
