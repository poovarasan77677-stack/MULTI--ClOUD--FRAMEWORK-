---
name: Feature request
about: Suggest a new feature
labels: enhancement
---

**Is this related to a problem?**
A clear description of the problem.

**Describe the solution you'd like**
What you want to happen.

**Alternatives considered**
Any alternative solutions or features you've considered.

**Additional context**
Any other context, screenshots, or examples.
