# Operations Runbook

## Daily Operations

### Morning Checks (5 min)
```bash
bash scripts/health-check.sh              # Overall health
bash scripts/smoke-test.sh                # API endpoints
kubectl get pods -n multi-cloud-ha        # Pod status (K8s)
```

### Check alert queue
```bash
curl -s http://localhost:5000/api/alerts/summary | jq .
```

---

## Common Tasks

### Seed / reset demo data
```bash
make seed          # Seed without clearing
make reset-db      # Clear + re-seed (dev only)
# or via API:
curl -X POST http://localhost:5000/api/clouds/seed/demo
curl -X POST http://localhost:5000/api/auth/seed
```

### Trigger manual failover
```bash
# Get provider IDs
curl -s http://localhost:5000/api/clouds | jq '.[].{id:_id,name:alias}'

# Trigger
curl -X POST http://localhost:5000/api/failover/trigger \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{"fromProviderId":"<id>","toProviderId":"<id>","reason":"Scheduled maintenance"}'
```

### Rotate JWT secret
```bash
make rotate-secrets
make docker-restart   # or kubectl rollout restart deployment/ha-backend
```

### Scale backend manually
```bash
# Docker
docker-compose up -d --scale backend=3

# Kubernetes
kubectl scale deployment ha-backend --replicas=5 -n multi-cloud-ha
```

### View logs
```bash
# Docker
docker-compose logs -f --tail=100 backend

# Kubernetes
kubectl logs -f deployment/ha-backend -n multi-cloud-ha --tail=100

# All containers
kubectl logs -f -l app.kubernetes.io/name=ha-framework -n multi-cloud-ha
```

---

## Troubleshooting

### Backend not starting
```bash
# Check env vars
docker-compose exec backend env | grep -E 'MONGO|REDIS|JWT|PORT'

# Check DB connection
curl http://localhost:5000/api/health/deep | jq .checks

# View full logs
docker-compose logs backend | tail -50
```

### Failover not triggering automatically
1. Check `FAILURE_THRESHOLD` env var (default: 3)
2. Verify primary provider `consecutiveFailures` in DB:
   ```bash
   curl http://localhost:5000/api/clouds | jq '.[0].healthCheck'
   ```
3. Check failover watcher logs for errors
4. Verify at least one provider has `isFailoverTarget: true`

### High memory usage
```bash
# Backend heap stats
curl http://localhost:5000/api/health/deep | jq .memoryMB

# Prometheus
curl -s http://localhost:5000/metrics | grep ha_framework_process_heap

# Restart if needed
make docker-restart
```

### Redis connection issues
The app runs without Redis (cache disabled). Check:
```bash
docker-compose ps redis
docker-compose logs redis | tail -20
```

### MongoDB replica set issues
```bash
docker-compose exec mongo mongosh --eval "rs.status()"
# If degraded:
docker-compose exec mongo mongosh --eval "rs.initiate()"
```

---

## Backup & Restore

```bash
# Manual backup
bash scripts/backup.sh

# Restore
tar -xzf /tmp/ha-backups/ha-framework_*.tar.gz -C /tmp/
mongorestore --uri="$MONGODB_URI" --gzip /tmp/ha-framework_*/

# Verify
curl http://localhost:5000/api/clouds | jq length
```

---

## Performance Tuning

| Parameter | Default | Tuning |
|-----------|---------|--------|
| `FAILURE_THRESHOLD` | 3 | Increase to 5 to reduce false positives |
| `HEALTH_CHECK_INTERVAL` | 30s | Decrease to 15s for faster detection |
| MongoDB cache | 0.5 × RAM | Increase via `wiredTigerCacheSizeGB` |
| Node.js cluster | max cores | Set `PM2_INSTANCES` in ecosystem config |
| Nginx keepalive | 65s | Increase for high-traffic setups |
