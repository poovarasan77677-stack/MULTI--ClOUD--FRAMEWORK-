# Deployment Guide

## Prerequisites

| Tool | Version | Purpose |
|------|---------|---------|
| Node.js | ≥ 18 | Backend runtime |
| Docker | ≥ 24 | Container runtime |
| Docker Compose | ≥ 2 | Local orchestration |
| kubectl | ≥ 1.28 | Kubernetes CLI |
| Helm | ≥ 3.12 | K8s packaging |
| Terraform | ≥ 1.5 | Infrastructure as code |
| Ansible | ≥ 2.14 | Configuration management |

---

## Option 1 — Local Development (Fastest)

```bash
git clone https://github.com/your-org/multi-cloud-ha-framework
cd multi-cloud-ha-framework
bash scripts/setup.sh       # Install deps, generate .env
bash scripts/start-dev.sh   # Start MongoDB, Redis, backend, frontend
```

Seed demo data:
```bash
curl -X POST http://localhost:5000/api/clouds/seed/demo
curl -X POST http://localhost:5000/api/auth/seed
```

Open: http://localhost:3000 — Login: admin@multicloud-ha.io / Admin@1234

---

## Option 2 — Docker Compose (Recommended for demos)

```bash
# Full stack (all 7 services)
docker-compose up -d

# With monitoring (Prometheus + Grafana + Alertmanager)
docker-compose up -d  # monitoring included in default compose

# With hot reload (dev mode)
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up -d

# Production mode (resource limits + restart policies)
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d
```

URLs after startup:
| Service | URL |
|---------|-----|
| Dashboard | http://localhost:3000 |
| API | http://localhost:5000 |
| Prometheus | http://localhost:9090 |
| Grafana | http://localhost:3001 |
| Alertmanager | http://localhost:9093 |

---

## Option 3 — Kubernetes

### Quick path (Helm):
```bash
# 1. Create namespace
kubectl create namespace multi-cloud-ha

# 2. Install with Helm
helm upgrade --install ha-release infrastructure/helm/ha-framework \
  --namespace multi-cloud-ha \
  --set secrets.jwtSecret="$(openssl rand -base64 48)" \
  --set secrets.mongodbUri="mongodb://..." \
  --set secrets.redisUrl="redis://..."

# 3. Check status
kubectl get pods -n multi-cloud-ha
```

### Full path (manifests):
```bash
make k8s-namespace   # Apply configmap + secrets
make k8s-deploy      # Apply all manifests
make k8s-status      # Check status
```

---

## Option 4 — Cloud Infrastructure (Terraform)

### AWS:
```bash
cd infrastructure/terraform/aws
terraform init
terraform plan -var="jwt_secret=$(openssl rand -base64 48)"
terraform apply
```

### Azure:
```bash
cd infrastructure/terraform/azure
terraform init
terraform apply
```

### GCP:
```bash
cd infrastructure/terraform/gcp
terraform init
terraform apply -var="project_id=your-gcp-project"
```

### All clouds (orchestrator):
```bash
cd infrastructure/terraform
terraform init
terraform apply -var="gcp_project_id=your-project"
```

---

## Option 5 — Ansible (Bare Metal / VMs)

```bash
cd infrastructure/ansible

# 1. Update inventory.ini with your server IPs
# 2. Test connectivity
ansible all -m ping

# 3. Deploy everything
ansible-playbook site.yml

# 4. Target specific role
ansible-playbook site.yml --tags nodejs,nginx
```

---

## Post-Deployment Checklist

```bash
# Run smoke test
bash scripts/smoke-test.sh https://your-domain.com

# Check health
curl https://your-domain.com/api/health | jq .

# Seed demo data
curl -X POST https://your-domain.com/api/clouds/seed/demo

# Schedule backups
echo "0 */4 * * * /opt/ha-framework/scripts/backup.sh" | crontab -
```
