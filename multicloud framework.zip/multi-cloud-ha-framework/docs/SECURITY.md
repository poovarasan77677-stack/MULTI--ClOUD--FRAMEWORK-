# Security Hardening Guide

## Authentication & Authorization

### JWT Configuration
```env
JWT_SECRET=<use: openssl rand -base64 48>  # Min 32 chars
JWT_EXPIRES_IN=8h                           # Reduce from 24h in high-security environments
```

### Rate Limiting (built-in)
- **API routes**: 500 requests/15 min per IP
- **Auth routes**: Recommend 10 requests/15 min (add separately in production)
- **Account lockout**: 5 failed logins → 15-minute lock

### Role-Based Access Control
| Role | Permissions |
|------|------------|
| `admin` | All operations including user management, audit log |
| `operator` | CRUD on providers/servers, trigger failover, acknowledge alerts |
| `viewer` | Read-only access to all dashboards |

## Network Security

### Docker Compose
- Internal services (MongoDB, Redis) are not exposed externally in production
- Nginx reverse proxy sits in front of all services
- Backend binds only to internal Docker network

### Kubernetes
- **Network Policies**: Default deny-all with explicit allow rules per service
- **Pod Security**: Non-root user in backend Dockerfile
- **Service Mesh**: Recommend Istio mTLS for service-to-service encryption

### Nginx Security Headers
```nginx
add_header X-Frame-Options SAMEORIGIN;
add_header X-Content-Type-Options nosniff;
add_header X-XSS-Protection "1; mode=block";
add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; ...";
```

## Secret Management

### Production Recommendations
```bash
# Option 1: AWS Secrets Manager
aws secretsmanager create-secret --name ha-framework/jwt-secret \
  --secret-string "$(openssl rand -base64 48)"

# Option 2: HashiCorp Vault
vault kv put secret/ha-framework \
  jwt-secret=$(openssl rand -base64 48) \
  mongodb-uri="mongodb://..."

# Option 3: Kubernetes External Secrets
# Install external-secrets operator and configure SecretStore
```

### Environment File Security
```bash
chmod 600 backend/.env              # Owner read-write only
chown root:root backend/.env        # Root only in production
```

## Database Security

### MongoDB
```javascript
// Create application user with minimal privileges
db.createUser({
  user: "hauser",
  pwd: "<strong-password>",
  roles: [{ role: "readWrite", db: "multicloud_ha" }]
});
```

```yaml
# mongod.conf production settings
security:
  authorization: enabled
  javascriptEnabled: false  # Disable JS execution

net:
  tls:
    mode: requireTLS
    certificateKeyFile: /etc/ssl/mongodb.pem
    CAFile: /etc/ssl/ca.pem
```

### Redis
```bash
# redis.conf
requirepass <strong-password>
bind 127.0.0.1 10.0.0.0/8     # Restrict to localhost + internal
protected-mode yes
rename-command FLUSHALL ""    # Disable dangerous commands
rename-command CONFIG ""
```

## Container Security

### Docker Image Hardening
```dockerfile
# Use specific digest instead of tag
FROM node:18-alpine@sha256:...
# Run as non-root
USER node
# Read-only filesystem
# Set in docker-compose: read_only: true
# Drop capabilities
# Set in docker-compose: cap_drop: [ALL]
```

### Kubernetes Security Context
```yaml
securityContext:
  runAsNonRoot: true
  runAsUser: 1000
  allowPrivilegeEscalation: false
  readOnlyRootFilesystem: true
  capabilities:
    drop: [ALL]
```

## TLS/SSL

### Let's Encrypt (Production)
```bash
bash scripts/ssl-setup.sh yourdomain.com prod
```

### Certificate Rotation
```bash
# cert-manager handles auto-renewal 30 days before expiry
# Monitor with:
kubectl get certificate -n multi-cloud-ha
```

## Security Scanning

### Dependency Audit
```bash
cd backend  && npm audit --audit-level=high
cd frontend && npm audit --audit-level=high
```

### Container Scanning
```bash
# Trivy
trivy image ha-backend:latest

# Grype
grype ha-backend:latest
```

### SAST (in CI)
The CI pipeline runs Trivy on every push to `main`.

## Incident Response

1. **Detect**: Prometheus alert fires → Alertmanager → Slack/PagerDuty
2. **Assess**: Check Grafana dashboard for blast radius
3. **Contain**: Trigger manual failover if primary compromised
4. **Eradicate**: Rotate secrets (`JWT_SECRET`, DB passwords, cloud credentials)
5. **Recover**: Re-deploy from clean image, restore from backup
6. **Review**: Audit log review, post-mortem

## Compliance Checklist

- [ ] All secrets rotated from defaults
- [ ] TLS enabled on all external endpoints
- [ ] MongoDB auth enabled
- [ ] Redis auth enabled + bound to internal IPs
- [ ] Network policies applied (K8s)
- [ ] Audit log retention configured (min 90 days)
- [ ] Vulnerability scanning in CI/CD
- [ ] Backup encryption enabled
- [ ] Rate limiting tuned for production load
- [ ] Security headers set in Nginx
- [ ] Non-root containers enforced
- [ ] RBAC roles assigned (least privilege)
