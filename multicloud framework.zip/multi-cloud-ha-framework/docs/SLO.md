# Service Level Objectives (SLOs)

## SLO Definitions

### Availability SLO — 99.9% Monthly
| Window | Max Downtime |
|--------|-------------|
| Monthly | 43.8 minutes |
| Weekly  | 10.1 minutes |
| Daily   | 1.4 minutes  |

**Measurement**: `sum(up{job="ha-framework-backend"}) / count(up{job="ha-framework-backend"})`

### Latency SLO — P95 < 800ms
- **P50**: < 150ms
- **P95**: < 800ms  ← SLO
- **P99**: < 2000ms

**Measurement**: `histogram_quantile(0.95, rate(ha_http_request_duration_seconds_bucket[5m]))`

### Error Rate SLO — < 1%
Maximum 1% of requests may result in 5xx errors.

**Measurement**: `rate(ha_http_requests_total{status=~"5.."}[5m]) / rate(ha_http_requests_total[5m])`

### Failover RTO SLO — < 5 minutes
Automatic failover must complete within 5 minutes of primary failure detection.

**Measurement**: `ha_failover_duration_seconds{trigger="automatic"} < 300`

## Error Budget

### Monthly Error Budget
- **Availability**: 43.8 minutes downtime allowed
- **Latency**: 0.5% of requests may exceed P95 threshold
- **Error Rate**: 1% of requests may error

### Error Budget Policy
| Budget Remaining | Action |
|-----------------|--------|
| > 50% | Normal operations |
| 25-50% | Increased change review required |
| 10-25% | Freeze non-critical deployments |
| < 10% | Emergency freeze; incident review required |

## Prometheus SLO Recording Rules

```yaml
# Add to monitoring/prometheus/rules/slo.yml
groups:
  - name: slo-recording-rules
    interval: 1m
    rules:
      - record: ha:availability:rate5m
        expr: avg_over_time(up{job="ha-framework-backend"}[5m])

      - record: ha:latency_p95:rate5m
        expr: histogram_quantile(0.95, sum(rate(ha_http_request_duration_seconds_bucket[5m])) by (le))

      - record: ha:error_rate:rate5m
        expr: |
          sum(rate(ha_http_requests_total{status=~"5.."}[5m]))
          /
          sum(rate(ha_http_requests_total[5m]))

      - alert: SLOAvailabilityBreach
        expr: ha:availability:rate5m < 0.999
        for: 5m
        labels: { severity: critical, slo: availability }
        annotations:
          summary: "Availability SLO breach — {{ $value | humanizePercentage }}"

      - alert: SLOLatencyBreach
        expr: ha:latency_p95:rate5m > 0.8
        for: 5m
        labels: { severity: warning, slo: latency }
        annotations:
          summary: "P95 latency SLO breach — {{ $value | humanizeDuration }}"

      - alert: SLOErrorRateBreach
        expr: ha:error_rate:rate5m > 0.01
        for: 2m
        labels: { severity: critical, slo: error_rate }
        annotations:
          summary: "Error rate SLO breach — {{ $value | humanizePercentage }}"
```
