# API Reference

**Base URL:** `http://localhost:5000/api`

## Authentication

```
POST /api/auth/register  — Create new user account
POST /api/auth/login     — Login and receive JWT
GET  /api/auth/me        — Get current user
POST /api/auth/logout    — Invalidate session
POST /api/auth/seed      — Create demo users (dev only)
```

All protected routes require: `Authorization: Bearer <token>`

## Cloud Providers

```
GET    /api/clouds              — List all providers (with metrics)
GET    /api/clouds/:id          — Get provider by ID
POST   /api/clouds              — Register new provider
PUT    /api/clouds/:id          — Update provider config
DELETE /api/clouds/:id          — Remove provider (cascades servers)
POST   /api/clouds/seed/demo    — Load 4 demo providers + servers
```

## Servers

```
GET    /api/servers             — List servers (filter: ?provider=&status=&role=)
GET    /api/servers/:id         — Get server by ID
POST   /api/servers             — Register new server
PUT    /api/servers/:id         — Update server
DELETE /api/servers/:id         — Terminate server
GET    /api/servers/:id/metrics — Get current metrics snapshot
```

## Alerts

```
GET   /api/alerts               — List alerts (filter: ?status=&severity=&type=)
GET   /api/alerts/summary       — Get active/critical/warning counts
PATCH /api/alerts/:id/acknowledge — Acknowledge alert
PATCH /api/alerts/:id/resolve     — Resolve alert
DELETE /api/alerts/resolved       — Purge resolved alerts >7 days
```

## Failover

```
GET  /api/failover              — List failover events (last 20)
GET  /api/failover/:id          — Get event details with step log
POST /api/failover/trigger      — Trigger manual failover
     Body: { fromProviderId, toProviderId, reason }
GET  /api/failover/stats/summary — Aggregate stats (total, success rate, avg duration)
```

## Metrics & Dashboard

```
GET /api/metrics/dashboard      — Full dashboard data (providers+servers+alerts+failovers)
GET /api/metrics/timeseries     — 24h hourly metrics (CPU, memory, requests, latency)
GET /api/metrics/costs          — Cost breakdown per provider
```

## Load Balancer

```
GET /api/loadbalancer/config    — Get LB configuration
PUT /api/loadbalancer/config    — Update LB config (algorithm, timeouts)
GET /api/loadbalancer/status    — Backend pool health + active connections
GET /api/loadbalancer/traffic   — Last 60s request rate data
```

## System

```
GET /api/health         — Full health report (DB, infrastructure)
GET /api/health/live    — Liveness probe (Kubernetes)
GET /api/health/ready   — Readiness probe (Kubernetes)
GET /metrics            — Prometheus metrics endpoint
```

## WebSocket Events

Connect to `http://localhost:5000` via Socket.IO.

| Event | Direction | Payload |
|-------|-----------|---------|
| `connected` | Server→Client | `{ message, timestamp, socketId }` |
| `provider:update` | Server→Client | `{ _id, status, metrics, healthCheck }` |
| `alert:new` | Server→Client | Full Alert document |
| `alert:acknowledged` | Server→Client | Updated Alert document |
| `alert:resolved` | Server→Client | Updated Alert document |
| `failover:started` | Server→Client | `{ eventId, from, to, reason }` |
| `failover:step` | Server→Client | `{ eventId, stepIndex, stepName, status }` |
| `failover:completed` | Server→Client | `{ eventId, durationMs, fromProvider, toProvider }` |
| `server:new` | Server→Client | `{ server, providerId }` |
| `server:terminated` | Server→Client | `{ serverId, providerId }` |
| `stats:update` | Server→Client | `{ totalServers, healthyServers, timestamp }` |
| `ping` | Client→Server | Any payload |
| `pong` | Server→Client | Echo + `serverTime` |
