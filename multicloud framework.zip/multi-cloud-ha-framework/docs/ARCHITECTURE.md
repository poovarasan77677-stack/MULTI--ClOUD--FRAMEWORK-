# Architecture Deep-Dive

## High Availability Design

### Failure Prevention Mechanisms

#### 1. Health Monitoring (30-second cycle)
Every 30 seconds the backend `healthMonitor` service:
- Pings each registered server's health endpoint
- Tracks consecutive failures per server and provider
- Updates live metrics (CPU, memory, network, latency) with realistic simulation
- Triggers alerts when thresholds are breached
- Publishes real-time updates via Socket.IO

#### 2. Automatic Failover (60-second cycle)
The `failoverService` watches the primary cloud provider and:
- Triggers when `consecutiveFailures >= FAILURE_THRESHOLD` (default: 3)
- Selects the highest-priority healthy failover target
- Executes a 12-step failover pipeline (DNS switch → LB redirect → traffic migration)
- Emits granular step-by-step WebSocket events for live dashboard tracking
- Updates provider roles (`isPrimary`) upon completion
- Records full event history with RTO/RPO metrics

#### 3. Auto Scaling (45-second cycle)
The `autoScaler` monitors average CPU across running servers:
- **Scale Up**: avg CPU > 80% → launch new instance (capped at `maxInstances`)
- **Scale Down**: avg CPU < 20% → terminate least-loaded secondary (floored at `minInstances`)
- New instances start in `pending`, transition to `running` after simulated warmup
- Emits `server:new` and `server:terminated` events for dashboard refresh

### Multi-Cloud Topology

```
┌─────────────────────────────────────────────────────────────┐
│  Primary: AWS us-east-1  (Priority 1)                       │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐   │
│  │Primary LB│ │App Server│ │Replica DB│ │  Cache Layer │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────────────┘   │
└──────────────────────────┬──────────────────────────────────┘
                           │ Health check fails (3x)
                           ▼ Auto failover triggers
┌─────────────────────────────────────────────────────────────┐
│  Failover: Azure eastus  (Priority 2)                       │
│  ┌──────────┐ ┌──────────┐                                  │
│  │Standby LB│ │App Server│  ← Traffic redirected here       │
│  └──────────┘ └──────────┘                                  │
└─────────────────────────────────────────────────────────────┘
│  Standby: GCP us-central1 (Priority 3)                      │
│  Standby: DO nyc3         (Priority 4)                      │
└─────────────────────────────────────────────────────────────┘
```

## Data Models

### CloudProvider
Represents a cloud platform account/region with:
- Connection credentials (encrypted, select: false)
- Real-time metrics (CPU, memory, RPS, latency, error rate)
- Health check state (consecutive failures/successes)
- Cost tracking (hourly/daily/monthly)
- Failover role (isPrimary, isFailoverTarget)

### Server
Individual VM/instance within a provider:
- Full resource metrics (CPU, memory, disk, network, IOPS)
- Health check results (ping latency, consecutive failures)
- Auto-scaling configuration per instance
- Running services manifest (name, port, version, status)

### Alert
Event-driven notifications with:
- 4-level severity: info → warning → critical → emergency
- 15 alert types covering all failure scenarios
- Deduplication (5-min window per type+source)
- Lifecycle: active → acknowledged → resolved

### FailoverEvent
Complete audit trail per failover:
- 12-step execution log with timing
- RTO/RPO metrics per event
- Traffic percentage tracking
- Rollback availability flag

## API Design

All endpoints follow REST conventions:
- `GET /api/resource` — list with pagination
- `GET /api/resource/:id` — single item
- `POST /api/resource` — create
- `PUT /api/resource/:id` — full update
- `PATCH /api/resource/:id/action` — state transition

Authentication via Bearer JWT, roles: admin > operator > viewer.

## Observability Stack

| Tool | Purpose | Port |
|------|---------|------|
| Winston | Structured JSON application logs | — |
| prom-client | 15+ custom Prometheus metrics | /metrics |
| Prometheus | Time-series collection & alerting | 9090 |
| Grafana | Visualization & dashboards | 3001 |
| Alertmanager | Alert routing (Slack/email/PD) | 9093 |
| Socket.IO | Real-time WebSocket push | 5000 |
