# Frequently Asked Questions

## General

**Q: What cloud providers are supported?**  
A: AWS, Azure, GCP, and DigitalOcean are pre-configured. Adding a new provider requires updating the enum in `CloudProvider.js`, adding instance type mappings in `autoScaler.js`, and adding a Terraform module.

**Q: Is this production-ready?**  
A: The framework is production-capable. Before deploying: rotate all default secrets, configure real cloud credentials, enable TLS, set up real MongoDB/Redis clusters, and configure notification channels. See `docs/SECURITY.md`.

**Q: Can I use it without Docker?**  
A: Yes. Run MongoDB and Redis natively, then `cd backend && npm run dev` and `cd frontend && npm start`.

---

## Auto-Failover

**Q: How does automatic failover work?**  
A: Every 60 seconds the `failoverService` checks the primary provider's `consecutiveFailures`. When it reaches `FAILURE_THRESHOLD` (default: 3, ~90s detection), it selects the highest-priority `isFailoverTarget: true` provider and runs a 12-step migration pipeline.

**Q: Can I test failover without breaking anything?**  
A: Yes — use the manual trigger on the Failover page. Select any two providers and click "Trigger Failover". The pipeline is non-destructive in demo mode.

**Q: What is the default RTO?**  
A: ~60–120 seconds for automatic failover in the simulated environment. Real-world RTO depends on DNS TTL, LB reconfiguration time, and database sync lag.

**Q: How do I change the failure threshold?**  
A: Set `FAILURE_THRESHOLD=5` in `backend/.env` and restart.

---

## Auto-Scaling

**Q: When does auto-scaling trigger?**  
A: Scale-up fires when average CPU across running servers exceeds 80%. Scale-down fires when average CPU drops below 20%. Check interval is 45 seconds.

**Q: Where are the scaling limits configured?**  
A: Currently in the `autoScaler.js` service (`scalingConfig.minInstances / maxInstances`). In production, these would come from provider-specific ASG settings via Terraform or K8s HPA.

---

## Monitoring

**Q: Grafana shows "No data"?**  
A: Ensure the backend is running and exposing `/metrics`. Check Prometheus targets at http://localhost:9090/targets. Run `bash scripts/smoke-test.sh` to verify connectivity.

**Q: How do I add a custom alert?**  
A: Add a new rule to `monitoring/prometheus/rules/alerts.yml` and reload Prometheus: `curl -X POST http://localhost:9090/-/reload`.

---

## Development

**Q: How do I add a new API route?**  
1. Create `backend/src/routes/myroute.js`  
2. Import and register in `backend/src/app.js`: `app.use('/api/myroute', require('./routes/myroute'))`  
3. Add service functions if needed in `src/services/`  
4. Write tests in `backend/tests/`  
5. Document in `docs/API.md`

**Q: Tests are failing — "Cannot connect to MongoDB"?**  
A: Tests use mocks and don't need a real DB. Ensure all model `require()` calls are mocked in test files. See existing tests for the mock pattern.

**Q: How do I reset the demo data?**  
```bash
node backend/scripts/reset.js --confirm    # Clears all data
node backend/scripts/seed.js              # Re-seeds demo data
# or via API:
curl -X POST http://localhost:5000/api/clouds/seed/demo
```
