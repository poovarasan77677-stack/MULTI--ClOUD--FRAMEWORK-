# Monitoring Guide

## Stack Overview

| Component | Role | URL |
|-----------|------|-----|
| **prom-client** | Exposes `/metrics` from Node.js app | Internal |
| **Prometheus** | Scrapes and stores metrics | :9090 |
| **Grafana** | Dashboards and visualization | :3001 |
| **Alertmanager** | Routes alerts to Slack/PD/email | :9093 |
| **Socket.IO** | Real-time push to dashboard | :5000 |

---

## Available Prometheus Metrics

| Metric | Type | Description |
|--------|------|-------------|
| `ha_servers_total` | Gauge | Total servers by provider/status |
| `ha_servers_healthy` | Gauge | Healthy server count |
| `ha_server_cpu_percent` | Gauge | Per-server CPU % |
| `ha_server_memory_percent` | Gauge | Per-server memory % |
| `ha_provider_uptime_percent` | Gauge | Provider uptime % |
| `ha_provider_latency_ms` | Gauge | Health check latency |
| `ha_failover_total` | Counter | Total failover events |
| `ha_failover_duration_seconds` | Histogram | Failover completion time |
| `ha_alerts_total` | Counter | Total alerts by severity/type |
| `ha_active_alerts` | Gauge | Current active alerts |
| `ha_scaling_events_total` | Counter | Scale up/down events |
| `ha_http_requests_total` | Counter | HTTP requests by method/route/status |
| `ha_http_request_duration_seconds` | Histogram | Request latency |
| `ha_framework_*` | Various | Default Node.js process metrics |

---

## Grafana Dashboard

Pre-built dashboard auto-provisions on startup.  
URL: http://localhost:3001 — Credentials: admin / haFramework2024!

### Panel List
1. System Health Score (gauge)
2. Active Providers (stat)
3. Running Servers (stat)
4. CPU Usage by Server (time series)
5. Memory Usage by Server (time series)
6. HTTP Request Rate (time series)
7. HTTP P95 Latency (time series)
8. Active Critical Alerts (stat)
9. Failover Events (time series)
10. Provider Uptime % (time series)

---

## Alert Rules

### Built-in Rules (`monitoring/prometheus/rules/alerts.yml`)
| Alert | Condition | Severity |
|-------|-----------|---------|
| `HighCPUUsage` | CPU > 85% for 2m | warning |
| `CriticalCPUUsage` | CPU > 95% for 1m | critical |
| `UnhealthyServers` | < 50% servers healthy | critical |
| `HighActiveAlerts` | > 5 critical alerts | emergency |
| `BackendDown` | API unreachable for 1m | critical |

### SLO Rules (`monitoring/prometheus/rules/slo.yml`)
| Alert | Condition | Severity |
|-------|-----------|---------|
| `SLOAvailabilityBreach` | Uptime < 99.9% for 5m | critical |
| `SLOLatencyBreach` | P95 > 800ms for 5m | warning |
| `SLOErrorRateBreach` | Error rate > 1% for 2m | critical |

---

## Configuring Alertmanager

Edit `monitoring/alertmanager/alertmanager.yml`:

```yaml
global:
  slack_api_url: 'https://hooks.slack.com/services/YOUR/WEBHOOK'

receivers:
  - name: 'default'
    slack_configs:
      - channel: '#alerts'
```

Reload Alertmanager:
```bash
docker-compose restart alertmanager
# or K8s:
kubectl rollout restart deployment/alertmanager -n monitoring
```

---

## Real-Time WebSocket Events

The dashboard subscribes to these events automatically:
- `provider:update` — live metrics every 30s
- `alert:new` — immediate toast + alert list update
- `failover:started/step/completed` — progress tracking
- `server:new/terminated` — auto-scaling events
- `stats:update` — aggregate health summary

Monitor WebSocket health:
```bash
# Check connected clients
curl http://localhost:5000/api/health | jq '.database'
```
