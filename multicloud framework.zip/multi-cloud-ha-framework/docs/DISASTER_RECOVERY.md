# Disaster Recovery Runbook

## RTO / RPO Targets

| Scenario | RTO Target | RPO Target |
|----------|-----------|-----------|
| Single server failure | < 30s (auto) | 0 (stateless) |
| Primary cloud outage | < 2 min (auto failover) | < 60s |
| Database failure | < 5 min | < 5 min |
| Complete region loss | < 10 min (manual) | < 15 min |
| Data corruption | < 30 min | Last backup (max 4h) |

---

## Scenario 1 — Single Server Failure

**Detection**: Health monitor marks server `error` after 3 consecutive failures (~90s)  
**Automatic response**: Auto-scaler may launch replacement instance  
**Manual steps** (if needed):
```bash
# 1. Check server status
curl http://localhost:5000/api/servers?status=error

# 2. Terminate bad instance
curl -X DELETE http://localhost:5000/api/servers/<id>

# 3. Verify auto-scaler launches replacement
curl http://localhost:5000/api/servers?status=pending
```

---

## Scenario 2 — Primary Cloud Provider Outage

**Detection**: Provider health score drops; `consecutiveFailures >= 3`  
**Automatic response**: Failover watcher triggers in ≤60s  
**Monitor via WebSocket**: `failover:started` → `failover:step[]` → `failover:completed`

**Manual trigger** (if auto-failover doesn't fire):
```bash
# 1. Get provider IDs
curl http://localhost:5000/api/clouds

# 2. Trigger failover
curl -X POST http://localhost:5000/api/failover/trigger \
  -H "Content-Type: application/json" \
  -d '{"fromProviderId":"<aws-id>","toProviderId":"<azure-id>","reason":"Manual: AWS outage confirmed"}'

# 3. Monitor progress
# Watch the dashboard Failover page for step-by-step progress
```

**Expected timeline**:
- 0-10s: Failure detection
- 10-30s: Failover target selection
- 30-90s: DNS switch + LB reconfiguration
- 90-120s: Traffic fully migrated

---

## Scenario 3 — Database (MongoDB) Failure

### Replica Set Member Failure (tolerable)
```bash
# Replica set handles automatically — monitor replica health
mongosh --eval "rs.status()"
```

### Primary MongoDB Node Failure
```bash
# Force election of new primary
mongosh --eval "rs.stepDown(60)"

# If auto-election fails, force primary
mongosh --host <secondary-host> --eval "rs.reconfig({...}, {force: true})"
```

### Full Database Loss — Restore from Backup
```bash
# 1. List available backups
ls -lh /tmp/ha-backups/
# Or from S3:
aws s3 ls s3://your-bucket/backups/ --recursive

# 2. Download latest backup
aws s3 cp s3://your-bucket/backups/ha-framework_YYYYMMDD_HHMMSS.tar.gz /tmp/

# 3. Restore
tar -xzf /tmp/ha-framework_*.tar.gz -C /tmp/restore/
mongorestore --uri="$MONGODB_URI" --gzip /tmp/restore/ha-framework_*/

# 4. Verify
mongosh "$MONGODB_URI" --eval "db.cloudproviders.countDocuments()"
```

---

## Scenario 4 — Complete Region Loss

```bash
# 1. Access backup region infrastructure
export KUBECONFIG=~/.kube/config-backup-region

# 2. Scale up backup-region deployment
kubectl scale deployment ha-backend  --replicas=5 -n multi-cloud-ha
kubectl scale deployment ha-frontend --replicas=3 -n multi-cloud-ha

# 3. Update DNS to point to backup region LB
# (In your DNS provider, change A/CNAME record)
# AWS Route53:
aws route53 change-resource-record-sets --hosted-zone-id <id> \
  --change-batch '{"Changes":[{"Action":"UPSERT","ResourceRecordSet":{"Name":"api.yourdomain.com","Type":"A","TTL":60,"ResourceRecords":[{"Value":"<backup-lb-ip>"}]}}]}'

# 4. Seed backup database if needed
kubectl exec -it mongodb-0 -n multi-cloud-ha -- \
  mongorestore --uri="$MONGODB_URI" /backup/latest/

# 5. Notify stakeholders
# Alert ops-team channel with incident details
```

---

## Scenario 5 — Rollback Failed Deployment

```bash
# Kubernetes rollback
kubectl rollout undo deployment/ha-backend  -n multi-cloud-ha
kubectl rollout undo deployment/ha-frontend -n multi-cloud-ha

# Verify rollback
kubectl rollout status deployment/ha-backend -n multi-cloud-ha

# Docker Compose rollback
IMAGE_TAG=<previous-tag> docker-compose up -d backend
```

---

## Post-Incident Checklist

- [ ] Confirm all services returning 200 on `/api/health`
- [ ] Verify MongoDB replica set status is healthy
- [ ] Check alert queue is draining
- [ ] Review audit log for anomalies: `GET /api/audit?from=<incident-time>`
- [ ] Update provider `isPrimary` flag if failover occurred
- [ ] Schedule post-mortem within 48 hours
- [ ] Update runbook based on learnings

---

## Backup Schedule

| Type | Frequency | Retention | Location |
|------|-----------|-----------|---------|
| MongoDB full | Every 4h | 7 days local | /tmp/ha-backups |
| MongoDB full | Daily | 30 days | S3 STANDARD_IA |
| MongoDB full | Weekly | 1 year | S3 Glacier |
| Config files | On change | Git history | GitHub |

```bash
# Run backup manually
bash scripts/backup.sh

# Schedule via cron (add to crontab)
0 */4 * * * /opt/ha-framework/scripts/backup.sh >> /var/log/ha-backup.log 2>&1
```

---

## Emergency Contacts

| Role | Contact | Escalation |
|------|---------|-----------|
| On-Call Engineer | PagerDuty schedule | +1-555-0100 |
| Platform Lead | platform-lead@company.com | Slack #platform |
| Database Admin | dba@company.com | +1-555-0101 |
| Cloud Account | cloud-billing@company.com | AWS/Azure/GCP support |
