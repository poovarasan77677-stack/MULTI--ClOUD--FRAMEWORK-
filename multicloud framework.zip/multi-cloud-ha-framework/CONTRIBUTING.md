# Contributing Guide

## Getting Started

```bash
git clone https://github.com/your-org/multi-cloud-ha-framework
cd multi-cloud-ha-framework
bash scripts/setup.sh
```

## Development Workflow

1. Create a feature branch: `git checkout -b feature/your-feature`
2. Make changes; follow existing code style
3. Run tests: `make test`
4. Commit with conventional commits: `feat:`, `fix:`, `docs:`, `refactor:`
5. Open a pull request against `develop`

## Code Style

- **Backend**: ESLint, CommonJS modules, async/await
- **Frontend**: Functional components, hooks, no class components
- **CSS**: CSS variables only (no hardcoded colors)
- **Commits**: `feat: add failover retry logic` — keep it short and imperative

## Running Tests

```bash
make test            # All backend tests
make test-coverage   # With coverage report
make lint            # ESLint
```

## Adding a New Cloud Provider

1. Add enum value to `CloudProvider` model (`src/models/CloudProvider.js`)
2. Add prefix mapping in `autoScaler.js`
3. Add instance types in `autoScaler.js → INSTANCE_TYPES`
4. Add Terraform module in `infrastructure/terraform/<provider>/`
5. Add color/icon mapping in frontend `ProviderCard.js`
6. Update `README.md` and `docs/ARCHITECTURE.md`
