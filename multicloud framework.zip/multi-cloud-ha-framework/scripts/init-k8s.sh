#!/bin/bash
# ============================================================
# Kubernetes Cluster Initialisation — Multi-Cloud HA Framework
# Run once per cluster to set up all prerequisites
# Usage: bash scripts/init-k8s.sh
# ============================================================
set -e
GREEN='\033[0;32m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${GREEN}✔${NC} $1"; }
info() { echo -e "${CYAN}ℹ${NC} $1"; }

NAMESPACE="${NAMESPACE:-multi-cloud-ha}"

info "Initialising cluster for Multi-Cloud HA Framework..."

# 1. Namespace + quota
kubectl apply -f infrastructure/kubernetes/namespace/namespace.yaml
log "Namespace $NAMESPACE created"

# 2. Secrets (prompt if not set)
JWT_SECRET="${JWT_SECRET:-$(openssl rand -base64 48)}"
MONGO_PASS="${MONGO_PASSWORD:-$(openssl rand -base64 24)}"
REDIS_PASS="${REDIS_PASSWORD:-$(openssl rand -base64 24)}"

kubectl create secret generic ha-secrets \
  --namespace="$NAMESPACE" \
  --from-literal=mongodb-uri="mongodb://admin:${MONGO_PASS}@mongodb:27017/multicloud_ha?authSource=admin" \
  --from-literal=redis-url="redis://:${REDIS_PASS}@redis:6379" \
  --from-literal=jwt-secret="$JWT_SECRET" \
  --from-literal=mongo-username="admin" \
  --from-literal=mongo-password="$MONGO_PASS" \
  --from-literal=redis-password="$REDIS_PASS" \
  --dry-run=client -o yaml | kubectl apply -f -
log "Secrets created"

# 3. ConfigMap
kubectl apply -f infrastructure/kubernetes/deployments/configmap.yaml
log "ConfigMap applied"

# 4. RBAC
kubectl apply -f infrastructure/kubernetes/rbac/rbac.yaml
log "RBAC applied"

# 5. Network policies
kubectl apply -f infrastructure/kubernetes/network-policy/network-policy.yaml
log "Network policies applied"

# 6. Database tier
kubectl apply -f infrastructure/kubernetes/database/mongodb-statefulset.yaml
kubectl apply -f infrastructure/kubernetes/redis/redis-deployment.yaml
log "Database tier deployed"

# 7. Application tier
kubectl apply -f infrastructure/kubernetes/deployments/backend-deployment.yaml
kubectl apply -f infrastructure/kubernetes/frontend/frontend-deployment.yaml
log "Application tier deployed"

# 8. Services + Ingress
kubectl apply -f infrastructure/kubernetes/services/services.yaml
log "Services applied"

# 9. Scheduled jobs
kubectl apply -f infrastructure/kubernetes/jobs/cronjobs.yaml
log "CronJobs applied"

# 10. Wait for rollout
info "Waiting for pods..."
kubectl rollout status deployment/ha-backend  -n "$NAMESPACE" --timeout=300s
kubectl rollout status deployment/ha-frontend -n "$NAMESPACE" --timeout=300s
log "All pods healthy!"

echo ""
echo -e "${GREEN}═══════════════════════════════════════════${NC}"
echo -e "${GREEN}✅  Cluster initialisation complete!${NC}"
echo -e "${GREEN}═══════════════════════════════════════════${NC}"
kubectl get pods -n "$NAMESPACE"
