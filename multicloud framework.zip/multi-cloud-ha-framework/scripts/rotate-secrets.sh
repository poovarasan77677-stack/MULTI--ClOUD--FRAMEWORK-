#!/bin/bash
# ============================================================
# Secret Rotation Script — Multi-Cloud HA Framework
# Rotates JWT secret and optionally DB passwords
# Usage: bash scripts/rotate-secrets.sh [--db-passwords]
# ============================================================
set -e
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[$(date +%H:%M:%S)] ✔${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +%H:%M:%S)] !${NC} $1"; }

ENV_FILE="${ENV_FILE:-backend/.env}"
[ ! -f "$ENV_FILE" ] && { echo -e "${RED}ERROR:${NC} .env not found at $ENV_FILE"; exit 1; }

# Generate new JWT secret
NEW_JWT=$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Backup current .env
cp "$ENV_FILE" "${ENV_FILE}.backup_${TIMESTAMP}"
log "Backed up .env to ${ENV_FILE}.backup_${TIMESTAMP}"

# Replace JWT secret
sed -i "s|^JWT_SECRET=.*|JWT_SECRET=${NEW_JWT}|" "$ENV_FILE"
log "JWT_SECRET rotated (${#NEW_JWT} chars)"

if [[ "$*" == *"--db-passwords"* ]]; then
  NEW_MONGO_PASS=$(node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))")
  NEW_REDIS_PASS=$(node -e "console.log(require('crypto').randomBytes(24).toString('base64url'))")
  warn "DB password rotation requested — update MongoDB and Redis manually, then:"
  warn "  MONGO new password: ${NEW_MONGO_PASS}"
  warn "  REDIS new password: ${NEW_REDIS_PASS}"
  echo ""
  warn "Remember to restart the backend after updating .env"
fi

log "Secret rotation complete. Restart backend to apply:"
log "  make docker-restart   (Docker)"
log "  kubectl rollout restart deployment/ha-backend -n multi-cloud-ha   (K8s)"
