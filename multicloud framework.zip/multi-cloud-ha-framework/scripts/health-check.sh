#!/bin/bash
# Health check script for all services
BACKEND_URL="${BACKEND_URL:-http://localhost:5000}"
FRONTEND_URL="${FRONTEND_URL:-http://localhost:3000}"

echo "=== Multi-Cloud HA Framework Health Check ==="
echo ""

check() {
  local name=$1; local url=$2; local expected=${3:-200}
  local code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 5 "$url" 2>/dev/null)
  if [ "$code" = "$expected" ]; then
    echo "✅ $name: OK ($code)"
  else
    echo "❌ $name: FAIL (got $code, expected $expected)"
  fi
}

check "Backend API"         "$BACKEND_URL/"
check "Backend Health"      "$BACKEND_URL/api/health/live"
check "Backend Ready"       "$BACKEND_URL/api/health/ready"
check "Prometheus Metrics"  "$BACKEND_URL/metrics"
check "Frontend"            "$FRONTEND_URL/"

echo ""
echo "=== Infrastructure Health ==="
curl -s "$BACKEND_URL/api/health" | python3 -m json.tool 2>/dev/null || echo "Cannot parse health response"
