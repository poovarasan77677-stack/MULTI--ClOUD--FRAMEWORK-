#!/bin/bash
# ============================================================
# MongoDB Backup Script — Multi-Cloud HA Framework
# ============================================================
set -e
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="${BACKUP_DIR:-/tmp/ha-backups}"
MONGO_URI="${MONGODB_URI:-mongodb://localhost:27017/multicloud_ha}"
S3_BUCKET="${S3_BUCKET:-}"
RETENTION_DAYS="${RETENTION_DAYS:-7}"

GREEN='\033[0;32m'; RED='\033[0;31m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${GREEN}[$(date +%H:%M:%S)]${NC} $1"; }
err()  { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }
info() { echo -e "${CYAN}[INFO]${NC} $1"; }

log "Starting backup at $TIMESTAMP"
mkdir -p "$BACKUP_DIR"

BACKUP_PATH="$BACKUP_DIR/ha-framework_$TIMESTAMP"
log "Creating backup: $BACKUP_PATH"

mongodump --uri="$MONGO_URI" --out="$BACKUP_PATH" --gzip
if [ $? -ne 0 ]; then err "mongodump failed"; fi

cd "$BACKUP_DIR"
tar -czf "ha-framework_$TIMESTAMP.tar.gz" "ha-framework_$TIMESTAMP" 2>/dev/null
rm -rf "$BACKUP_PATH"

BACKUP_FILE="$BACKUP_DIR/ha-framework_$TIMESTAMP.tar.gz"
BACKUP_SIZE=$(du -sh "$BACKUP_FILE" | awk '{print $1}')
log "Backup created: $BACKUP_FILE ($BACKUP_SIZE)"

# Upload to S3 if configured
if [ -n "$S3_BUCKET" ]; then
  log "Uploading to S3: s3://$S3_BUCKET/backups/"
  aws s3 cp "$BACKUP_FILE" "s3://$S3_BUCKET/backups/" --storage-class STANDARD_IA
  log "Upload complete"
fi

# Clean old backups (local)
find "$BACKUP_DIR" -name "ha-framework_*.tar.gz" -mtime "+$RETENTION_DAYS" -delete
info "Removed backups older than $RETENTION_DAYS days"

log "Backup complete!"
echo "$BACKUP_FILE"
