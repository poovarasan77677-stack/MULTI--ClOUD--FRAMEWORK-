#!/bin/bash
# SSL Certificate Setup using Let's Encrypt + cert-manager (Kubernetes)
# Or self-signed for development
DOMAIN="${1:-localhost}"
MODE="${2:-dev}"  # dev | prod

if [ "$MODE" = "dev" ]; then
  echo "Generating self-signed certificate for $DOMAIN..."
  mkdir -p ./infrastructure/nginx/ssl
  openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
    -keyout ./infrastructure/nginx/ssl/privkey.pem \
    -out    ./infrastructure/nginx/ssl/fullchain.pem \
    -subj "/C=US/ST=State/L=City/O=MultiCloudHA/CN=$DOMAIN" 2>/dev/null
  echo "✅ Self-signed certificate generated"
  echo "   Key:  ./infrastructure/nginx/ssl/privkey.pem"
  echo "   Cert: ./infrastructure/nginx/ssl/fullchain.pem"
else
  echo "Installing cert-manager for Let's Encrypt..."
  kubectl apply -f https://github.com/cert-manager/cert-manager/releases/download/v1.13.0/cert-manager.yaml
  kubectl wait --for=condition=Available deployment/cert-manager -n cert-manager --timeout=120s

  cat <<ISSUEREOF | kubectl apply -f -
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: admin@$DOMAIN
    privateKeySecretRef:
      name: letsencrypt-prod
    solvers:
      - http01:
          ingress:
            class: nginx
ISSUEREOF
  echo "✅ cert-manager ClusterIssuer configured for $DOMAIN"
fi
