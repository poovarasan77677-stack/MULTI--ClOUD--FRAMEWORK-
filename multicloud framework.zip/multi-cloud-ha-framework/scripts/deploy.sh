#!/bin/bash
# ============================================================
# Production Deployment Script — Multi-Cloud HA Framework
# ============================================================
set -e
DEPLOY_ENV="${DEPLOY_ENV:-production}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
REGISTRY="${REGISTRY:-ghcr.io/your-org}"
NAMESPACE="${NAMESPACE:-multi-cloud-ha}"

GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
log()  { echo -e "${GREEN}[$(date +%H:%M:%S)] ✔${NC} $1"; }
warn() { echo -e "${YELLOW}[$(date +%H:%M:%S)] !${NC} $1"; }
err()  { echo -e "${RED}[$(date +%H:%M:%S)] ✘${NC} $1"; exit 1; }

log "Deploying Multi-Cloud HA Framework"
log "Environment: $DEPLOY_ENV | Tag: $IMAGE_TAG"

# Validate kubectl access
kubectl cluster-info &>/dev/null || err "kubectl not configured or cluster unreachable"
log "Kubernetes cluster accessible"

# Apply manifests
log "Applying Kubernetes manifests..."
kubectl apply -f infrastructure/kubernetes/deployments/configmap.yaml -n $NAMESPACE
kubectl apply -f infrastructure/kubernetes/deployments/backend-deployment.yaml -n $NAMESPACE
kubectl apply -f infrastructure/kubernetes/frontend/frontend-deployment.yaml -n $NAMESPACE
kubectl apply -f infrastructure/kubernetes/services/services.yaml -n $NAMESPACE
kubectl apply -f infrastructure/kubernetes/database/mongodb-statefulset.yaml -n $NAMESPACE

# Update images
log "Updating container images to $IMAGE_TAG..."
kubectl set image deployment/ha-backend  ha-backend=$REGISTRY/ha-backend:$IMAGE_TAG  -n $NAMESPACE
kubectl set image deployment/ha-frontend ha-frontend=$REGISTRY/ha-frontend:$IMAGE_TAG -n $NAMESPACE

# Wait for rollout
log "Waiting for backend rollout..."
kubectl rollout status deployment/ha-backend  -n $NAMESPACE --timeout=300s
log "Waiting for frontend rollout..."
kubectl rollout status deployment/ha-frontend -n $NAMESPACE --timeout=300s

# Verify
BACKEND_PODS=$(kubectl get pods -n $NAMESPACE -l app=ha-backend  --field-selector=status.phase=Running --no-headers | wc -l)
FRONTEND_PODS=$(kubectl get pods -n $NAMESPACE -l app=ha-frontend --field-selector=status.phase=Running --no-headers | wc -l)
log "Backend pods running: $BACKEND_PODS"
log "Frontend pods running: $FRONTEND_PODS"

[ "$BACKEND_PODS" -lt 1 ]  && err "No backend pods are running!"
[ "$FRONTEND_PODS" -lt 1 ] && err "No frontend pods are running!"

log ""
log "✅  Deployment successful!"
log "    Tag:     $IMAGE_TAG"
log "    Backend: $BACKEND_PODS pods"
log "    Frontend:$FRONTEND_PODS pods"
log ""
kubectl get services -n $NAMESPACE
