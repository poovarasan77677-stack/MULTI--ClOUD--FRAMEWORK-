#!/bin/bash
# ============================================================
# Quick Smoke Test — validates all key endpoints are healthy
# Usage: bash scripts/smoke-test.sh [base_url]
# ============================================================
BASE="${1:-http://localhost:5000}"
FRONT="${2:-http://localhost:3000}"
PASS=0; FAIL=0

check() {
  local name="$1" url="$2" expected="${3:-200}"
  local code
  code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 8 "$url" 2>/dev/null)
  if [ "$code" = "$expected" ]; then
    echo "  ✅  $name ($code)"; ((PASS++))
  else
    echo "  ❌  $name (expected $expected, got $code)"; ((FAIL++))
  fi
}

echo ""
echo "🔍  Smoke test: $BASE"
echo "─────────────────────────────────────────"

check "Backend root"         "$BASE/"
check "Health live"          "$BASE/api/health/live"
check "Health ready"         "$BASE/api/health/ready"
check "Health full"          "$BASE/api/health"
check "Prometheus metrics"   "$BASE/metrics"
check "Cloud providers"      "$BASE/api/clouds"
check "Servers"              "$BASE/api/servers"
check "Alerts"               "$BASE/api/alerts"
check "Alert summary"        "$BASE/api/alerts/summary"
check "Dashboard metrics"    "$BASE/api/metrics/dashboard"
check "Timeseries metrics"   "$BASE/api/metrics/timeseries"
check "Cost metrics"         "$BASE/api/metrics/costs"
check "LB config"            "$BASE/api/loadbalancer/config"
check "LB status"            "$BASE/api/loadbalancer/status"
check "Failover events"      "$BASE/api/failover"
check "Failover stats"       "$BASE/api/failover/stats/summary"

echo ""
echo "🌐  Frontend: $FRONT"
echo "─────────────────────────────────────────"
check "Frontend dashboard"   "$FRONT/"

echo ""
echo "─────────────────────────────────────────"
echo "  Passed: $PASS  |  Failed: $FAIL"

if [ "$FAIL" -gt 0 ]; then
  echo "  ⚠️   Some checks failed — see above"
  exit 1
else
  echo "  ✅  All checks passed!"
  exit 0
fi
