#!/bin/bash
# Start all services in development mode
set -e
GREEN='\033[0;32m'; NC='\033[0m'

echo -e "${GREEN}Starting Multi-Cloud HA Framework (Dev Mode)...${NC}"

# Start Docker services if available
if command -v docker-compose &>/dev/null; then
  echo "Starting infrastructure services..."
  docker-compose up -d mongo redis
  sleep 3
fi

# Start backend in background
echo "Starting backend API on :5000..."
cd backend && npm run dev &
BACKEND_PID=$!

sleep 4

# Start frontend
echo "Starting frontend on :3000..."
cd ../frontend && npm start &
FRONTEND_PID=$!

echo -e "${GREEN}All services started!${NC}"
echo "  Backend PID: $BACKEND_PID"
echo "  Frontend PID: $FRONTEND_PID"
echo ""
echo "  Dashboard → http://localhost:3000"
echo "  API       → http://localhost:5000"
echo ""
echo "Press Ctrl+C to stop all services"

trap "kill $BACKEND_PID $FRONTEND_PID 2>/dev/null; echo 'Services stopped.'" EXIT
wait
