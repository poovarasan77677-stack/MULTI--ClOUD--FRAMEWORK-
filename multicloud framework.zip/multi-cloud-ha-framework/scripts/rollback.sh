#!/bin/bash
# ============================================================
# Rollback Script — revert to previous deployment
# ============================================================
set -e
GREEN='\033[0;32m'; RED='\033[0;31m'; NC='\033[0m'
log() { echo -e "${GREEN}[$(date +%H:%M:%S)] ✔${NC} $1"; }
err() { echo -e "${RED}[$(date +%H:%M:%S)] ✘${NC} $1"; exit 1; }

DEPLOY_TARGET="${1:-docker}"  # docker | k8s
NAMESPACE="${NAMESPACE:-multi-cloud-ha}"

case "$DEPLOY_TARGET" in
  docker)
    log "Rolling back via Docker Compose..."
    PREV_TAG=$(docker images ha-backend --format "{{.Tag}}" | grep -v latest | head -1)
    [ -z "$PREV_TAG" ] && err "No previous image tag found"
    IMAGE_TAG="$PREV_TAG" docker-compose up -d backend frontend
    log "Rolled back to tag: $PREV_TAG"
    ;;
  k8s)
    log "Rolling back Kubernetes deployments..."
    kubectl rollout undo deployment/ha-backend  -n "$NAMESPACE"
    kubectl rollout undo deployment/ha-frontend -n "$NAMESPACE"
    kubectl rollout status deployment/ha-backend  -n "$NAMESPACE" --timeout=120s
    kubectl rollout status deployment/ha-frontend -n "$NAMESPACE" --timeout=120s
    log "Kubernetes rollback complete"
    kubectl get pods -n "$NAMESPACE"
    ;;
  *)
    err "Unknown target. Use: bash scripts/rollback.sh docker|k8s"
    ;;
esac
