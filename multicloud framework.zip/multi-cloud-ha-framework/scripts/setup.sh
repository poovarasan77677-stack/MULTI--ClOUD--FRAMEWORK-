#!/bin/bash
# ============================================================
# Multi-Cloud HA Framework - One-Click Setup Script
# ============================================================
set -e

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
log()  { echo -e "${GREEN}[✔]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[✘]${NC} $1"; exit 1; }
info() { echo -e "${CYAN}[i]${NC} $1"; }

echo ""
echo -e "${CYAN}╔══════════════════════════════════════════════════════╗"
echo -e "║    Multi-Cloud High Availability Framework Setup    ║"
echo -e "╚══════════════════════════════════════════════════════╝${NC}"
echo ""

# Check Node.js
if ! command -v node &>/dev/null; then err "Node.js is required. Install from https://nodejs.org"; fi
NODE_VER=$(node --version | cut -d'v' -f2 | cut -d'.' -f1)
[ "$NODE_VER" -lt 18 ] && err "Node.js v18+ required. Found: $(node --version)"
log "Node.js $(node --version) found"

# Check Docker
if command -v docker &>/dev/null; then
  log "Docker $(docker --version | awk '{print $3}' | tr -d ',') found"
  DOCKER_AVAILABLE=true
else
  warn "Docker not found. Manual MongoDB & Redis setup required."
  DOCKER_AVAILABLE=false
fi

# Install backend
info "Installing backend dependencies..."
cd backend && npm install --silent && cd ..
log "Backend dependencies installed"

# Install frontend
info "Installing frontend dependencies..."
cd frontend && npm install --silent && cd ..
log "Frontend dependencies installed"

# Generate .env
if [ ! -f backend/.env ]; then
  JWT_SECRET=$(node -e "console.log(require('crypto').randomBytes(32).toString('hex'))")
  cat > backend/.env << ENVEOF
NODE_ENV=development
PORT=5000
FRONTEND_URL=http://localhost:3000
MONGODB_URI=mongodb://localhost:27017/multicloud_ha
REDIS_URL=redis://localhost:6379
JWT_SECRET=${JWT_SECRET}
JWT_EXPIRES_IN=24h
LOG_LEVEL=info
ENVEOF
  log ".env file created with secure JWT secret"
else
  warn ".env already exists, skipping"
fi

# Start Docker services
if [ "$DOCKER_AVAILABLE" = true ]; then
  info "Starting MongoDB and Redis with Docker..."
  docker-compose up -d mongo redis 2>/dev/null || true
  sleep 5
  log "MongoDB and Redis started"
fi

echo ""
echo -e "${GREEN}╔══════════════════════════════════════════════════════╗"
echo -e "║            ✅  Setup Complete!                      ║"
echo -e "╚══════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e " ${CYAN}To start the application:${NC}"
echo -e "   ${YELLOW}# Terminal 1 — Backend API:${NC}"
echo -e "   cd backend && npm run dev"
echo ""
echo -e "   ${YELLOW}# Terminal 2 — Frontend:${NC}"
echo -e "   cd frontend && npm start"
echo ""
echo -e "   ${YELLOW}# Or run everything:${NC}"
echo -e "   bash scripts/start-dev.sh"
echo ""
echo -e " ${CYAN}URLs:${NC}"
echo -e "   Dashboard: ${GREEN}http://localhost:3000${NC}"
echo -e "   API:       ${GREEN}http://localhost:5000${NC}"
echo -e "   API Docs:  ${GREEN}http://localhost:5000/api/health${NC}"
echo -e "   Metrics:   ${GREEN}http://localhost:5000/metrics${NC}"
echo ""
echo -e " ${CYAN}After startup, seed demo data:${NC}"
echo -e "   curl -X POST http://localhost:5000/api/clouds/seed/demo"
echo ""
