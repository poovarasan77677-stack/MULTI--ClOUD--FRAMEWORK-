# 🌐 Multi-Cloud High Availability Framework

> A production-grade, fully automated framework for **server failure prevention** and **High Availability** across AWS, Azure, GCP, and DigitalOcean.

![Architecture](https://img.shields.io/badge/Architecture-Multi--Cloud-blue)
![Stack](https://img.shields.io/badge/Stack-MERN%20%2B%20Socket.IO%20%2B%20Prometheus-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

---

## ✨ Features

| Feature | Description |
|---------|-------------|
| 🔄 **Auto Failover** | Automatic detection & traffic rerouting when primary cloud fails |
| 📈 **Auto Scaling** | CPU/memory-based horizontal scaling across all providers |
| 📊 **Real-time Dashboard** | Live metrics via WebSocket with Recharts visualizations |
| 🚨 **Smart Alerts** | Deduplication, severity routing, Slack/email/PagerDuty integration |
| ⚖️ **Load Balancing** | Round-robin, least-connections, weighted, ip-hash algorithms |
| 🏗️ **IaC** | Terraform modules for AWS, Azure, GCP with remote state |
| ☸️ **Kubernetes** | K8s manifests with HPA, PDB, and rolling deployments |
| 📉 **Prometheus + Grafana** | Full observability stack with pre-built dashboards |
| 🔐 **JWT Auth** | Role-based access: admin, operator, viewer |
| 🛡️ **Security** | Helmet, rate limiting, input validation, encrypted secrets |

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     React Dashboard (Port 3000)              │
│          Real-time updates via Socket.IO WebSocket           │
└─────────────────────────┬───────────────────────────────────┘
                          │ REST + Socket.IO
┌─────────────────────────▼───────────────────────────────────┐
│              Node.js / Express API (Port 5000)               │
│  ┌──────────────┐ ┌────────────┐ ┌────────────────────────┐ │
│  │ Health Monitor│ │Auto Scaler │ │   Failover Watcher     │ │
│  │  (cron: 30s) │ │ (cron:45s) │ │     (cron: 60s)        │ │
│  └──────────────┘ └────────────┘ └────────────────────────┘ │
└──────────────┬──────────────────────────────────────────────┘
               │
┌──────────────▼──────────────────────────────────────────────┐
│                      MongoDB + Redis                         │
└──────────────────────────────────────────────────────────────┘
               │
┌──────────────▼──────────────────────────────────────────────┐
│                   Cloud Providers                            │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────┐  │
│  │   AWS    │  │  Azure   │  │   GCP    │  │DigitalOcean│  │
│  │(Primary) │  │(Failover)│  │(Failover)│  │ (Standby)  │  │
│  └──────────┘  └──────────┘  └──────────┘  └────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Option 1: One-Click Setup (Recommended)
```bash
git clone https://github.com/your-org/multi-cloud-ha-framework.git
cd multi-cloud-ha-framework
bash scripts/setup.sh
bash scripts/start-dev.sh
```

### Option 2: Docker Compose
```bash
docker-compose up -d
```
Access at: `http://localhost:3000`

### Option 3: Manual Setup
```bash
# 1. Backend
cd backend && npm install && cp .env.example .env && npm run dev

# 2. Frontend (new terminal)
cd frontend && npm install && npm start

# 3. Seed demo data
curl -X POST http://localhost:5000/api/clouds/seed/demo
```

---

## 📁 Project Structure

```
multi-cloud-ha-framework/
├── backend/                    # Node.js + Express API
│   ├── src/
│   │   ├── app.js              # Entry point
│   │   ├── config/             # Database config
│   │   ├── models/             # Mongoose schemas
│   │   ├── routes/             # REST API endpoints
│   │   ├── services/           # Business logic
│   │   │   ├── healthMonitor.js    # 30s health checks
│   │   │   ├── failoverService.js  # Auto failover logic
│   │   │   ├── autoScaler.js       # Scale up/down
│   │   │   ├── alertService.js     # Alert management
│   │   │   └── metricsService.js   # Prometheus metrics
│   │   ├── middleware/         # Auth, error handling
│   │   └── utils/              # Logger
│   └── Dockerfile
│
├── frontend/                   # React 18 Dashboard
│   ├── src/
│   │   ├── App.js
│   │   ├── context/            # Global state
│   │   ├── pages/              # Dashboard, Providers, Servers, Alerts, Failover, LB, Settings
│   │   ├── components/         # Reusable components
│   │   └── services/           # API + Socket clients
│   └── Dockerfile
│
├── infrastructure/
│   ├── terraform/
│   │   ├── aws/                # AWS IaC (VPC, ALB, ASG, RDS)
│   │   ├── azure/              # Azure IaC
│   │   └── gcp/                # GCP IaC
│   ├── kubernetes/             # K8s manifests (Deployments, HPA, PDB, Ingress)
│   └── nginx/                  # Reverse proxy config
│
├── monitoring/
│   ├── prometheus/             # Scrape config + alert rules
│   ├── grafana/                # Dashboards + datasources
│   └── alertmanager/           # Routing + receivers
│
├── scripts/
│   ├── setup.sh                # One-click setup
│   ├── start-dev.sh            # Dev startup
│   └── health-check.sh         # Health verification
│
├── .github/workflows/          # CI/CD pipeline
└── docker-compose.yml          # Full stack orchestration
```

---

## 🌐 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET    | `/api/health` | Full system health |
| GET    | `/api/clouds` | List cloud providers |
| POST   | `/api/clouds/seed/demo` | Seed demo data |
| GET    | `/api/servers` | List all servers |
| GET    | `/api/alerts` | Get alerts |
| POST   | `/api/failover/trigger` | Trigger manual failover |
| GET    | `/api/metrics/dashboard` | Dashboard metrics |
| GET    | `/metrics` | Prometheus metrics |

---

## 🔑 Demo Credentials

After seeding: `POST http://localhost:5000/api/auth/seed`

| Role | Email | Password |
|------|-------|----------|
| Admin | admin@multicloud-ha.io | Admin@1234 |
| Operator | operator@multicloud-ha.io | Operator@1234 |

---

## 🔧 Configuration

See `.env.example` for all options. Key variables:

```env
MONGODB_URI=mongodb://localhost:27017/multicloud_ha
JWT_SECRET=your-secure-random-secret
HEALTH_CHECK_INTERVAL=*/30 * * * * *
FAILURE_THRESHOLD=3
```

---

## 📊 Monitoring

- **Prometheus**: http://localhost:9090
- **Grafana**: http://localhost:3001 (admin/haFramework2024!)
- **Alertmanager**: http://localhost:9093

---

## 🛡️ Production Checklist

- [ ] Change all default passwords in `docker-compose.yml`
- [ ] Set strong `JWT_SECRET` (min 32 chars)
- [ ] Configure SSL/TLS certificates
- [ ] Set up real cloud provider credentials
- [ ] Configure Slack/PagerDuty/email notifications
- [ ] Enable MongoDB authentication
- [ ] Set up database backups
- [ ] Review firewall rules

---

## 📄 License

MIT © 2024 Multi-Cloud HA Framework
